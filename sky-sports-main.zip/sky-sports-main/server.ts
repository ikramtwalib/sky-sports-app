import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import {
  CONTINUATION_LEAGUE_IDS,
  LEAGUE_API_MAPPINGS,
  OVERVIEW_LEAGUE_IDS,
  TANZANIA_TIMEZONE,
  buildClubWikipediaCandidates,
  buildTeamsFromStandingsAndMatches,
  calculateStandingsFromResults,
  deriveLeaderFromStandings,
  emptyStats,
  enrichStandingsWithResults,
  extractWikipediaInfoboxLogoFile,
  normalizeLookupName,
  parseEspnLeagueLeaders,
  parseEspnMultiSportScoreboard,
  parseEspnNews,
  parseEspnScoreboard,
  parseEspnStandings,
  parseEspnSummary,
  parseEspnTeamDetailAndRoster,
  parseFootballDataStandings,
  parseWikipediaImageInfoUrls,
  parseWikipediaPortraitMap,
} from './src/server/footballMappings.ts';
import type {
  FootballMatch,
  LeagueLeaderItem,
  LeagueStatsApiResponse,
  MultiSportApiResponse,
  MultiSportEvent,
  NewsApiResponse,
  NewsHeadline,
  OverviewApiResponse,
  PlayerStat,
  PlayersApiResponse,
  SportCategoryId,
  StandingRow,
  StandingsApiResponse,
  TeamDetailApiResponse,
  TransfersApiResponse,
} from './src/types/football.ts';

const ESPN_BASE = 'https://site.api.espn.com/apis/site/v2/sports/soccer';
const ESPN_STANDINGS_BASE = 'https://site.api.espn.com/apis/v2/sports/soccer';
const ESPN_SPORTS_ROOT = 'https://site.api.espn.com/apis/site/v2/sports';
const WIKI_API_BASE = 'https://en.wikipedia.org/w/api.php';

const TTL_LIVE_MS = 20_000;
const TTL_STANDINGS_MS = 45_000;
const TTL_HISTORICAL_MS = 300_000;
const MIN_FORCE_COOLDOWN_MS = 10_000;

interface CacheEntry<T> {
  expiresAt: number;
  createdAt: number;
  data: T;
}

const cache = new Map<string, CacheEntry<unknown>>();
const inFlightRequests = new Map<string, Promise<unknown>>();
const rateLimitUntilByHost = new Map<string, number>();
const previousMatchStatusById = new Map<string, FootballMatch['status']>();
const clubLogoCache = new Map<string, { expiresAt: number; url: string | null }>();
const playerPhotoCache = new Map<string, { expiresAt: number; url: string | null }>();
const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;

function getCachedEntry<T>(key: string): CacheEntry<T> | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry as CacheEntry<T>;
}

function getCached<T>(key: string): T | null {
  return getCachedEntry<T>(key)?.data ?? null;
}

function setCached<T>(key: string, data: T, ttlMs: number): T {
  const now = Date.now();
  cache.set(key, { data, createdAt: now, expiresAt: now + ttlMs });
  return data;
}

function dedupeInFlight<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const existing = inFlightRequests.get(key);
  if (existing) return existing as Promise<T>;
  const promise = fn().finally(() => {
    inFlightRequests.delete(key);
  });
  inFlightRequests.set(key, promise);
  return promise;
}

async function fetchJsonWithTimeout(url: string, headers: Record<string, string> = {}): Promise<unknown> {
  const host = new URL(url).host;
  const blockedUntil = rateLimitUntilByHost.get(host) ?? 0;
  if (Date.now() < blockedUntil) {
    const waitSec = Math.max(1, Math.ceil((blockedUntil - Date.now()) / 1000));
    throw new Error(`Provider rate limit active for ${host}. Retry in ${waitSec}s.`);
  }

  return dedupeInFlight(`http:${url}`, async () => {
    const res = await fetch(url, {
      headers: {
        Accept: 'application/json',
        'User-Agent': 'SkySports-Football-Hub/1.0',
        ...headers,
      },
      signal: AbortSignal.timeout(8500),
    });
    if (res.status === 429) {
      const retryAfterSec = Number(res.headers.get('retry-after')) || 30;
      rateLimitUntilByHost.set(host, Date.now() + Math.min(retryAfterSec, 120) * 1000);
      throw new Error(`Upstream rate limit (429) for ${host}. Backing off for ${retryAfterSec}s.`);
    }
    if (!res.ok) {
      throw new Error(`Upstream HTTP ${res.status} for ${url}`);
    }
    const contentType = res.headers.get('content-type') || '';
    if (contentType && !contentType.includes('json') && !contentType.includes('javascript')) {
      throw new Error(`Unexpected upstream content-type (${contentType}) for ${url}`);
    }
    const parsed: unknown = await res.json();
    if (!parsed || typeof parsed !== 'object') {
      throw new Error(`Invalid JSON structure returned by ${url}`);
    }
    return parsed;
  });
}

async function resolveMissingClubLogos(
  clubs: Array<{ key: string; name: string }>
): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  const now = Date.now();
  const pending: Array<{ key: string; name: string; candidates: string[] }> = [];
  const seenKeys = new Set<string>();

  for (const c of clubs) {
    if (!c.name || seenKeys.has(c.key)) continue;
    seenKeys.add(c.key);
    const cached = clubLogoCache.get(c.key);
    if (cached && now < cached.expiresAt) {
      if (cached.url) result.set(c.key, cached.url);
      continue;
    }
    pending.push({
      key: c.key,
      name: c.name,
      candidates: buildClubWikipediaCandidates(c.name),
    });
  }

  if (pending.length === 0) return result;

  // Query Wikipedia in safe batches of 35 titles
  const candidateToKeys = new Map<string, string[]>();
  const allTitles: string[] = [];
  for (const item of pending) {
    const primaryTitles = item.candidates.slice(0, 3);
    for (const t of primaryTitles) {
      if (!candidateToKeys.has(t)) {
        candidateToKeys.set(t, []);
        allTitles.push(t);
      }
      candidateToKeys.get(t)!.push(item.key);
    }
  }

  const keyToFileTitle = new Map<string, string>();

  for (let i = 0; i < allTitles.length; i += 35) {
    const chunk = allTitles.slice(i, i + 35);
    try {
      const url = `${WIKI_API_BASE}?action=query&titles=${encodeURIComponent(
        chunk.join('|')
      )}&prop=revisions&rvprop=content&rvsection=0&redirects=1&format=json`;
      const payload = (await fetchJsonWithTimeout(url)) as {
        query?: {
          pages?: Record<string, { title?: string; revisions?: Array<{ '*'?: string }> }>;
          normalized?: Array<{ from?: string; to?: string }>;
          redirects?: Array<{ from?: string; to?: string }>;
        };
      };

      const normalizedMap = new Map<string, string>();
      for (const n of payload.query?.normalized || []) {
        if (n.from && n.to) normalizedMap.set(n.to, n.from);
      }
      const redirectsMap = new Map<string, string[]>();
      for (const r of payload.query?.redirects || []) {
        if (r.from && r.to) {
          const arr = redirectsMap.get(r.to) || [];
          arr.push(r.from);
          redirectsMap.set(r.to, arr);
        }
      }

      for (const page of Object.values(payload.query?.pages || {})) {
        const wikitext = page.revisions?.[0]?.['*'] || '';
        const logoFile = extractWikipediaInfoboxLogoFile(wikitext);
        if (!logoFile || !page.title) continue;

        const matchingSources = new Set<string>([page.title]);
        const nFrom = normalizedMap.get(page.title);
        if (nFrom) matchingSources.add(nFrom);
        for (const rFrom of redirectsMap.get(page.title) || []) {
          matchingSources.add(rFrom);
          const rnFrom = normalizedMap.get(rFrom);
          if (rnFrom) matchingSources.add(rnFrom);
        }

        for (const srcTitle of matchingSources) {
          for (const clubKey of candidateToKeys.get(srcTitle) || []) {
            if (!keyToFileTitle.has(clubKey)) {
              keyToFileTitle.set(clubKey, logoFile);
            }
          }
        }
      }
    } catch {
      // Non-fatal: continue with resolved chunk
    }
  }

  // Batch fetch real image URLs from Wikipedia imageinfo
  const uniqueFiles = Array.from(new Set(keyToFileTitle.values()));
  const fileToUrl = new Map<string, string>();
  for (let i = 0; i < uniqueFiles.length; i += 40) {
    const chunk = uniqueFiles.slice(i, i + 40);
    try {
      const url = `${WIKI_API_BASE}?action=query&titles=${encodeURIComponent(
        chunk.join('|')
      )}&prop=imageinfo&iiprop=url&iiurlwidth=240&format=json`;
      const payload = await fetchJsonWithTimeout(url);
      const parsedUrls = parseWikipediaImageInfoUrls(payload);
      for (const [fTitle, imgUrl] of Object.entries(parsedUrls)) {
        fileToUrl.set(fTitle, imgUrl);
      }
    } catch {
      // Non-fatal
    }
  }

  for (const item of pending) {
    const f = keyToFileTitle.get(item.key);
    const resolvedUrl = f ? fileToUrl.get(f) || null : null;
    clubLogoCache.set(item.key, {
      url: resolvedUrl,
      expiresAt: now + (resolvedUrl ? TWENTY_FOUR_HOURS_MS : 10 * 60 * 1000),
    });
    if (resolvedUrl) {
      result.set(item.key, resolvedUrl);
    }
  }

  return result;
}

async function resolvePlayerHeadshots(players: PlayerStat[], maxToResolve = 140): Promise<PlayerStat[]> {
  if (players.length === 0) return players;
  const now = Date.now();
  const subset = players.slice(0, maxToResolve);
  const unresolved: PlayerStat[] = [];

  for (const p of subset) {
    if (p.headshotUrl) continue;
    const cacheKey = normalizeLookupName(p.name);
    const cached = playerPhotoCache.get(cacheKey);
    if (cached && now < cached.expiresAt) continue;
    unresolved.push(p);
  }

  if (unresolved.length > 0) {
    const uniqueNames = Array.from(new Set(unresolved.map((p) => p.name.trim()))).filter(Boolean);
    for (let i = 0; i < uniqueNames.length; i += 45) {
      const chunk = uniqueNames.slice(i, i + 45);
      try {
        const url = `${WIKI_API_BASE}?action=query&titles=${encodeURIComponent(
          chunk.map((n) => n.replace(/ /g, '_')).join('|')
        )}&prop=pageimages&redirects=1&format=json&pithumbsize=240`;
        const payload = await fetchJsonWithTimeout(url);
        const portraitMap = parseWikipediaPortraitMap(payload);
        for (const name of chunk) {
          const norm = normalizeLookupName(name);
          const photo = portraitMap[norm] || null;
          if (photo) {
            playerPhotoCache.set(norm, { url: photo, expiresAt: now + TWENTY_FOUR_HOURS_MS });
          }
        }
      } catch {
        // Non-fatal
      }
    }

    // Second pass with " (footballer)" disambiguation for players whose plain name had no portrait
    const stillMissing = uniqueNames.filter((name) => {
      const cached = playerPhotoCache.get(normalizeLookupName(name));
      return !cached || !cached.url;
    });
    for (let i = 0; i < Math.min(stillMissing.length, 45); i += 45) {
      const chunk = stillMissing.slice(i, i + 45);
      try {
        const url = `${WIKI_API_BASE}?action=query&titles=${encodeURIComponent(
          chunk.map((n) => `${n.replace(/ /g, '_')}_(footballer)`).join('|')
        )}&prop=pageimages&redirects=1&format=json&pithumbsize=240`;
        const payload = await fetchJsonWithTimeout(url);
        const portraitMap = parseWikipediaPortraitMap(payload);
        for (const name of chunk) {
          const normFootballer = normalizeLookupName(`${name} (footballer)`);
          const normPlain = normalizeLookupName(name);
          const photo = portraitMap[normFootballer] || portraitMap[normPlain] || null;
          playerPhotoCache.set(normPlain, {
            url: photo,
            expiresAt: now + (photo ? TWENTY_FOUR_HOURS_MS : 30 * 60 * 1000),
          });
        }
      } catch {
        // Non-fatal
      }
    }
  }

  return players.map((p) => {
    if (p.headshotUrl) return p;
    const cached = playerPhotoCache.get(normalizeLookupName(p.name));
    if (cached?.url) {
      return { ...p, headshotUrl: cached.url };
    }
    return p;
  });
}

function dedupeMatches(list: FootballMatch[]): FootballMatch[] {
  const seen = new Map<string, FootballMatch>();
  for (const m of list) {
    const existing = seen.get(m.id);
    if (!existing) {
      seen.set(m.id, m);
    } else if (m.events.length > existing.events.length) {
      seen.set(m.id, m);
    }
  }
  return Array.from(seen.values());
}

function sortMatchesChronologically(list: FootballMatch[]): FootballMatch[] {
  const priority = (s: FootballMatch['status']) => (s === 'live' ? 0 : s === 'upcoming' ? 1 : 2);
  return [...list].sort((a, b) => {
    const pDiff = priority(a.status) - priority(b.status);
    if (pDiff !== 0) return pDiff;
    const tA = a.kickoffIso ? Date.parse(a.kickoffIso) : 0;
    const tB = b.kickoffIso ? Date.parse(b.kickoffIso) : 0;
    if (a.status === 'result') return tB - tA;
    return tA - tB;
  });
}

async function fetchLeagueMatchesLive(
  leagueId: string,
  includeRecentResults = true
): Promise<FootballMatch[]> {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta?.espnSlug) return [];

  const cacheKey = `league-matches:${leagueId}:${includeRecentResults ? 'full' : 'lite'}`;
  const cached = getCached<FootballMatch[]>(cacheKey);
  if (cached) return cached;

  const basePayload = await fetchJsonWithTimeout(`${ESPN_BASE}/${meta.espnSlug}/scoreboard`);
  const baseParsed = parseEspnScoreboard(leagueId, basePayload);
  let combined = [...baseParsed.matches];

  const hasResult = combined.some((m) => m.status === 'result');
  if (includeRecentResults && !hasResult && baseParsed.pastDates.length > 0) {
    const latestPastDate = baseParsed.pastDates[baseParsed.pastDates.length - 1];
    try {
      const pastPayload = await fetchJsonWithTimeout(
        `${ESPN_BASE}/${meta.espnSlug}/scoreboard?dates=${latestPastDate}`
      );
      const pastParsed = parseEspnScoreboard(leagueId, pastPayload);
      combined = [...combined, ...pastParsed.matches];
    } catch {
      // Non-fatal: continue with primary scoreboard events
    }
  }

  const finalMatches = sortMatchesChronologically(dedupeMatches(combined));

  // Enrich any missing club logos via Wikipedia Infobox Crest API
  const missingClubs: Array<{ key: string; name: string }> = [];
  for (const m of finalMatches) {
    if (!m.homeLogo) missingClubs.push({ key: m.homeTeamId, name: m.homeTeam });
    if (!m.awayLogo) missingClubs.push({ key: m.awayTeamId, name: m.awayTeam });
  }
  if (missingClubs.length > 0) {
    const resolvedLogos = await resolveMissingClubLogos(missingClubs);
    for (let i = 0; i < finalMatches.length; i += 1) {
      const m = finalMatches[i]!;
      const homeLogo = m.homeLogo || resolvedLogos.get(m.homeTeamId);
      const awayLogo = m.awayLogo || resolvedLogos.get(m.awayTeamId);
      if (homeLogo !== m.homeLogo || awayLogo !== m.awayLogo) {
        finalMatches[i] = { ...m, homeLogo, awayLogo };
      }
    }
  }

  return setCached(cacheKey, finalMatches, TTL_LIVE_MS);
}

async function fetchStandingsFromApiFootball(leagueId: string, apiFootballId: number): Promise<StandingRow[]> {
  const apiKey = process.env.API_FOOTBALL_KEY?.trim();
  if (!apiKey) return [];

  const url = `https://v3.football.api-sports.io/standings?league=${apiFootballId}&season=2026`;
  const payload = (await fetchJsonWithTimeout(url, {
    'x-apisports-key': apiKey,
  })) as {
    response?: Array<{
      league?: {
        standings?: Array<
          Array<{
            rank?: number;
            team?: { id?: number; name?: string; logo?: string };
            points?: number;
            goalsDiff?: number;
            form?: string;
            description?: string;
            all?: { played?: number; win?: number; draw?: number; lose?: number; goals?: { for?: number; against?: number } };
          }>
        >;
      };
    }>;
  };

  const rawRows = payload?.response?.[0]?.league?.standings?.[0] || [];
  return rawRows.map((r, idx) => {
    const teamName = r.team?.name || `Club ${idx + 1}`;
    const desc = (r.description || '').toLowerCase();
    let zone: StandingRow['zone'];
    if (desc.includes('champions') || desc.includes('caf')) zone = 'champions';
    else if (desc.includes('confederation') || desc.includes('europa') || desc.includes('continental')) zone = 'continental';
    else if (desc.includes('relegat')) zone = 'relegation';

    const formArr = (r.form || '')
      .split('')
      .filter((c): c is 'W' | 'D' | 'L' => c === 'W' || c === 'D' || c === 'L')
      .slice(-5);

    return {
      pos: r.rank || idx + 1,
      teamId: teamName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
      teamName,
      shortName: teamName.slice(0, 3).toUpperCase(),
      color: '#10B981',
      logoUrl: r.team?.logo,
      played: r.all?.played ?? 0,
      won: r.all?.win ?? 0,
      drawn: r.all?.draw ?? 0,
      lost: r.all?.lose ?? 0,
      gf: r.all?.goals?.for ?? 0,
      ga: r.all?.goals?.against ?? 0,
      gd: r.goalsDiff ?? 0,
      pts: r.points ?? 0,
      form: formArr,
      zone,
      source: 'live',
    };
  });
}

async function fetchStandingsFromFootballData(
  leagueId: string,
  footballDataCode: string
): Promise<StandingRow[]> {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY?.trim();
  if (!apiKey) return [];

  const url = `https://api.football-data.org/v4/competitions/${encodeURIComponent(
    footballDataCode
  )}/standings`;
  const payload = await fetchJsonWithTimeout(url, {
    'X-Auth-Token': apiKey,
  });
  return parseFootballDataStandings(leagueId, payload);
}

async function fetchLeagueStandingsLive(
  leagueId: string,
  forceRefresh = false
): Promise<{
  available: boolean;
  provider: string;
  standings: StandingRow[];
  calculatedFromResults?: boolean;
  reason?: string;
}> {
  const cacheKey = `standings:${leagueId}`;
  const existingEntry = getCachedEntry<{
    available: boolean;
    provider: string;
    standings: StandingRow[];
    calculatedFromResults?: boolean;
    reason?: string;
  }>(cacheKey);
  if (existingEntry) {
    if (!forceRefresh || Date.now() - existingEntry.createdAt < MIN_FORCE_COOLDOWN_MS) {
      return existingEntry.data;
    }
  }

  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta) {
    return {
      available: false,
      provider: 'none',
      standings: [],
      reason: 'Unknown competition identifier.',
    };
  }

  return dedupeInFlight(cacheKey, async () => {
    const recentLeagueMatches = meta.espnSlug
      ? await fetchLeagueMatchesLive(leagueId, true).catch(() => [] as FootballMatch[])
      : ([] as FootballMatch[]);

    if (meta.espnSlug) {
      try {
        const payload = await fetchJsonWithTimeout(`${ESPN_STANDINGS_BASE}/${meta.espnSlug}/standings`);
        const rows = parseEspnStandings(leagueId, payload);
        if (rows.length > 0) {
          const missing = rows
            .filter((r) => !r.logoUrl)
            .map((r) => ({ key: r.teamId, name: r.teamName }));
          let enrichedRows = rows;
          if (missing.length > 0) {
            const resolved = await resolveMissingClubLogos(missing);
            enrichedRows = rows.map((r) => ({
              ...r,
              logoUrl: r.logoUrl || resolved.get(r.teamId),
            }));
          }
          enrichedRows = enrichStandingsWithResults(leagueId, enrichedRows, recentLeagueMatches);
          return setCached(
            cacheKey,
            {
              available: true,
              provider: 'ESPN Football Data Feed',
              standings: enrichedRows,
              calculatedFromResults: false,
            },
            TTL_STANDINGS_MS
          );
        }
      } catch {
        // Fall through to football-data.org / API-Football / result calculation
      }
    }

    if (meta.footballDataCode && process.env.FOOTBALL_DATA_API_KEY?.trim()) {
      try {
        const rows = await fetchStandingsFromFootballData(leagueId, meta.footballDataCode);
        if (rows.length > 0) {
          const enrichedRows = enrichStandingsWithResults(leagueId, rows, recentLeagueMatches);
          return setCached(
            cacheKey,
            {
              available: true,
              provider: 'Football-Data.org Live Feed',
              standings: enrichedRows,
              calculatedFromResults: false,
            },
            TTL_STANDINGS_MS
          );
        }
      } catch {
        // Fall through
      }
    }

    if (meta.apiFootballId && process.env.API_FOOTBALL_KEY?.trim()) {
      try {
        const rows = await fetchStandingsFromApiFootball(leagueId, meta.apiFootballId);
        if (rows.length > 0) {
          const enrichedRows = enrichStandingsWithResults(leagueId, rows, recentLeagueMatches);
          return setCached(
            cacheKey,
            {
              available: true,
              provider: 'API-Football Live Feed',
              standings: enrichedRows,
              calculatedFromResults: false,
            },
            TTL_STANDINGS_MS
          );
        }
      } catch {
        // Fall through
      }
    }

    // Automatic standings reconciliation fallback from verified completed match results
    if (recentLeagueMatches.length > 0) {
      const derivedRows = calculateStandingsFromResults(leagueId, recentLeagueMatches);
      if (derivedRows.length > 0) {
        return setCached(
          cacheKey,
          {
            available: true,
            provider: 'Calculated from Verified Match Results',
            standings: derivedRows,
            calculatedFromResults: true,
          },
          TTL_STANDINGS_MS
        );
      }
    }

    const unavailableResult = {
      available: false,
      provider: 'unavailable',
      standings: [],
      reason: `Live standings data is currently unavailable for ${meta.name} via the configured football data providers.`,
    };
    return setCached(cacheKey, unavailableResult, TTL_STANDINGS_MS);
  });
}

async function fetchAggregatedFootballNews(): Promise<NewsHeadline[]> {
  const cacheKey = 'news:aggregated';
  const cached = getCached<NewsHeadline[]>(cacheKey);
  if (cached) return cached;

  return dedupeInFlight(cacheKey, async () => {
    const sources: Array<{
      slug: string;
      leagueName: string;
      category: NewsHeadline['category'];
      region: NewsHeadline['region'];
    }> = [
      { slug: 'eng.1', leagueName: 'English Premier League', category: 'Breaking', region: 'Europe' },
      { slug: 'uefa.champions', leagueName: 'UEFA Champions League', category: 'UCL', region: 'Europe' },
      { slug: 'esp.1', leagueName: 'La Liga', category: 'Match Update', region: 'Europe' },
      { slug: 'ita.1', leagueName: 'Serie A', category: 'Serie A', region: 'Europe' },
      { slug: 'ger.1', leagueName: 'Bundesliga', category: 'Match Update', region: 'Europe' },
      { slug: 'fra.1', leagueName: 'Ligue 1', category: 'Match Update', region: 'Europe' },
      { slug: 'rsa.1', leagueName: 'Betway Premiership (PSL)', category: 'Africa', region: 'Africa' },
      { slug: 'caf.champions', leagueName: 'CAF Champions League', category: 'Africa', region: 'Africa' },
      { slug: 'nga.1', leagueName: 'Nigeria NPFL', category: 'Africa', region: 'Africa' },
      { slug: 'gha.1', leagueName: 'Ghana Premier League', category: 'Africa', region: 'Africa' },
      { slug: 'caf.nations', leagueName: 'AFCON & African Football', category: 'Africa', region: 'Africa' },
      { slug: 'uefa.nations', leagueName: 'UEFA Nations League', category: 'International', region: 'International' },
      { slug: 'fifa.world', leagueName: 'FIFA World Football', category: 'International', region: 'International' },
    ];

    const settled = await Promise.allSettled(
      sources.map((s) => fetchJsonWithTimeout(`${ESPN_BASE}/${s.slug}/news?limit=12`))
    );

    const fulfilledCount = settled.filter((r) => r.status === 'fulfilled').length;
    if (fulfilledCount === 0) {
      throw new Error('Unable to reach live sports news providers.');
    }

    const items: NewsHeadline[] = [];
    settled.forEach((res, idx) => {
      if (res.status !== 'fulfilled') return;
      const s = sources[idx]!;
      items.push(...parseEspnNews(res.value, s.leagueName, s.category, s.region));
    });

    const deduped = Array.from(new Map(items.map((i) => [i.title, i])).values()).sort((a, b) => {
      const tA = a.publishedIso ? Date.parse(a.publishedIso) : 0;
      const tB = b.publishedIso ? Date.parse(b.publishedIso) : 0;
      return tB - tA;
    });

    return setCached(cacheKey, deduped, TTL_HISTORICAL_MS);
  });
}

async function fetchLiveHeadlines(): Promise<NewsHeadline[]> {
  const articles = await fetchAggregatedFootballNews();
  return articles.slice(0, 18);
}

async function fetchLivePlayers(): Promise<PlayerStat[]> {
  const cacheKey = 'players:live';
  const cached = getCached<PlayerStat[]>(cacheKey);
  if (cached) return cached;

  return dedupeInFlight(cacheKey, async () => {
    const playerLeagueIds = ['epl', 'laliga', 'bundesliga', 'serie-a', 'ligue-1', 'ucl', 'roshn', 'sa-psl', 'mls'];
    const settled = await Promise.allSettled(
      playerLeagueIds.map(async (leagueId) => {
        const slug = LEAGUE_API_MAPPINGS[leagueId]?.espnSlug;
        if (!slug) return [] as PlayerStat[];
        const payload = await fetchJsonWithTimeout(`${ESPN_BASE}/${slug}/statistics`);
        return parseEspnLeagueLeaders(leagueId, payload);
      })
    );

    const fulfilledCount = settled.filter((r) => r.status === 'fulfilled').length;
    if (fulfilledCount === 0) {
      throw new Error('Unable to retrieve live player statistics from football providers.');
    }

    const all: PlayerStat[] = [];
    for (const r of settled) {
      if (r.status === 'fulfilled') all.push(...r.value);
    }

    const sorted = all.sort((a, b) => {
      if (b.goals !== a.goals) return b.goals - a.goals;
      if (b.assists !== a.assists) return b.assists - a.assists;
      return b.appearances - a.appearances;
    });

    const enrichedPlayers = await resolvePlayerHeadshots(sorted, 160);
    return setCached(cacheKey, enrichedPlayers, TTL_HISTORICAL_MS);
  });
}

async function fetchLeagueStats(leagueId: string): Promise<LeagueStatsApiResponse> {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta) {
    return {
      ok: true,
      available: false,
      leagueId,
      provider: 'unavailable',
      fetchedAt: new Date().toISOString(),
      topScorers: [],
      topAssists: [],
      mostAppearances: [],
      cleanSheetsAvailable: false,
      marketValuesAvailable: false,
      reason: 'Competition identifier not recognized.',
    };
  }
  if (!meta.espnSlug) {
    return {
      ok: true,
      available: false,
      leagueId,
      provider: 'unavailable',
      fetchedAt: new Date().toISOString(),
      topScorers: [],
      topAssists: [],
      mostAppearances: [],
      cleanSheetsAvailable: false,
      marketValuesAvailable: false,
      reason: `Player scoring & assist leaderboards are currently unavailable for ${meta.name} from the connected football API.`,
    };
  }

  const cacheKey = `league-stats:${leagueId}`;
  const cached = getCached<LeagueStatsApiResponse>(cacheKey);
  if (cached) return cached;

  return dedupeInFlight(cacheKey, async () => {
    const payload = await fetchJsonWithTimeout(`${ESPN_BASE}/${meta.espnSlug}/statistics`);
    const parsed = parseEspnLeagueLeaders(leagueId, payload);
    const enriched = await resolvePlayerHeadshots(parsed, 40);

    const topScorers = [...enriched]
      .filter((p) => p.goals > 0)
      .sort((a, b) => b.goals - a.goals || b.assists - a.assists)
      .slice(0, 15);
    const topAssists = [...enriched]
      .filter((p) => p.assists > 0)
      .sort((a, b) => b.assists - a.assists || b.goals - a.goals)
      .slice(0, 15);
    const mostAppearances = [...enriched]
      .filter((p) => p.appearances > 0)
      .sort((a, b) => b.appearances - a.appearances || b.goals - a.goals)
      .slice(0, 15);

    const result: LeagueStatsApiResponse = {
      ok: true,
      available: enriched.length > 0,
      leagueId,
      provider: 'ESPN Football League Statistics Feed',
      fetchedAt: new Date().toISOString(),
      topScorers,
      topAssists,
      mostAppearances,
      cleanSheetsAvailable: false,
      marketValuesAvailable: false,
      reason:
        enriched.length === 0
          ? `No player scoring or assist leaders have been published for ${meta.name} yet.`
          : undefined,
    };

    return setCached(cacheKey, result, TTL_HISTORICAL_MS);
  });
}

async function fetchLiveTransferStories(): Promise<NewsHeadline[]> {
  const cacheKey = 'transfers:live';
  const cached = getCached<NewsHeadline[]>(cacheKey);
  if (cached) return cached;

  const all = await fetchAggregatedFootballNews();
  const transferOnly = all.filter((item) => item.category === 'Transfer');
  const deduped = Array.from(new Map(transferOnly.map((i) => [i.title, i])).values());
  return setCached(cacheKey, deduped, TTL_HISTORICAL_MS);
}

const MULTI_SPORT_FEEDS: Record<
  Exclude<SportCategoryId, 'football'>,
  { path?: string; leagueLabel: string; providerLabel: string }
> = {
  basketball: { path: 'basketball/nba', leagueLabel: 'NBA Basketball', providerLabel: 'ESPN Live NBA Feed' },
  tennis: { path: 'tennis/atp', leagueLabel: 'ATP Tour Tennis', providerLabel: 'ESPN Live Tennis Feed' },
  cricket: { path: 'cricket/8048', leagueLabel: 'International Cricket', providerLabel: 'ESPNcricinfo Live Feed' },
  rugby: { path: 'rugby/270557', leagueLabel: 'International & Club Rugby', providerLabel: 'ESPN Live Rugby Feed' },
  baseball: { path: 'baseball/mlb', leagueLabel: 'MLB Baseball', providerLabel: 'ESPN Live MLB Feed' },
  hockey: { path: 'hockey/nhl', leagueLabel: 'NHL Ice Hockey', providerLabel: 'ESPN Live NHL Feed' },
  volleyball: { leagueLabel: 'International Volleyball', providerLabel: 'Unavailable' },
};

async function fetchMultiSportScoreboard(sport: Exclude<SportCategoryId, 'football'>): Promise<MultiSportApiResponse> {
  const cfg = MULTI_SPORT_FEEDS[sport];
  if (!cfg?.path) {
    return {
      ok: true,
      sport,
      available: false,
      provider: 'unavailable',
      timezone: TANZANIA_TIMEZONE,
      fetchedAt: new Date().toISOString(),
      events: [],
      reason: `Live ${sport} scoreboard feed is currently unavailable from the connected ESPN multi-sport providers.`,
    };
  }

  const cacheKey = `sport:${sport}`;
  const cached = getCached<MultiSportApiResponse>(cacheKey);
  if (cached) return cached;

  return dedupeInFlight(cacheKey, async () => {
    const payload = await fetchJsonWithTimeout(`${ESPN_SPORTS_ROOT}/${cfg.path}/scoreboard`);
    const events: MultiSportEvent[] = parseEspnMultiSportScoreboard(sport, cfg.leagueLabel, payload);
    const body: MultiSportApiResponse = {
      ok: true,
      sport,
      available: events.length > 0,
      provider: cfg.providerLabel,
      timezone: TANZANIA_TIMEZONE,
      fetchedAt: new Date().toISOString(),
      events,
      reason:
        events.length === 0
          ? `No active ${cfg.leagueLabel} fixtures or completed matches were returned in the current scoreboard window.`
          : undefined,
    };
    return setCached(cacheKey, body, TTL_LIVE_MS);
  });
}

async function buildLiveOverview(forceRefresh = false): Promise<OverviewApiResponse> {
  const cacheKey = 'overview:global';
  const existingEntry = getCachedEntry<OverviewApiResponse>(cacheKey);
  if (existingEntry) {
    if (!forceRefresh || Date.now() - existingEntry.createdAt < MIN_FORCE_COOLDOWN_MS) {
      return existingEntry.data;
    }
  }

  const warnings: string[] = [];

  // 1. Fetch matches across major world leagues + international window (including recent completed results)
  const matchLeagues = OVERVIEW_LEAGUE_IDS;
  const matchSettled = await Promise.allSettled(
    matchLeagues.map((id) => fetchLeagueMatchesLive(id, true))
  );

  let allMatches: FootballMatch[] = [];
  matchSettled.forEach((res, idx) => {
    if (res.status === 'fulfilled') {
      allMatches.push(...res.value);
    } else {
      warnings.push(`Could not refresh ${LEAGUE_API_MAPPINGS[matchLeagues[idx]!]?.name || matchLeagues[idx]}`);
    }
  });

  // Fallback check: if everything failed completely, throw 503 error
  const fulfilledCount = matchSettled.filter((r) => r.status === 'fulfilled').length;
  if (fulfilledCount === 0) {
    throw new Error('Unable to reach live football data providers. Check network connectivity or retry.');
  }

  allMatches = sortMatchesChronologically(dedupeMatches(allMatches));

  // Mark one high-priority live or marquee match as featured
  const firstLiveIdx = allMatches.findIndex((m) => m.status === 'live');
  if (firstLiveIdx >= 0) {
    allMatches[firstLiveIdx] = { ...allMatches[firstLiveIdx]!, featured: true };
  } else if (allMatches.length > 0) {
    const marqueeIdx = allMatches.findIndex((m) =>
      ['epl', 'ucl', 'laliga', 'serie-a', 'nations-league'].includes(m.leagueId)
    );
    const pick = marqueeIdx >= 0 ? marqueeIdx : 0;
    allMatches[pick] = { ...allMatches[pick]!, featured: true };
  }

  // Detect newly completed matches to immediately invalidate & recalculate standings
  const completedLeaguesSet = new Set<string>();
  for (const m of allMatches) {
    const prevStatus = previousMatchStatusById.get(m.id);
    if (prevStatus && prevStatus !== 'result' && m.status === 'result') {
      completedLeaguesSet.add(m.leagueId);
      cache.delete(`standings:${m.leagueId}`);
    }
    previousMatchStatusById.set(m.id, m.status);
  }
  const completedLeagues = Array.from(completedLeaguesSet);

  // 2. Fetch live standings for continuation tracker & authentic team profiles
  const standingsByLeague: Record<string, StandingRow[]> = {};
  const standingsSettled = await Promise.allSettled(
    CONTINUATION_LEAGUE_IDS.map(async (id) => ({
      id,
      res: await fetchLeagueStandingsLive(id, completedLeaguesSet.has(id)),
    }))
  );

  for (const s of standingsSettled) {
    if (s.status === 'fulfilled' && s.value.res.available) {
      standingsByLeague[s.value.id] = s.value.res.standings;
    }
  }

  const leaders: LeagueLeaderItem[] = [];
  for (const leagueId of CONTINUATION_LEAGUE_IDS) {
    const rows = standingsByLeague[leagueId];
    if (!rows || rows.length === 0) continue;
    const nextLeagueMatch = allMatches.find(
      (m) => m.leagueId === leagueId && (m.status === 'live' || m.status === 'upcoming')
    );
    const resumeLabel = nextLeagueMatch
      ? nextLeagueMatch.timeLabel.split('·')[0]?.trim() || 'Live Feed'
      : '2026/27 Active';
    const leader = deriveLeaderFromStandings(leagueId, rows, '2026/27', resumeLabel);
    if (leader) leaders.push(leader);
  }

  // 3. Build teams + live headlines
  const teams = buildTeamsFromStandingsAndMatches(standingsByLeague, allMatches);
  const headlines = await fetchLiveHeadlines().catch(() => []);

  const payload: OverviewApiResponse = {
    ok: true,
    provider: 'Sky Sports Secure Football Backend (ESPN Live Feed)',
    timezone: TANZANIA_TIMEZONE,
    fetchedAt: new Date().toISOString(),
    matches: allMatches,
    headlines,
    leaders,
    teams,
    completedLeagues: completedLeagues.length > 0 ? completedLeagues : undefined,
    warnings: warnings.length > 0 ? warnings : undefined,
  };

  return setCached(cacheKey, payload, TTL_LIVE_MS);
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      service: 'sky-sports-backend',
      timezone: TANZANIA_TIMEZONE,
      timestamp: new Date().toISOString(),
      configuredKeys: {
        apiFootball: Boolean(process.env.API_FOOTBALL_KEY?.trim()),
        footballData: Boolean(process.env.FOOTBALL_DATA_API_KEY?.trim()),
      },
    });
  });

  app.get('/api/football/overview', async (req, res) => {
    if (req.query.simulateError === '1') {
      res.status(503).json({
        ok: false,
        error: 'Live football data feed is temporarily unavailable (upstream timeout). Please retry.',
      });
      return;
    }
    try {
      const force = req.query.refresh === '1';
      const data = await buildLiveOverview(force);
      res.json(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve live football data.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/league/:leagueId', async (req, res) => {
    const { leagueId } = req.params;
    const meta = LEAGUE_API_MAPPINGS[leagueId];
    if (!meta) {
      res.status(404).json({ ok: false, error: 'Competition not found.' });
      return;
    }
    if (!meta.espnSlug) {
      res.json({
        ok: true,
        available: false,
        leagueId,
        matches: [],
        reason: `Live fixture API is not available for ${meta.name}.`,
      });
      return;
    }
    try {
      const matches = await fetchLeagueMatchesLive(leagueId, true);
      res.json({
        ok: true,
        available: true,
        leagueId,
        fetchedAt: new Date().toISOString(),
        matches,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch league matches.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/standings/:leagueId', async (req, res) => {
    const { leagueId } = req.params;
    try {
      const force = req.query.refresh === '1';
      const result = await fetchLeagueStandingsLive(leagueId, force);
      const responseBody: StandingsApiResponse = {
        ok: true,
        available: result.available,
        leagueId,
        provider: result.provider,
        fetchedAt: new Date().toISOString(),
        standings: result.standings,
        calculatedFromResults: result.calculatedFromResults,
        reason: result.reason,
      };
      res.json(responseBody);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to fetch league standings.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/league-stats/:leagueId', async (req, res) => {
    const { leagueId } = req.params;
    try {
      const body = await fetchLeagueStats(leagueId);
      res.json(body);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve league statistics.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/match/:leagueId/:eventId', async (req, res) => {
    const { leagueId, eventId } = req.params;
    const meta = LEAGUE_API_MAPPINGS[leagueId];
    if (!meta?.espnSlug) {
      res.status(404).json({ ok: false, error: 'Live match center feed is unavailable for this competition.' });
      return;
    }
    const cacheKey = `summary:${leagueId}:${eventId}`;
    const force = req.query.refresh === '1';
    if (!force) {
      const cached = getCached<FootballMatch>(cacheKey);
      if (cached) {
        res.json({ ok: true, match: cached });
        return;
      }
    }

    try {
      const [leagueMatches, summaryPayload] = await Promise.all([
        fetchLeagueMatchesLive(leagueId, true).catch(() => [] as FootballMatch[]),
        fetchJsonWithTimeout(`${ESPN_BASE}/${meta.espnSlug}/summary?event=${encodeURIComponent(eventId)}`),
      ]);

      const base =
        leagueMatches.find((m) => m.externalEventId === eventId) ||
        parseEspnScoreboard(leagueId, { leagues: [{ calendar: [] }], events: [] }).matches[0] || {
          id: `espn-${leagueId}-${eventId}`,
          externalEventId: eventId,
          leagueId,
          league: meta.name,
          country: meta.country,
          region: meta.region,
          round: '2026/27',
          status: 'live' as const,
          timeLabel: 'Match Center',
          venue: meta.country,
          homeTeamId: 'home',
          awayTeamId: 'away',
          homeTeam: 'Home',
          awayTeam: 'Away',
          homeShort: 'HOM',
          awayShort: 'AWY',
          homeColor: '#10B981',
          awayColor: '#F59E0B',
          source: 'live' as const,
          events: [],
          stats: emptyStats(),
          homeLineup: [],
          awayLineup: [],
        };

      const enriched = parseEspnSummary(base, summaryPayload);
      if (!enriched.homeLogo || !enriched.awayLogo) {
        const missing: Array<{ key: string; name: string }> = [];
        if (!enriched.homeLogo) missing.push({ key: enriched.homeTeamId, name: enriched.homeTeam });
        if (!enriched.awayLogo) missing.push({ key: enriched.awayTeamId, name: enriched.awayTeam });
        const resolved = await resolveMissingClubLogos(missing);
        enriched.homeLogo = enriched.homeLogo || resolved.get(enriched.homeTeamId);
        enriched.awayLogo = enriched.awayLogo || resolved.get(enriched.awayTeamId);
      }
      setCached(cacheKey, enriched, 20_000);
      res.json({ ok: true, match: enriched });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to load match summary.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/players', async (_req, res) => {
    try {
      const players = await fetchLivePlayers();
      const body: PlayersApiResponse = {
        ok: true,
        available: players.length > 0,
        provider: 'ESPN Football Player Statistics Feed',
        fetchedAt: new Date().toISOString(),
        players,
        reason: players.length === 0 ? 'No live player leader records returned right now.' : undefined,
      };
      res.json(body);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve live player statistics.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/team/:leagueId/:externalTeamId', async (req, res) => {
    const { leagueId, externalTeamId } = req.params;
    const meta = LEAGUE_API_MAPPINGS[leagueId];
    if (!meta?.espnSlug) {
      const unavailable: TeamDetailApiResponse = {
        ok: true,
        available: false,
        provider: 'unavailable',
        fetchedAt: new Date().toISOString(),
        team: null,
        squad: [],
        matches: [],
        reason: `Live squad and club profile API is currently unavailable for ${meta?.name || leagueId}.`,
      };
      res.json(unavailable);
      return;
    }

    const cacheKey = `team-detail:${leagueId}:${externalTeamId}`;
    const cached = getCached<TeamDetailApiResponse>(cacheKey);
    if (cached) {
      res.json(cached);
      return;
    }

    try {
      const [teamRes, rosterRes, matchesRes] = await Promise.allSettled([
        fetchJsonWithTimeout(`${ESPN_BASE}/${meta.espnSlug}/teams/${encodeURIComponent(externalTeamId)}`),
        fetchJsonWithTimeout(`${ESPN_BASE}/${meta.espnSlug}/teams/${encodeURIComponent(externalTeamId)}/roster`),
        fetchLeagueMatchesLive(leagueId, true),
      ]);

      const teamPayload = teamRes.status === 'fulfilled' ? teamRes.value : {};
      const rosterPayload = rosterRes.status === 'fulfilled' ? rosterRes.value : {};
      const parsed = parseEspnTeamDetailAndRoster(leagueId, externalTeamId, teamPayload, rosterPayload);

      let team = parsed.team;
      if (team && !team.logoUrl) {
        const resolvedLogos = await resolveMissingClubLogos([{ key: team.id, name: team.name }]);
        const logoUrl = resolvedLogos.get(team.id);
        if (logoUrl) {
          team = { ...team, logoUrl };
        }
      }

      const squadWithPhotos = await resolvePlayerHeadshots(
        parsed.squad.map((p) => ({ ...p, clubLogoUrl: p.clubLogoUrl || team?.logoUrl })),
        60
      );

      const leagueMatches = matchesRes.status === 'fulfilled' ? matchesRes.value : [];
      const teamMatches = leagueMatches.filter(
        (m) =>
          m.homeExternalTeamId === externalTeamId ||
          m.awayExternalTeamId === externalTeamId ||
          (team && (m.homeTeamId === team.id || m.awayTeamId === team.id))
      );

      const responseBody: TeamDetailApiResponse = {
        ok: true,
        available: Boolean(team),
        provider: 'ESPN Football Club & Roster API',
        fetchedAt: new Date().toISOString(),
        team,
        squad: squadWithPhotos,
        matches: teamMatches,
        reason: team ? undefined : 'Club roster and profile data unavailable from upstream provider.',
      };
      setCached(cacheKey, responseBody, 90_000);
      res.json(responseBody);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve club profile.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/transfers', async (_req, res) => {
    try {
      const stories = await fetchLiveTransferStories();
      const body: TransfersApiResponse = {
        ok: true,
        available: stories.length > 0,
        provider: 'ESPN Live Football Transfer Wire',
        timezone: TANZANIA_TIMEZONE,
        fetchedAt: new Date().toISOString(),
        stories,
        reason:
          stories.length === 0
            ? 'No active transfer stories were reported in the latest football news wire.'
            : undefined,
      };
      res.json(body);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve live transfer news.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/football/news', async (_req, res) => {
    try {
      const articles = await fetchAggregatedFootballNews();
      const body: NewsApiResponse = {
        ok: true,
        available: articles.length > 0,
        provider: 'ESPN Global & African Football News Wire',
        timezone: TANZANIA_TIMEZONE,
        fetchedAt: new Date().toISOString(),
        articles,
        reason:
          articles.length === 0
            ? 'No verified news articles were returned by the live news providers.'
            : undefined,
      };
      res.json(body);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to retrieve live sports news.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  app.get('/api/sports/:sport', async (req, res) => {
    const sportParam = req.params.sport as SportCategoryId;
    if (sportParam === 'football') {
      res.redirect(307, '/api/football/overview');
      return;
    }
    if (!(sportParam in MULTI_SPORT_FEEDS)) {
      res.status(404).json({ ok: false, error: 'Unsupported sport category.' });
      return;
    }
    try {
      const data = await fetchMultiSportScoreboard(sportParam);
      res.json(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to fetch multi-sport scoreboard.';
      res.status(503).json({ ok: false, error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.use(async (req, res, next) => {
      if (req.originalUrl.startsWith('/api/')) {
        next();
        return;
      }
      try {
        const indexPath = path.resolve(process.cwd(), 'index.html');
        const template = fs.readFileSync(indexPath, 'utf-8');
        const html = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (err) {
        vite.ssrFixStacktrace(err as Error);
        next(err);
      }
    });
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.use((_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`SKY SPORTS server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start SKY SPORTS server:', err);
  process.exit(1);
});
