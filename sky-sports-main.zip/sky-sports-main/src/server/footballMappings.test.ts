import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildClubWikipediaCandidates,
  buildTeamsFromStandingsAndMatches,
  calculateStandingsFromResults,
  deriveLeaderFromStandings,
  enrichStandingsWithResults,
  extractCompStats,
  extractWikipediaInfoboxLogoFile,
  formatKickoffLabel,
  parseEspnHeadToHead,
  parseEspnLeagueLeaders,
  parseEspnMultiSportScoreboard,
  parseEspnNews,
  parseEspnScoreboard,
  parseEspnStandings,
  parseEspnSummary,
  parseEspnTeamDetailAndRoster,
  parseFootballDataStandings,
  parseWikipediaImageInfoUrls,
  parseWikipediaPortraitMap,
} from './footballMappings';

test('formatKickoffLabel formats live minutes, completed matches, and scheduled Tanzania EAT kickoffs', () => {
  assert.equal(formatKickoffLabel('2026-11-17T19:45Z', 'in', "64'", '64'), "Live · 64'");
  assert.equal(formatKickoffLabel('2026-11-17T19:45Z', 'in', 'HT', 'HT'), 'Live · HT');
  assert.equal(formatKickoffLabel('2026-11-16T19:45Z', 'post', 'FT', '90'), 'FT · Nov 16');
  const pre = formatKickoffLabel('2026-11-21T15:00Z', 'pre', '');
  assert.ok(pre.includes('Nov 21') && pre.includes('18:00 EAT'));
});

test('parseEspnScoreboard extracts live, upcoming, and result matches with logos and scorers', () => {
  const samplePayload = {
    leagues: [
      {
        season: { displayName: '2026-27 English Premier League' },
        calendar: ['2026-11-08T08:00Z', '2026-11-21T08:00Z'],
      },
    ],
    events: [
      {
        id: '704201',
        date: '2026-11-17T19:45Z',
        competitions: [
          {
            date: '2026-11-17T19:45Z',
            venue: { fullName: 'Emirates Stadium' },
            status: {
              displayClock: '64',
              type: { state: 'in', shortDetail: "64'" },
            },
            competitors: [
              {
                homeAway: 'home',
                score: '2',
                team: {
                  id: '359',
                  displayName: 'Arsenal',
                  abbreviation: 'ARS',
                  color: 'ef0107',
                  logo: 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png',
                },
                statistics: [
                  { name: 'possessionPct', displayValue: '58.0' },
                  { name: 'totalShots', displayValue: '15' },
                  { name: 'shotsOnTarget', displayValue: '7' },
                  { name: 'wonCorners', displayValue: '6' },
                ],
              },
              {
                homeAway: 'away',
                score: '1',
                team: {
                  id: '363',
                  displayName: 'Chelsea',
                  abbreviation: 'CHE',
                  color: '034694',
                  logo: 'https://a.espncdn.com/i/teamlogos/soccer/500/363.png',
                },
                statistics: [
                  { name: 'possessionPct', displayValue: '42.0' },
                  { name: 'totalShots', displayValue: '9' },
                  { name: 'shotsOnTarget', displayValue: '3' },
                  { name: 'wonCorners', displayValue: '3' },
                ],
              },
            ],
            details: [
              {
                scoringPlay: true,
                clock: { displayValue: "22'" },
                team: { id: '359' },
                athletesInvolved: [{ displayName: 'Bukayo Saka' }],
                type: { text: 'Goal' },
              },
              {
                yellowCard: true,
                clock: { displayValue: "51'" },
                team: { id: '363' },
                athletesInvolved: [{ displayName: 'Moisés Caicedo' }],
                type: { text: 'Yellow Card' },
              },
            ],
          },
        ],
      },
      {
        id: '704202',
        date: '2026-11-22T16:30Z',
        competitions: [
          {
            date: '2026-11-22T16:30Z',
            venue: { fullName: 'Anfield' },
            status: { type: { state: 'pre', shortDetail: 'Scheduled' } },
            competitors: [
              {
                homeAway: 'home',
                team: {
                  id: '364',
                  displayName: 'Liverpool',
                  abbreviation: 'LIV',
                  color: 'c8102e',
                  logo: 'https://a.espncdn.com/i/teamlogos/soccer/500/364.png',
                },
              },
              {
                homeAway: 'away',
                team: {
                  id: '382',
                  displayName: 'Manchester City',
                  abbreviation: 'MCI',
                  color: '6cabdd',
                  logo: 'https://a.espncdn.com/i/teamlogos/soccer/500/382.png',
                },
              },
            ],
          },
        ],
      },
    ],
  };

  const parsed = parseEspnScoreboard('epl', samplePayload);
  assert.equal(parsed.matches.length, 2);

  const liveMatch = parsed.matches[0];
  assert.equal(liveMatch?.status, 'live');
  assert.equal(liveMatch?.source, 'live');
  assert.equal(liveMatch?.homeScore, 2);
  assert.equal(liveMatch?.awayScore, 1);
  assert.equal(liveMatch?.homeLogo, 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png');
  assert.equal(liveMatch?.events.length, 2);
  assert.equal(liveMatch?.events[0]?.player, 'Bukayo Saka');
  assert.equal(liveMatch?.events[1]?.team, 'away');
  assert.equal(liveMatch?.stats.possessionHome, 58);

  const upcomingMatch = parsed.matches[1];
  assert.equal(upcomingMatch?.status, 'upcoming');
  assert.equal(upcomingMatch?.homeScore, undefined);
  assert.equal(upcomingMatch?.awayScore, undefined);
});

test('parseEspnStandings parses entries with PNG logos, zones, and derives leaders/teams', () => {
  const payload = {
    children: [
      {
        standings: {
          entries: [
            {
              team: {
                id: '359',
                displayName: 'Arsenal',
                abbreviation: 'ARS',
                color: 'ef0107',
                logos: [{ href: 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png' }],
              },
              note: { description: 'Champions League' },
              stats: [
                { name: 'rank', value: 1 },
                { name: 'gamesPlayed', value: 11 },
                { name: 'wins', value: 9 },
                { name: 'ties', value: 1 },
                { name: 'losses', value: 1 },
                { name: 'pointsFor', value: 26 },
                { name: 'pointsAgainst', value: 7 },
                { name: 'pointDifferential', value: 19 },
                { name: 'points', value: 28 },
              ],
            },
          ],
        },
      },
    ],
  };

  const rows = parseEspnStandings('epl', payload);
  assert.equal(rows.length, 1);
  assert.equal(rows[0]?.pos, 1);
  assert.equal(rows[0]?.pts, 28);
  assert.equal(rows[0]?.zone, 'champions');
  assert.equal(rows[0]?.logoUrl, 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png');
  assert.equal(rows[0]?.source, 'live');

  const leader = deriveLeaderFromStandings('epl', rows, '2026/27', 'Next: Nov 21');
  assert.equal(leader?.leaderName, 'Arsenal');
  assert.equal(leader?.ptsLabel, '28 pts (11P)');

  const teams = buildTeamsFromStandingsAndMatches({ epl: rows }, []);
  assert.equal(teams.length, 1);
  assert.equal(teams[0]?.logoUrl, 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png');
});

test('parseEspnSummary and parseEspnNews enrich match details and live news', () => {
  const baseMatch = parseEspnScoreboard('epl', {
    leagues: [{ season: { displayName: '2026/27' }, calendar: [] }],
    events: [
      {
        id: '704201',
        date: '2026-11-17T19:45Z',
        competitions: [
          {
            date: '2026-11-17T19:45Z',
            status: { type: { state: 'post', shortDetail: 'FT' } },
            competitors: [
              { homeAway: 'home', score: '1', team: { id: '1', displayName: 'Wales', abbreviation: 'WAL' } },
              { homeAway: 'away', score: '2', team: { id: '2', displayName: 'Portugal', abbreviation: 'POR' } },
            ],
          },
        ],
      },
    ],
  }).matches[0]!;

  const summary = parseEspnSummary(baseMatch, {
    header: {
      competitions: [
        {
          competitors: [
            { homeAway: 'home', team: { id: '1' } },
            { homeAway: 'away', team: { id: '2' } },
          ],
        },
      ],
    },
    keyEvents: [
      {
        scoringPlay: true,
        clock: { displayValue: "78'" },
        team: { id: '2' },
        participants: [{ athlete: { displayName: 'Cristiano Ronaldo' } }],
        type: { text: 'Goal' },
      },
    ],
    rosters: [
      { team: { id: '1' }, roster: [{ starter: true, athlete: { displayName: 'Danny Ward' } }] },
      { team: { id: '2' }, roster: [{ starter: true, athlete: { displayName: 'Diogo Costa' } }] },
    ],
  });

  assert.equal(summary.events[0]?.player, 'Cristiano Ronaldo');
  assert.equal(summary.events[0]?.team, 'away');
  assert.deepEqual(summary.homeLineup, ['Danny Ward']);
  assert.deepEqual(summary.awayLineup, ['Diogo Costa']);

  const news = parseEspnNews(
    {
      articles: [
        {
          id: 'n1',
          headline: 'Arsenal complete midfield signing ahead of winter window',
          description: 'Official club announcement confirmed.',
          published: new Date(Date.now() - 3600000).toISOString(),
          links: { web: { href: 'https://www.espn.com/soccer' } },
        },
      ],
    },
    'English Premier League',
    'Breaking'
  );
  assert.equal(news.length, 1);
  assert.equal(news[0]?.category, 'Transfer');
  assert.equal(news[0]?.source, 'live');
});

test('parseEspnLeagueLeaders merges goals and assists leaders with club crests', () => {
  const payload = {
    stats: [
      {
        name: 'goalsLeaders',
        leaders: [
          {
            athlete: {
              id: '201',
              displayName: 'Erling Haaland',
              team: {
                id: '382',
                displayName: 'Manchester City',
                abbreviation: 'MCI',
                color: '6cabdd',
                logos: [{ href: 'https://a.espncdn.com/i/teamlogos/soccer/500/382.png' }],
              },
              statistics: [
                { name: 'appearances', value: 11 },
                { name: 'totalGoals', value: 12 },
                { name: 'goalAssists', value: 1 },
              ],
            },
          },
        ],
      },
      {
        name: 'assistsLeaders',
        leaders: [
          {
            athlete: {
              id: '201',
              displayName: 'Erling Haaland',
              team: {
                id: '382',
                displayName: 'Manchester City',
                abbreviation: 'MCI',
              },
              statistics: [
                { name: 'appearances', value: 11 },
                { name: 'totalGoals', value: 12 },
                { name: 'goalAssists', value: 2 },
              ],
            },
          },
        ],
      },
    ],
  };

  const leaders = parseEspnLeagueLeaders('epl', payload);
  assert.equal(leaders.length, 1);
  assert.equal(leaders[0]?.name, 'Erling Haaland');
  assert.equal(leaders[0]?.goals, 12);
  assert.equal(leaders[0]?.assists, 2);
  assert.equal(leaders[0]?.clubLogoUrl, 'https://a.espncdn.com/i/teamlogos/soccer/500/382.png');
  assert.equal(leaders[0]?.rating, null);
});

test('parseEspnTeamDetailAndRoster extracts club summary, stadium, and squad roster stats', () => {
  const teamPayload = {
    team: {
      id: '359',
      displayName: 'Arsenal',
      abbreviation: 'ARS',
      color: 'ef0107',
      standingSummary: '1st in English Premier League',
      record: { items: [{ summary: '9-1-1' }] },
      venue: { fullName: 'Emirates Stadium' },
      logos: [{ href: 'https://a.espncdn.com/i/teamlogos/soccer/500/359.png' }],
    },
  };
  const rosterPayload = {
    team: { id: '359', displayName: 'Arsenal', abbreviation: 'ARS' },
    athletes: [
      {
        id: '900',
        displayName: 'David Raya',
        jersey: '22',
        age: 31,
        citizenship: 'Spain',
        position: { abbreviation: 'G' },
        statistics: {
          splits: {
            categories: [
              { stats: [{ name: 'appearances', value: 11 }] },
              { stats: [{ name: 'saves', value: 34 }] },
            ],
          },
        },
      },
      {
        id: '901',
        displayName: 'Bukayo Saka',
        jersey: '7',
        age: 25,
        citizenship: 'England',
        position: { abbreviation: 'F' },
        statistics: {
          splits: {
            categories: [
              { stats: [{ name: 'appearances', value: 11 }, { name: 'yellowCards', value: 2 }] },
              { stats: [{ name: 'totalGoals', value: 6 }, { name: 'goalAssists', value: 7 }, { name: 'shotsOnTarget', value: 18 }] },
            ],
          },
        },
      },
    ],
  };

  const { team, squad } = parseEspnTeamDetailAndRoster('epl', '359', teamPayload, rosterPayload);
  assert.equal(team?.name, 'Arsenal');
  assert.equal(team?.leaguePosition, 1);
  assert.equal(team?.stadium, 'Emirates Stadium');
  assert.equal(team?.recordSummary, '9-1-1');
  assert.equal(squad.length, 2);
  assert.equal(squad[0]?.name, 'Bukayo Saka');
  assert.equal(squad[0]?.goals, 6);
  assert.equal(squad[1]?.position, 'GK');
  assert.equal(squad[1]?.saves, 34);
});

test('extractCompStats returns null metrics and statsAvailable=false when API omits stats', () => {
  const missing = extractCompStats({}, {});
  assert.equal(missing.statsAvailable, false);
  assert.equal(missing.possessionHome, null);
  assert.equal(missing.shotsHome, null);
  assert.equal(missing.cornersHome, null);

  const partial = extractCompStats(
    { statistics: [{ name: 'possessionPct', displayValue: '62.4' }, { name: 'wonCorners', displayValue: '7' }] },
    { statistics: [{ name: 'possessionPct', displayValue: '37.6' }, { name: 'wonCorners', displayValue: '2' }] }
  );
  assert.equal(partial.statsAvailable, true);
  assert.equal(partial.possessionHome, 62);
  assert.equal(partial.cornersAway, 2);
  assert.equal(partial.xgHome, null);
});

test('Wikipedia crest and player portrait parsers extract verified Wikimedia URLs cleanly', () => {
  const candidates = buildClubWikipediaCandidates('Young Africans');
  assert.equal(candidates[0], 'Young Africans S.C.');

  const logoFile = extractWikipediaInfoboxLogoFile(`
{{Infobox football club
| clubname = Young Africans
| image = [[File:Young Africans S.C. logo.png|180px]]
}}`);
  assert.equal(logoFile, 'File:Young Africans S.C. logo.png');

  const urls = parseWikipediaImageInfoUrls({
    query: {
      pages: {
        '101': {
          title: 'File:Young Africans S.C. logo.png',
          imageinfo: [{ thumburl: 'https://upload.wikimedia.org/wikipedia/en/thumb/yanga.png' }],
        },
      },
    },
  });
  assert.equal(
    urls['File:Young Africans S.C. logo.png'],
    'https://upload.wikimedia.org/wikipedia/en/thumb/yanga.png'
  );

  const portraits = parseWikipediaPortraitMap({
    query: {
      normalized: [{ from: 'Erling_Haaland', to: 'Erling Haaland' }],
      pages: {
        '202': {
          title: 'Erling Haaland',
          thumbnail: { source: 'https://upload.wikimedia.org/wikipedia/commons/thumb/haaland.jpg' },
        },
      },
    },
  });
  assert.equal(
    portraits['erling haaland'],
    'https://upload.wikimedia.org/wikipedia/commons/thumb/haaland.jpg'
  );
});

test('parseEspnHeadToHead & Substitution keyEvents enrich Match Center cleanly', () => {
  const baseMatch = parseEspnScoreboard('epl', {
    leagues: [{ season: { displayName: '2026/27' }, calendar: [] }],
    events: [
      {
        id: '704209',
        date: '2026-11-17T19:45Z',
        competitions: [
          {
            date: '2026-11-17T19:45Z',
            status: { type: { state: 'post', shortDetail: 'FT' } },
            competitors: [
              { homeAway: 'home', score: '2', team: { id: '359', displayName: 'Arsenal', abbreviation: 'ARS' } },
              { homeAway: 'away', score: '1', team: { id: '363', displayName: 'Chelsea', abbreviation: 'CHE' } },
            ],
          },
        ],
      },
    ],
  }).matches[0]!;

  const summary = parseEspnSummary(baseMatch, {
    header: {
      competitions: [
        {
          competitors: [
            { homeAway: 'home', team: { id: '359' } },
            { homeAway: 'away', team: { id: '363' } },
          ],
        },
      ],
    },
    keyEvents: [
      {
        clock: { displayValue: "68'" },
        team: { id: '359' },
        participants: [{ athlete: { displayName: 'Gabriel Martinelli' } }],
        type: { text: 'Substitution' },
        text: 'Leandro Trossard replaces Gabriel Martinelli',
      },
    ],
    seasonseries: [
      {
        type: 'head-to-head',
        title: 'Head-to-Head',
        summary: 'Arsenal leads 3-1-1',
        events: [
          {
            id: 'h1',
            date: '2026-03-01T16:30Z',
            competitionName: 'English Premier League',
            competitors: [
              { homeAway: 'home', score: '1', team: { displayName: 'Chelsea', abbreviation: 'CHE' } },
              { homeAway: 'away', score: '2', team: { displayName: 'Arsenal', abbreviation: 'ARS' } },
            ],
          },
          {
            id: 'h2',
            date: '2025-10-12T14:00Z',
            competitionName: 'English Premier League',
            competitors: [
              { homeAway: 'home', score: '1', team: { displayName: 'Arsenal', abbreviation: 'ARS' } },
              { homeAway: 'away', score: '1', team: { displayName: 'Chelsea', abbreviation: 'CHE' } },
            ],
          },
        ],
      },
    ],
  });

  assert.equal(summary.events[0]?.type, 'sub');
  assert.equal(summary.events[0]?.player, 'Gabriel Martinelli');
  assert.ok(summary.headToHead);
  assert.equal(summary.headToHead?.matches.length, 2);
  assert.equal(summary.headToHead?.matches[0]?.winnerSide, 'away');
  assert.equal(summary.headToHead?.matches[1]?.winnerSide, 'draw');
  assert.equal(parseEspnHeadToHead({}), undefined);
});

test('parseEspnNews classifies Africa, Tanzania, Injury, Manager, and Transfer badges with EAT timestamps', () => {
  const items = parseEspnNews(
    {
      articles: [
        {
          id: 't1',
          headline: 'Young Africans and Simba chase Tanzanian title race',
          description: 'Taifa Stars midfielders impress in Dar es Salaam.',
          published: '2026-11-17T12:00Z',
          images: [{ url: 'https://a.espncdn.com/photo/yanga.jpg' }],
          links: { web: { href: 'https://www.espn.com/soccer/story/1' } },
        },
        {
          id: 't2',
          headline: 'Liverpool complete loan signing of defender',
          description: 'Official season-long loan deal confirmed.',
          published: '2026-11-17T11:00Z',
          links: { web: { href: 'https://www.espn.com/soccer/story/2' } },
        },
        {
          id: 't3',
          headline: 'Star striker ruled out with hamstring injury',
          description: 'Expected to miss three weeks after surgery.',
          published: '2026-11-17T10:00Z',
        },
        {
          id: 't4',
          headline: 'Club confirms new head coach appointment',
          description: 'Manager signs two-year contract.',
          published: '2026-11-17T09:00Z',
        },
      ],
    },
    'CAF Champions League',
    'Breaking',
    'Africa'
  );

  assert.equal(items.length, 4);
  assert.equal(items[0]?.category, 'Tanzania');
  assert.equal(items[0]?.imageUrl, 'https://a.espncdn.com/photo/yanga.jpg');
  assert.ok(items[0]?.publishedEatLabel?.includes('EAT'));
  assert.equal(items[1]?.category, 'Transfer');
  assert.equal(items[1]?.transferStatus, 'Loan');
  assert.equal(items[2]?.category, 'Injury');
  assert.equal(items[3]?.category, 'Manager');
});

test('calculateStandingsFromResults, enrichStandingsWithResults, parseFootballDataStandings, and multi-sport parser', () => {
  const scoreboard = parseEspnScoreboard('epl', {
    leagues: [{ season: { displayName: '2026/27' }, calendar: [] }],
    events: [
      {
        id: 'm1',
        date: '2026-11-16T15:00Z',
        competitions: [
          {
            date: '2026-11-16T15:00Z',
            status: { type: { state: 'post', shortDetail: 'FT' } },
            competitors: [
              { homeAway: 'home', score: '3', team: { id: '359', displayName: 'Arsenal', abbreviation: 'ARS' } },
              { homeAway: 'away', score: '1', team: { id: '363', displayName: 'Chelsea', abbreviation: 'CHE' } },
            ],
          },
        ],
      },
    ],
  });

  const calculated = calculateStandingsFromResults('epl', scoreboard.matches);
  assert.equal(calculated.length, 2);
  assert.equal(calculated[0]?.teamName, 'Arsenal');
  assert.equal(calculated[0]?.pts, 3);
  assert.equal(calculated[0]?.gd, 2);
  assert.deepEqual(calculated[0]?.form, ['W']);
  assert.deepEqual(calculated[1]?.form, ['L']);

  const officialMissingForm = parseFootballDataStandings('epl', {
    standings: [
      {
        type: 'TOTAL',
        table: [
          {
            position: 1,
            playedGames: 10,
            won: 8,
            draw: 1,
            lost: 1,
            goalsFor: 22,
            goalsAgainst: 8,
            goalDifference: 14,
            points: 25,
            form: '',
            team: { id: 57, name: 'Arsenal', tla: 'ARS', crest: 'https://crests.football-data.org/57.png' },
          },
        ],
      },
    ],
  });
  assert.equal(officialMissingForm.length, 1);
  assert.equal(officialMissingForm[0]?.logoUrl, 'https://crests.football-data.org/57.png');

  const enriched = enrichStandingsWithResults('epl', officialMissingForm, scoreboard.matches);
  assert.deepEqual(enriched[0]?.form, ['W']);

  const nbaEvents = parseEspnMultiSportScoreboard('basketball', 'NBA', {
    events: [
      {
        id: 'nba1',
        date: '2026-11-18T01:00Z',
        competitions: [
          {
            date: '2026-11-18T01:00Z',
            venue: { fullName: 'TD Garden' },
            status: { displayClock: '4:12', type: { state: 'in', shortDetail: '4:12 - 3rd' } },
            competitors: [
              { homeAway: 'home', score: '88', team: { displayName: 'Boston Celtics', abbreviation: 'BOS', logo: 'https://a.espncdn.com/bos.png' } },
              { homeAway: 'away', score: '84', team: { displayName: 'Miami Heat', abbreviation: 'MIA', logo: 'https://a.espncdn.com/mia.png' } },
            ],
          },
        ],
      },
    ],
  });
  assert.equal(nbaEvents.length, 1);
  assert.equal(nbaEvents[0]?.status, 'live');
  assert.equal(nbaEvents[0]?.homeScore, '88');
  assert.equal(nbaEvents[0]?.awayScore, '84');
});



