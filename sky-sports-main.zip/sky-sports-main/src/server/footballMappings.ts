import type {
  FootballMatch,
  HeadToHeadMatch,
  HeadToHeadSummary,
  LeagueLeaderItem,
  MatchEvent,
  MatchStats,
  MatchStatus,
  MultiSportEvent,
  NewsCategory,
  NewsHeadline,
  PlayerPosition,
  PlayerStat,
  RegionId,
  SportCategoryId,
  StandingRow,
  TeamProfile,
  TransferDealClassification,
} from '../types/football';

export const TANZANIA_TIMEZONE = 'Africa/Dar_es_Salaam';

export interface LeagueApiMapping {
  leagueId: string;
  name: string;
  shortName: string;
  country: string;
  region: Exclude<RegionId, 'all'>;
  espnSlug?: string;
  apiFootballId?: number;
  footballDataCode?: string;
  liveSupported: boolean;
}

export const LEAGUE_API_MAPPINGS: Record<string, LeagueApiMapping> = {
  epl: { leagueId: 'epl', name: 'English Premier League', shortName: 'EPL', country: 'England', region: 'Europe', espnSlug: 'eng.1', footballDataCode: 'PL', apiFootballId: 39, liveSupported: true },
  ucl: { leagueId: 'ucl', name: 'UEFA Champions League', shortName: 'UCL', country: 'Europe', region: 'Europe', espnSlug: 'uefa.champions', footballDataCode: 'CL', apiFootballId: 2, liveSupported: true },
  laliga: { leagueId: 'laliga', name: 'La Liga', shortName: 'LAL', country: 'Spain', region: 'Europe', espnSlug: 'esp.1', footballDataCode: 'PD', apiFootballId: 140, liveSupported: true },
  bundesliga: { leagueId: 'bundesliga', name: 'Bundesliga', shortName: 'BUN', country: 'Germany', region: 'Europe', espnSlug: 'ger.1', footballDataCode: 'BL1', apiFootballId: 78, liveSupported: true },
  'serie-a': { leagueId: 'serie-a', name: 'Serie A', shortName: 'SER', country: 'Italy', region: 'Europe', espnSlug: 'ita.1', footballDataCode: 'SA', apiFootballId: 135, liveSupported: true },
  roshn: { leagueId: 'roshn', name: 'Roshn Saudi League', shortName: 'RSL', country: 'Saudi Arabia', region: 'Asia & Middle East', espnSlug: 'ksa.1', apiFootballId: 307, liveSupported: true },

  // Africa
  'sa-psl': { leagueId: 'sa-psl', name: 'Betway Premiership (PSL)', shortName: 'PSL', country: 'South Africa', region: 'Africa', espnSlug: 'rsa.1', apiFootballId: 288, liveSupported: true },
  'tanzania-nbc': { leagueId: 'tanzania-nbc', name: 'NBC Premier League', shortName: 'NBC', country: 'Tanzania', region: 'Africa', apiFootballId: 567, liveSupported: false },
  'kenya-fkf': { leagueId: 'kenya-fkf', name: 'FKF Premier League', shortName: 'FKF', country: 'Kenya', region: 'Africa', espnSlug: 'ken.1', apiFootballId: 276, liveSupported: true },
  'uganda-upl': { leagueId: 'uganda-upl', name: 'Uganda Premier League', shortName: 'UPL', country: 'Uganda', region: 'Africa', espnSlug: 'uga.1', apiFootballId: 585, liveSupported: true },
  'caf-cl': { leagueId: 'caf-cl', name: 'CAF Champions League', shortName: 'CAF', country: 'Africa', region: 'Africa', espnSlug: 'caf.champions', apiFootballId: 12, liveSupported: true },
  'caf-confed': { leagueId: 'caf-confed', name: 'CAF Confederation Cup', shortName: 'CCC', country: 'Africa', region: 'Africa', espnSlug: 'caf.confed', apiFootballId: 20, liveSupported: true },
  'zambia-super': { leagueId: 'zambia-super', name: 'Zambia Super League', shortName: 'ZSL', country: 'Zambia', region: 'Africa', espnSlug: 'zam.1', apiFootballId: 400, liveSupported: true },
  'zim-psl': { leagueId: 'zim-psl', name: 'Zimbabwe PSL', shortName: 'ZIM', country: 'Zimbabwe', region: 'Africa', espnSlug: 'zim.1', apiFootballId: 401, liveSupported: true },
  'egypt-pl': { leagueId: 'egypt-pl', name: 'Egyptian Premier League', shortName: 'EGP', country: 'Egypt', region: 'Africa', apiFootballId: 233, liveSupported: false },
  'botola-pro': { leagueId: 'botola-pro', name: 'Botola Pro', shortName: 'BOT', country: 'Morocco', region: 'Africa', apiFootballId: 200, liveSupported: false },
  'algeria-l1': { leagueId: 'algeria-l1', name: 'Algerian Ligue 1', shortName: 'ALG', country: 'Algeria', region: 'Africa', apiFootballId: 186, liveSupported: false },
  'nigeria-npfl': { leagueId: 'nigeria-npfl', name: 'Nigeria NPFL', shortName: 'NPFL', country: 'Nigeria', region: 'Africa', espnSlug: 'nga.1', apiFootballId: 399, liveSupported: true },
  'tunisia-l1': { leagueId: 'tunisia-l1', name: 'Tunisian Ligue 1', shortName: 'TL1', country: 'Tunisia', region: 'Africa', apiFootballId: 202, liveSupported: false },
  'ghana-pl': { leagueId: 'ghana-pl', name: 'Ghana Premier League', shortName: 'GPL', country: 'Ghana', region: 'Africa', espnSlug: 'gha.1', apiFootballId: 570, liveSupported: true },
  'rwanda-pl': { leagueId: 'rwanda-pl', name: 'Rwanda Premier League', shortName: 'RPL', country: 'Rwanda', region: 'Africa', apiFootballId: 405, liveSupported: false },
  'burundi-pl': { leagueId: 'burundi-pl', name: 'Burundi Primus League', shortName: 'BPL', country: 'Burundi', region: 'Africa', apiFootballId: 566, liveSupported: false },
  'drc-linafoot': { leagueId: 'drc-linafoot', name: 'DR Congo Linafoot', shortName: 'DRC', country: 'DR Congo', region: 'Africa', apiFootballId: 568, liveSupported: false },
  'senegal-l1': { leagueId: 'senegal-l1', name: 'Senegal Ligue 1', shortName: 'SEN', country: 'Senegal', region: 'Africa', apiFootballId: 404, liveSupported: false },
  'cameroon-e1': { leagueId: 'cameroon-e1', name: 'Cameroon Elite One', shortName: 'CMR', country: 'Cameroon', region: 'Africa', apiFootballId: 403, liveSupported: false },
  'civ-l1': { leagueId: 'civ-l1', name: 'Ivory Coast Ligue 1', shortName: 'CIV', country: 'Ivory Coast', region: 'Africa', apiFootballId: 386, liveSupported: false },
  'ethiopia-pl': { leagueId: 'ethiopia-pl', name: 'Ethiopian Premier League', shortName: 'ETH', country: 'Ethiopia', region: 'Africa', apiFootballId: 363, liveSupported: false },

  // Rest of Europe
  'ligue-1': { leagueId: 'ligue-1', name: 'Ligue 1', shortName: 'L1', country: 'France', region: 'Europe', espnSlug: 'fra.1', footballDataCode: 'FL1', apiFootballId: 61, liveSupported: true },
  uel: { leagueId: 'uel', name: 'UEFA Europa League', shortName: 'UEL', country: 'Europe', region: 'Europe', espnSlug: 'uefa.europa', apiFootballId: 3, liveSupported: true },
  uecl: { leagueId: 'uecl', name: 'UEFA Conference League', shortName: 'UECL', country: 'Europe', region: 'Europe', espnSlug: 'uefa.europa.conf', apiFootballId: 848, liveSupported: true },
  championship: { leagueId: 'championship', name: 'EFL Championship', shortName: 'EFL', country: 'England', region: 'Europe', espnSlug: 'eng.2', footballDataCode: 'ELC', apiFootballId: 40, liveSupported: true },
  eredivisie: { leagueId: 'eredivisie', name: 'Eredivisie', shortName: 'ERE', country: 'Netherlands', region: 'Europe', espnSlug: 'ned.1', footballDataCode: 'DED', apiFootballId: 88, liveSupported: true },
  'liga-portugal': { leagueId: 'liga-portugal', name: 'Liga Portugal', shortName: 'LPT', country: 'Portugal', region: 'Europe', espnSlug: 'por.1', footballDataCode: 'PPL', apiFootballId: 94, liveSupported: true },
  'scottish-prem': { leagueId: 'scottish-prem', name: 'Scottish Premiership', shortName: 'SPL', country: 'Scotland', region: 'Europe', espnSlug: 'sco.1', apiFootballId: 179, liveSupported: true },
  'super-lig': { leagueId: 'super-lig', name: 'Süper Lig', shortName: 'SL', country: 'Turkey', region: 'Europe', espnSlug: 'tur.1', apiFootballId: 203, liveSupported: true },
  'belgian-pro': { leagueId: 'belgian-pro', name: 'Belgian Pro League', shortName: 'BPL', country: 'Belgium', region: 'Europe', espnSlug: 'bel.1', apiFootballId: 144, liveSupported: true },
  'swiss-super': { leagueId: 'swiss-super', name: 'Swiss Super League', shortName: 'SSL', country: 'Switzerland', region: 'Europe', espnSlug: 'sui.1', apiFootballId: 207, liveSupported: true },

  // Americas
  mls: { leagueId: 'mls', name: 'MLS', shortName: 'MLS', country: 'USA / Canada', region: 'Americas', espnSlug: 'usa.1', apiFootballId: 253, liveSupported: true },
  'liga-mx': { leagueId: 'liga-mx', name: 'Liga MX', shortName: 'LMX', country: 'Mexico', region: 'Americas', espnSlug: 'mex.1', apiFootballId: 262, liveSupported: true },
  brasileirao: { leagueId: 'brasileirao', name: 'Brasileirão Série A', shortName: 'BRA', country: 'Brazil', region: 'Americas', espnSlug: 'bra.1', footballDataCode: 'BSA', apiFootballId: 71, liveSupported: true },
  'liga-arg': { leagueId: 'liga-arg', name: 'Liga Profesional', shortName: 'ARG', country: 'Argentina', region: 'Americas', espnSlug: 'arg.1', apiFootballId: 128, liveSupported: true },
  libertadores: { leagueId: 'libertadores', name: 'Copa Libertadores', shortName: 'LIB', country: 'South America', region: 'Americas', espnSlug: 'conmebol.libertadores', apiFootballId: 13, liveSupported: true },
  'colombia-a': { leagueId: 'colombia-a', name: 'Categoría Primera A', shortName: 'COL', country: 'Colombia', region: 'Americas', espnSlug: 'col.1', apiFootballId: 239, liveSupported: true },

  // Asia & Middle East
  'afc-cl': { leagueId: 'afc-cl', name: 'AFC Champions League Elite', shortName: 'ACLE', country: 'Asia', region: 'Asia & Middle East', espnSlug: 'afc.champions', apiFootballId: 17, liveSupported: true },
  'j1-league': { leagueId: 'j1-league', name: 'J1 League', shortName: 'J1', country: 'Japan', region: 'Asia & Middle East', espnSlug: 'jpn.1', apiFootballId: 98, liveSupported: true },
  'k-league-1': { leagueId: 'k-league-1', name: 'K League 1', shortName: 'K1', country: 'South Korea', region: 'Asia & Middle East', apiFootballId: 292, liveSupported: false },
  'a-league': { leagueId: 'a-league', name: 'A-League Men', shortName: 'ALM', country: 'Australia', region: 'Asia & Middle East', espnSlug: 'aus.1', apiFootballId: 188, liveSupported: true },
  csl: { leagueId: 'csl', name: 'Chinese Super League', shortName: 'CSL', country: 'China', region: 'Asia & Middle East', espnSlug: 'chn.1', apiFootballId: 169, liveSupported: true },
  isl: { leagueId: 'isl', name: 'Indian Super League', shortName: 'ISL', country: 'India', region: 'Asia & Middle East', espnSlug: 'ind.1', apiFootballId: 323, liveSupported: true },
  'qatar-stars': { leagueId: 'qatar-stars', name: 'Qatar Stars League', shortName: 'QSL', country: 'Qatar', region: 'Asia & Middle East', apiFootballId: 305, liveSupported: false },
  'uae-pro': { leagueId: 'uae-pro', name: 'UAE Pro League', shortName: 'UAE', country: 'United Arab Emirates', region: 'Asia & Middle East', apiFootballId: 301, liveSupported: false },

  // International
  wcq: { leagueId: 'wcq', name: 'FIFA International & Qualifiers', shortName: 'WCQ', country: 'International', region: 'International', espnSlug: 'fifa.worldq.caf', liveSupported: true },
  'nations-league': { leagueId: 'nations-league', name: 'UEFA Nations League', shortName: 'UNL', country: 'International', region: 'International', espnSlug: 'uefa.nations', liveSupported: true },
  'afcon-q': { leagueId: 'afcon-q', name: 'AFCON Qualifiers & Finals', shortName: 'AFCON', country: 'Africa', region: 'International', espnSlug: 'caf.nations', liveSupported: true },
};

export const OVERVIEW_LEAGUE_IDS = [
  'nations-league',
  'epl',
  'ucl',
  'laliga',
  'bundesliga',
  'serie-a',
  'roshn',
  'sa-psl',
  'kenya-fkf',
  'uganda-upl',
  'caf-cl',
  'caf-confed',
  'mls',
  'brasileirao',
];

export const CONTINUATION_LEAGUE_IDS = [
  'epl',
  'laliga',
  'serie-a',
  'bundesliga',
  'roshn',
  'sa-psl',
  'kenya-fkf',
  'uganda-upl',
  'ucl',
  'ligue-1',
];

type UnknownRecord = Record<string, unknown>;

function asRecord(val: unknown): UnknownRecord {
  return val && typeof val === 'object' ? (val as UnknownRecord) : {};
}

function asArray(val: unknown): unknown[] {
  return Array.isArray(val) ? val : [];
}

function asString(val: unknown, fallback = ''): string {
  return typeof val === 'string' ? val : fallback;
}

function asNumber(val: unknown, fallback = 0): number {
  if (typeof val === 'number' && Number.isFinite(val)) return val;
  if (typeof val === 'string') {
    const parsed = Number(val);
    if (Number.isFinite(parsed)) return parsed;
  }
  return fallback;
}

function normalizeHex(raw: string, fallback: string): string {
  const clean = raw.trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{6}$/.test(clean)) return `#${clean.toUpperCase()}`;
  return fallback;
}

export function slugifyTeamId(name: string, espnId?: string): string {
  const cleaned = name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  if (cleaned) return cleaned;
  return espnId ? `club-${espnId}` : 'club-unknown';
}

export function formatKickoffLabel(
  isoDate: string,
  state: string,
  shortDetail?: string,
  displayClock?: string
): string {
  const detail = (shortDetail || '').trim();
  const clock = (displayClock || '').trim();

  if (state === 'in') {
    if (detail === 'HT' || clock === 'HT') return 'Live · HT';
    if (clock) return `Live · ${clock.includes("'") ? clock : `${clock}'`}`;
    if (detail) return `Live · ${detail}`;
    return 'Live';
  }

  const parsed = new Date(isoDate);
  const validDate = !Number.isNaN(parsed.getTime());

  if (state === 'post') {
    const base = detail || 'FT';
    if (!validDate) return base;
    const dateStr = parsed.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      timeZone: TANZANIA_TIMEZONE,
    });
    return `${base} · ${dateStr}`;
  }

  if (!validDate) return detail || 'Scheduled';

  const dayLabel = parsed.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: TANZANIA_TIMEZONE,
  });
  const timeLabel = parsed.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: TANZANIA_TIMEZONE,
  });
  return `${dayLabel} · ${timeLabel} EAT`;
}

export function formatRelativeDateLabel(isoDate: string): string {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return 'Latest';
  const diffMs = Date.now() - parsed.getTime();
  const diffMins = Math.round(diffMs / 60000);
  if (diffMins >= 0 && diffMins < 60) return `${Math.max(1, diffMins)}m ago`;
  const diffHours = Math.round(diffMs / 3600000);
  if (diffHours >= 0 && diffHours < 24) return `${diffHours}h ago`;
  return parsed.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: TANZANIA_TIMEZONE,
  });
}

function parseOptionalScore(raw: unknown): number | undefined {
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  if (typeof raw === 'string' && raw.trim() !== '') {
    const parsed = Number(raw.trim());
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

export function emptyStats(): MatchStats {
  return {
    statsAvailable: false,
    possessionHome: null,
    possessionAway: null,
    shotsHome: null,
    shotsAway: null,
    shotsOnTargetHome: null,
    shotsOnTargetAway: null,
    cornersHome: null,
    cornersAway: null,
    xgHome: null,
    xgAway: null,
  };
}

export function extractCompStats(homeComp: UnknownRecord, awayComp: UnknownRecord): MatchStats {
  const readStat = (comp: UnknownRecord, statNames: string[]): number | null => {
    const statsArr = asArray(comp.statistics);
    for (const entry of statsArr) {
      const rec = asRecord(entry);
      const name = asString(rec.name).toLowerCase();
      if (statNames.includes(name)) {
        const raw = rec.displayValue ?? rec.value;
        if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
        if (typeof raw === 'string' && raw.trim() !== '') {
          const parsed = Number(raw.replace('%', '').trim());
          if (Number.isFinite(parsed)) return parsed;
        }
      }
    }
    return null;
  };

  const possHRaw = readStat(homeComp, ['possessionpct', 'possession']);
  const possARaw = readStat(awayComp, ['possessionpct', 'possession']);
  const possessionHome = possHRaw !== null ? Math.round(possHRaw) : null;
  const possessionAway =
    possARaw !== null
      ? Math.round(possARaw)
      : possessionHome !== null
      ? Math.max(0, 100 - possessionHome)
      : null;

  const shotsHRaw = readStat(homeComp, ['totalshots', 'shots']);
  const shotsARaw = readStat(awayComp, ['totalshots', 'shots']);
  const sotHRaw = readStat(homeComp, ['shotsontarget']);
  const sotARaw = readStat(awayComp, ['shotsontarget']);
  const cornersHRaw = readStat(homeComp, ['woncorners', 'corners']);
  const cornersARaw = readStat(awayComp, ['woncorners', 'corners']);
  const xgHRaw = readStat(homeComp, ['expectedgoals', 'xg']);
  const xgARaw = readStat(awayComp, ['expectedgoals', 'xg']);

  const shotsHome = shotsHRaw !== null ? Math.round(shotsHRaw) : null;
  const shotsAway = shotsARaw !== null ? Math.round(shotsARaw) : null;
  const shotsOnTargetHome = sotHRaw !== null ? Math.round(sotHRaw) : null;
  const shotsOnTargetAway = sotARaw !== null ? Math.round(sotARaw) : null;
  const cornersHome = cornersHRaw !== null ? Math.round(cornersHRaw) : null;
  const cornersAway = cornersARaw !== null ? Math.round(cornersARaw) : null;
  const xgHome = xgHRaw !== null ? Number(xgHRaw.toFixed(2)) : null;
  const xgAway = xgARaw !== null ? Number(xgARaw.toFixed(2)) : null;

  const statsAvailable =
    possessionHome !== null ||
    shotsHome !== null ||
    shotsOnTargetHome !== null ||
    cornersHome !== null ||
    xgHome !== null;

  return {
    statsAvailable,
    possessionHome,
    possessionAway,
    shotsHome,
    shotsAway,
    shotsOnTargetHome,
    shotsOnTargetAway,
    cornersHome,
    cornersAway,
    xgHome,
    xgAway,
  };
}

function extractDetailsEvents(
  detailsArr: unknown[],
  homeApiId: string,
  awayApiId: string
): MatchEvent[] {
  const events: MatchEvent[] = [];
  for (const item of detailsArr) {
    const rec = asRecord(item);
    const typeObj = asRecord(rec.type);
    const typeText = asString(typeObj.text, '').toLowerCase();
    const isGoal =
      Boolean(rec.scoringPlay) ||
      typeText.includes('goal') ||
      typeText.includes('penalty - scored');
    const isYellow = Boolean(rec.yellowCard) || typeText.includes('yellow');
    const isRed = Boolean(rec.redCard) || typeText.includes('red');
    const isSub = typeText.includes('substitution');
    if (!isGoal && !isYellow && !isRed && !isSub) continue;

    const eventType: MatchEvent['type'] = isGoal
      ? 'goal'
      : isRed
      ? 'red'
      : isSub
      ? 'sub'
      : 'yellow';

    const teamObj = asRecord(rec.team);
    const teamIdStr = asString(teamObj.id);
    const side: 'home' | 'away' =
      teamIdStr && teamIdStr === awayApiId && teamIdStr !== homeApiId ? 'away' : 'home';

    const clockObj = asRecord(rec.clock);
    const minute = asString(clockObj.displayValue, '—');

    const athletes = asArray(rec.athletesInvolved);
    const primaryAthlete = asRecord(athletes[0]);
    const playerName =
      asString(primaryAthlete.displayName) ||
      asString(primaryAthlete.shortName) ||
      (eventType === 'goal' ? 'Goal Scorer' : 'Match Booking');

    const detail = rec.penaltyKick
      ? 'Penalty'
      : rec.ownGoal
      ? 'Own Goal'
      : asString(typeObj.text) || undefined;

    events.push({
      minute,
      team: side,
      type: eventType,
      player: playerName,
      detail,
    });
  }
  return events;
}

export function parseEspnScoreboard(
  leagueId: string,
  payload: unknown
): {
  matches: FootballMatch[];
  pastDates: string[];
  nextDates: string[];
  seasonLabel: string;
} {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta) {
    return { matches: [], pastDates: [], nextDates: [], seasonLabel: '2026/27' };
  }

  const root = asRecord(payload);
  const leagueArr = asArray(root.leagues);
  const firstLeague = asRecord(leagueArr[0]);
  const seasonObj = asRecord(firstLeague.season);
  const seasonLabel = asString(seasonObj.displayName, '2026/27');

  const todayMs = Date.now();
  const calendarArr = asArray(firstLeague.calendar);
  const pastDates: string[] = [];
  const nextDates: string[] = [];

  for (const d of calendarArr) {
    if (typeof d !== 'string') continue;
    const ms = Date.parse(d);
    if (Number.isNaN(ms)) continue;
    const yyyymmdd = d.slice(0, 10).replace(/-/g, '');
    if (ms <= todayMs) {
      pastDates.push(yyyymmdd);
    } else {
      nextDates.push(yyyymmdd);
    }
  }

  const events = asArray(root.events);
  const matches: FootballMatch[] = [];

  for (const rawEv of events) {
    const ev = asRecord(rawEv);
    const externalEventId = asString(ev.id);
    const compList = asArray(ev.competitions);
    const comp = asRecord(compList[0]);
    const competitors = asArray(comp.competitors);
    if (competitors.length < 2) continue;

    const homeComp =
      competitors.map(asRecord).find((c) => asString(c.homeAway) === 'home') ||
      asRecord(competitors[0]);
    const awayComp =
      competitors.map(asRecord).find((c) => asString(c.homeAway) === 'away') ||
      asRecord(competitors[1]);

    const homeTeamRec = asRecord(homeComp.team);
    const awayTeamRec = asRecord(awayComp.team);

    const homeName = (asString(homeTeamRec.displayName) || asString(homeTeamRec.shortDisplayName)).trim();
    const awayName = (asString(awayTeamRec.displayName) || asString(awayTeamRec.shortDisplayName)).trim();
    if (!externalEventId || !homeName || !awayName) continue;

    const homeApiId = asString(homeTeamRec.id);
    const awayApiId = asString(awayTeamRec.id);

    const statusObj = asRecord(comp.status || ev.status);
    const statusType = asRecord(statusObj.type);
    const state = asString(statusType.state, 'pre');

    let status: MatchStatus = 'upcoming';
    if (state === 'in') status = 'live';
    else if (state === 'post') status = 'result';

    const isoDate = asString(comp.date) || asString(ev.date);
    const shortDetail = asString(statusType.shortDetail);
    const displayClock = asString(statusObj.displayClock);

    const venueObj = asRecord(comp.venue);
    const addrObj = asRecord(venueObj.address);
    const venueName = asString(venueObj.fullName) || asString(addrObj.city) || `${meta.country} Stadium`;

    const hasScore = status === 'live' || status === 'result';
    const homeScore = hasScore ? parseOptionalScore(homeComp.score) : undefined;
    const awayScore = hasScore ? parseOptionalScore(awayComp.score) : undefined;

    const roundRec = asRecord(comp.type);
    const roundLabel =
      asString(roundRec.text) ||
      asString(asRecord(ev.season).slug) ||
      seasonLabel;

    const detailsEvents = extractDetailsEvents(
      asArray(comp.details),
      homeApiId,
      awayApiId
    );

    const homeLogo =
      asString(homeTeamRec.logo) ||
      asString(asRecord(asArray(homeTeamRec.logos)[0]).href) ||
      undefined;
    const awayLogo =
      asString(awayTeamRec.logo) ||
      asString(asRecord(asArray(awayTeamRec.logos)[0]).href) ||
      undefined;

    matches.push({
      id: `espn-${leagueId}-${externalEventId}`,
      externalEventId,
      leagueId,
      league: meta.name,
      country: meta.country,
      region: meta.region,
      round: roundLabel,
      status,
      timeLabel: formatKickoffLabel(isoDate, state, shortDetail, displayClock),
      venue: venueName,
      homeTeamId: slugifyTeamId(homeName, homeApiId),
      awayTeamId: slugifyTeamId(awayName, awayApiId),
      homeExternalTeamId: homeApiId || undefined,
      awayExternalTeamId: awayApiId || undefined,
      homeTeam: homeName,
      awayTeam: awayName,
      homeShort: asString(homeTeamRec.abbreviation, homeName.slice(0, 3).toUpperCase()),
      awayShort: asString(awayTeamRec.abbreviation, awayName.slice(0, 3).toUpperCase()),
      homeColor: normalizeHex(asString(homeTeamRec.color), '#10B981'),
      awayColor: normalizeHex(asString(awayTeamRec.color), '#F59E0B'),
      homeLogo,
      awayLogo,
      homeScore,
      awayScore,
      kickoffIso: isoDate || undefined,
      source: 'live',
      featured: false,
      events: detailsEvents,
      stats: hasScore ? extractCompStats(homeComp, awayComp) : emptyStats(),
      homeLineup: [],
      awayLineup: [],
    });
  }

  return { matches, pastDates, nextDates, seasonLabel };
}

export function parseEspnStandings(leagueId: string, payload: unknown): StandingRow[] {
  const root = asRecord(payload);
  const children = asArray(root.children);
  const standingsRoot =
    children.length > 0 ? asRecord(asRecord(children[0]).standings) : asRecord(root.standings);
  const entries = asArray(standingsRoot.entries);

  const rows: StandingRow[] = [];

  for (let i = 0; i < entries.length; i += 1) {
    const entry = asRecord(entries[i]);
    const team = asRecord(entry.team);
    const teamName = asString(team.displayName) || asString(team.name);
    if (!teamName) continue;

    const teamApiId = asString(team.id);
    const logos = asArray(team.logos);
    const logoUrl = asString(asRecord(logos[0]).href) || undefined;

    const stats = asArray(entry.stats).map(asRecord);
    const getStatVal = (names: string[]): number => {
      for (const st of stats) {
        const n = asString(st.name).toLowerCase();
        if (names.includes(n)) {
          return asNumber(st.value, asNumber(st.displayValue, 0));
        }
      }
      return 0;
    };

    const note = asRecord(entry.note);
    const noteDesc = asString(note.description).toLowerCase();
    let zone: StandingRow['zone'];
    if (noteDesc.includes('champions league') || noteDesc.includes('promotion') || noteDesc.includes('caf')) {
      zone = 'champions';
    } else if (noteDesc.includes('europa') || noteDesc.includes('conference') || noteDesc.includes('continental') || noteDesc.includes('playoff')) {
      zone = 'continental';
    } else if (noteDesc.includes('relegat')) {
      zone = 'relegation';
    }

    const pos = Math.round(getStatVal(['rank'])) || i + 1;
    const played = Math.round(getStatVal(['gamesplayed', 'played']));
    const won = Math.round(getStatVal(['wins']));
    const drawn = Math.round(getStatVal(['ties', 'draws']));
    const lost = Math.round(getStatVal(['losses']));
    const gf = Math.round(getStatVal(['pointsfor', 'goalsfor']));
    const ga = Math.round(getStatVal(['pointsagainst', 'goalsagainst']));
    const gd = Math.round(getStatVal(['pointdifferential', 'goaldifferential'])) || gf - ga;
    const pts = Math.round(getStatVal(['points']));

    rows.push({
      pos,
      teamId: slugifyTeamId(teamName, teamApiId),
      externalTeamId: teamApiId || undefined,
      teamName,
      shortName: asString(team.abbreviation, teamName.slice(0, 3).toUpperCase()),
      color: normalizeHex(asString(team.color), '#10B981'),
      logoUrl,
      played,
      won,
      drawn,
      lost,
      gf,
      ga,
      gd,
      pts,
      form: [],
      zone,
      source: 'live',
    });
  }

  return rows.sort((a, b) => a.pos - b.pos);
}

export function parseEspnSummary(baseMatch: FootballMatch, payload: unknown): FootballMatch {
  const root = asRecord(payload);
  const header = asRecord(root.header);
  const compList = asArray(header.competitions);
  const comp = asRecord(compList[0]);
  const competitors = asArray(comp.competitors);

  const homeComp =
    competitors.map(asRecord).find((c) => asString(c.homeAway) === 'home') ||
    asRecord(competitors[0]);
  const awayComp =
    competitors.map(asRecord).find((c) => asString(c.homeAway) === 'away') ||
    asRecord(competitors[1]);

  const homeTeamRec = asRecord(homeComp.team);
  const awayTeamRec = asRecord(awayComp.team);
  const homeApiId = asString(homeTeamRec.id) || baseMatch.homeExternalTeamId || '';
  const awayApiId = asString(awayTeamRec.id) || baseMatch.awayExternalTeamId || '';

  const headerHomeName =
    asString(homeTeamRec.displayName) || asString(homeTeamRec.shortDisplayName);
  const headerAwayName =
    asString(awayTeamRec.displayName) || asString(awayTeamRec.shortDisplayName);
  const headerHomeLogo =
    asString(homeTeamRec.logo) ||
    asString(asRecord(asArray(homeTeamRec.logos)[0]).href) ||
    baseMatch.homeLogo;
  const headerAwayLogo =
    asString(awayTeamRec.logo) ||
    asString(asRecord(asArray(awayTeamRec.logos)[0]).href) ||
    baseMatch.awayLogo;

  const statusObj = asRecord(comp.status);
  const statusType = asRecord(statusObj.type);
  const headerState = asString(statusType.state);
  let resolvedStatus: MatchStatus = baseMatch.status;
  if (headerState === 'in') resolvedStatus = 'live';
  else if (headerState === 'post') resolvedStatus = 'result';
  else if (headerState === 'pre') resolvedStatus = 'upcoming';

  const isoDate = asString(comp.date) || baseMatch.kickoffIso || '';
  const resolvedTimeLabel = headerState
    ? formatKickoffLabel(
        isoDate,
        headerState,
        asString(statusType.shortDetail),
        asString(statusObj.displayClock)
      )
    : baseMatch.timeLabel;

  const hasScore = resolvedStatus === 'live' || resolvedStatus === 'result';
  const homeScore = hasScore
    ? parseOptionalScore(homeComp.score) ?? baseMatch.homeScore
    : baseMatch.homeScore;
  const awayScore = hasScore
    ? parseOptionalScore(awayComp.score) ?? baseMatch.awayScore
    : baseMatch.awayScore;

  // Extract keyEvents + header.competitions[0].details (merge & prefer richest goal info)
  const keyEvents = asArray(root.keyEvents);
  const parsedKeyEvents: MatchEvent[] = [];

  for (const item of keyEvents) {
    const ev = asRecord(item);
    const typeObj = asRecord(ev.type);
    const typeText = asString(typeObj.text).toLowerCase();
    const isGoal =
      Boolean(ev.scoringPlay) ||
      typeText.includes('goal') ||
      typeText.includes('penalty - scored');
    const isRed = typeText.includes('red');
    const isYellow = typeText.includes('yellow');
    const isSub = typeText.includes('substitution');
    if (!isGoal && !isRed && !isYellow && !isSub) continue;

    const teamObj = asRecord(ev.team);
    const side: 'home' | 'away' =
      asString(teamObj.id) && asString(teamObj.id) === awayApiId && asString(teamObj.id) !== homeApiId
        ? 'away'
        : 'home';

    const participants = asArray(ev.participants);
    const firstAthlete = asRecord(asRecord(participants[0]).athlete);
    const secondAthlete = asRecord(asRecord(participants[1]).athlete);
    const playerName =
      isSub && asString(firstAthlete.displayName) && asString(secondAthlete.displayName)
        ? `${asString(firstAthlete.displayName)} ↔ ${asString(secondAthlete.displayName)}`
        : asString(firstAthlete.displayName) ||
          asString(ev.shortText) ||
          asString(ev.text, 'Match Event');

    const clockObj = asRecord(ev.clock);
    const detail = typeText.includes('own goal')
      ? 'Own Goal'
      : typeText.includes('penalty')
      ? 'Penalty'
      : asString(typeObj.text) || undefined;

    parsedKeyEvents.push({
      minute: asString(clockObj.displayValue, '—'),
      team: side,
      type: isGoal ? 'goal' : isRed ? 'red' : isSub ? 'sub' : 'yellow',
      player: playerName,
      detail,
    });
  }

  const compDetailsEvents = extractDetailsEvents(
    asArray(comp.details),
    homeApiId,
    awayApiId
  );

  const parsedEvents =
    parsedKeyEvents.length >= compDetailsEvents.length ? parsedKeyEvents : compDetailsEvents;

  // Extract boxscore team stats
  const boxscore = asRecord(root.boxscore);
  const boxTeams = asArray(boxscore.teams).map(asRecord);
  const boxHome = boxTeams.find((t) => asString(asRecord(t.team).id) === homeApiId) || boxTeams[0];
  const boxAway = boxTeams.find((t) => asString(asRecord(t.team).id) === awayApiId) || boxTeams[1];

  const stats =
    boxHome && boxAway
      ? extractCompStats(asRecord(boxHome), asRecord(boxAway))
      : baseMatch.stats;

  // Extract lineups from rosters
  const rosters = asArray(root.rosters).map(asRecord);
  const extractLineup = (teamApiId: string, fallbackIdx: number): string[] => {
    const rosterRec =
      rosters.find((r) => asString(asRecord(r.team).id) === teamApiId) || rosters[fallbackIdx];
    const entries = asArray(asRecord(rosterRec).roster);
    const starters = entries
      .map(asRecord)
      .filter((p) => p.starter === true)
      .slice(0, 11)
      .map((p) => asString(asRecord(p.athlete).displayName))
      .filter(Boolean);
    if (starters.length > 0) return starters;
    return entries
      .map(asRecord)
      .slice(0, 11)
      .map((p) => asString(asRecord(p.athlete).displayName))
      .filter(Boolean);
  };

  const homeLineup = extractLineup(homeApiId, 0);
  const awayLineup = extractLineup(awayApiId, 1);

  const gameInfo = asRecord(root.gameInfo);
  const venueRec = asRecord(gameInfo.venue);
  const venue = asString(venueRec.fullName) || baseMatch.venue;
  const headToHead = parseEspnHeadToHead(payload);

  return {
    ...baseMatch,
    homeTeam: headerHomeName || baseMatch.homeTeam,
    awayTeam: headerAwayName || baseMatch.awayTeam,
    homeShort: asString(homeTeamRec.abbreviation, baseMatch.homeShort),
    awayShort: asString(awayTeamRec.abbreviation, baseMatch.awayShort),
    homeLogo: headerHomeLogo,
    awayLogo: headerAwayLogo,
    status: resolvedStatus,
    timeLabel: resolvedTimeLabel,
    homeScore,
    awayScore,
    venue,
    events: parsedEvents.length > 0 ? parsedEvents : baseMatch.events,
    stats,
    homeLineup: homeLineup.length > 0 ? homeLineup : baseMatch.homeLineup,
    awayLineup: awayLineup.length > 0 ? awayLineup : baseMatch.awayLineup,
    headToHead,
    source: 'live',
  };
}

export function parseEspnHeadToHead(payload: unknown): HeadToHeadSummary | undefined {
  const root = asRecord(payload);
  const seasonSeries = asArray(root.seasonseries).map(asRecord);
  const h2hNode =
    seasonSeries.find((s) => asString(s.type).toLowerCase() === 'head-to-head') ||
    seasonSeries[0];
  if (!h2hNode) return undefined;

  const rawEvents = asArray(h2hNode.events);
  const matches: HeadToHeadMatch[] = [];

  for (const rawEv of rawEvents.slice(0, 5)) {
    const ev = asRecord(rawEv);
    const comps = asArray(ev.competitors).map(asRecord);
    if (comps.length < 2) continue;

    const homeComp = comps.find((c) => asString(c.homeAway) === 'home') || comps[0]!;
    const awayComp = comps.find((c) => asString(c.homeAway) === 'away') || comps[1]!;
    const homeTeamRec = asRecord(homeComp.team);
    const awayTeamRec = asRecord(awayComp.team);
    const homeTeam = asString(homeTeamRec.displayName);
    const awayTeam = asString(awayTeamRec.displayName);
    if (!homeTeam || !awayTeam) continue;

    const homeScore = parseOptionalScore(homeComp.score) ?? null;
    const awayScore = parseOptionalScore(awayComp.score) ?? null;

    let winnerSide: HeadToHeadMatch['winnerSide'];
    if (typeof homeScore === 'number' && typeof awayScore === 'number') {
      winnerSide = homeScore > awayScore ? 'home' : awayScore > homeScore ? 'away' : 'draw';
    }

    const isoDate = asString(ev.date);
    const parsedDate = new Date(isoDate);
    const dateLabel = !Number.isNaN(parsedDate.getTime())
      ? parsedDate.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          timeZone: TANZANIA_TIMEZONE,
        })
      : 'Historical';

    matches.push({
      id: asString(ev.id, `${homeTeam}-${awayTeam}-${dateLabel}`),
      dateLabel,
      competition: asString(ev.competitionName, 'Official Fixture'),
      homeTeam,
      awayTeam,
      homeShort: asString(homeTeamRec.abbreviation, homeTeam.slice(0, 3).toUpperCase()),
      awayShort: asString(awayTeamRec.abbreviation, awayTeam.slice(0, 3).toUpperCase()),
      homeLogo: asString(homeTeamRec.logo) || asString(asRecord(asArray(homeTeamRec.logos)[0]).href) || undefined,
      awayLogo: asString(awayTeamRec.logo) || asString(asRecord(asArray(awayTeamRec.logos)[0]).href) || undefined,
      homeScore,
      awayScore,
      winnerSide,
    });
  }

  if (matches.length === 0) return undefined;
  return {
    title: asString(h2hNode.title, 'Head-to-Head'),
    summaryText: asString(h2hNode.summary) || asString(h2hNode.shortSummary, 'Last 5 Meetings'),
    matches,
  };
}

function formatEatNewsDate(isoDate: string): string | undefined {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return undefined;
  const datePart = parsed.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: TANZANIA_TIMEZONE,
  });
  const timePart = parsed.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: TANZANIA_TIMEZONE,
  });
  return `${datePart} · ${timePart} EAT`;
}

export function parseEspnNews(
  payload: unknown,
  defaultLeagueName: string,
  defaultCategory: NewsCategory,
  defaultRegion?: Exclude<RegionId, 'all'>
): NewsHeadline[] {
  const root = asRecord(payload);
  const articles = asArray(root.articles);
  const items: NewsHeadline[] = [];

  for (let i = 0; i < articles.length; i += 1) {
    const art = asRecord(articles[i]);
    const title = asString(art.headline);
    if (!title) continue;

    const description = asString(art.description, title);
    const published = asString(art.published);
    const links = asRecord(art.links);
    const web = asRecord(links.web);
    const externalUrl = asString(web.href) || undefined;
    const images = asArray(art.images);
    const firstImage = asRecord(images[0]);
    const imageUrl = asString(firstImage.url) || undefined;

    const lowerText = `${title} ${description}`.toLowerCase();
    const isTransfer =
      lowerText.includes('transfer') ||
      lowerText.includes('sign') ||
      lowerText.includes('loan') ||
      lowerText.includes('bid') ||
      lowerText.includes('deal') ||
      lowerText.includes('contract') ||
      lowerText.includes('target') ||
      lowerText.includes('rumour') ||
      lowerText.includes('rumor');

    const isTanzania =
      lowerText.includes('tanzania') ||
      lowerText.includes('taifa stars') ||
      lowerText.includes('simba') ||
      lowerText.includes('yanga') ||
      lowerText.includes('young africans');

    const isInjury =
      lowerText.includes('injury') ||
      lowerText.includes('injured') ||
      lowerText.includes('ruled out') ||
      lowerText.includes('fitness') ||
      lowerText.includes('surgery');

    const isManager =
      lowerText.includes('manager') ||
      lowerText.includes('head coach') ||
      lowerText.includes('sacked') ||
      lowerText.includes('appointed');

    let category: NewsCategory = defaultCategory;
    if (isTanzania) category = 'Tanzania';
    else if (isManager && !lowerText.includes('transfer') && !lowerText.includes('loan')) category = 'Manager';
    else if (isInjury) category = 'Injury';
    else if (isTransfer) category = 'Transfer';
    else if (defaultRegion === 'Africa') category = 'Africa';

    let transferStatus: TransferDealClassification | undefined;
    if (isTransfer) {
      if (/\bloan\b/.test(lowerText)) transferStatus = 'Loan';
      else if (/\b(official|confirmed|completes|complete|unveiled|signs|signed)\b/.test(lowerText)) {
        transferStatus = 'Confirmed';
      } else if (/\b(rumour|rumor|linked|target|interest|eyes|monitoring|talks)\b/.test(lowerText)) {
        transferStatus = 'Rumour';
      } else {
        transferStatus = 'Report';
      }
    }

    const leagueTag = slugifyTeamId(defaultLeagueName);
    const rawId =
      asString(art.id) ||
      asString(art.dataSourceIdentifier) ||
      `${leagueTag}-${i}-${slugifyTeamId(title).slice(0, 24)}`;

    items.push({
      id: `espn-news-${leagueTag}-${rawId}`,
      category,
      timeAgo: formatRelativeDateLabel(published),
      publishedIso: published || undefined,
      publishedEatLabel: published ? formatEatNewsDate(published) : undefined,
      title,
      summary: description,
      leagueName: defaultLeagueName,
      region: defaultRegion,
      imageUrl,
      sourceName: 'ESPN Football Wire',
      transferStatus,
      externalUrl,
      source: 'live',
    });
  }

  return items;
}

export function deriveLeaderFromStandings(
  leagueId: string,
  rows: StandingRow[],
  roundLabel: string,
  resumeDateLabel: string
): LeagueLeaderItem | null {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  const leader = rows[0];
  if (!meta || !leader) return null;

  return {
    leagueId,
    leagueLabel: meta.name,
    roundLabel,
    resumeDateLabel,
    leaderId: leader.teamId,
    leaderExternalTeamId: leader.externalTeamId,
    leaderName: leader.teamName,
    leaderShort: leader.shortName,
    leaderColor: leader.color,
    leaderLogo: leader.logoUrl,
    ptsLabel: `${leader.pts} pts (${leader.played}P)`,
    source: 'live',
  };
}

export function buildTeamsFromStandingsAndMatches(
  standingsByLeague: Record<string, StandingRow[]>,
  matches: FootballMatch[]
): TeamProfile[] {
  const map = new Map<string, TeamProfile>();

  for (const [leagueId, rows] of Object.entries(standingsByLeague)) {
    const meta = LEAGUE_API_MAPPINGS[leagueId];
    if (!meta) continue;
    for (const row of rows) {
      if (map.has(row.teamId)) continue;
      map.set(row.teamId, {
        id: row.teamId,
        externalTeamId: row.externalTeamId,
        name: row.teamName,
        shortName: row.shortName,
        country: meta.country,
        leagueId,
        leagueName: meta.name,
        region: meta.region,
        stadium: 'Club Stadium',
        capacity: 'Official Venue',
        manager: 'Not provided by live API',
        founded: null,
        primaryColor: row.color,
        secondaryColor: '#FFFFFF',
        logoUrl: row.logoUrl,
        standingSummary: `#${row.pos} in ${meta.name}`,
        recordSummary: `${row.won}W-${row.drawn}D-${row.lost}L`,
        leaguePosition: row.pos,
        form: row.form,
        summary: `${row.teamName} currently sits #${row.pos} in ${meta.name} (${row.pts} pts from ${row.played} matches, ${row.won}W-${row.drawn}D-${row.lost}L).`,
        source: 'live',
      });
    }
  }

  for (const m of matches) {
    const enrichTeam = (
      id: string,
      externalTeamId: string | undefined,
      name: string,
      shortName: string,
      color: string,
      logoUrl?: string
    ) => {
      const existing = map.get(id);
      if (existing) {
        if (!existing.externalTeamId && externalTeamId) existing.externalTeamId = externalTeamId;
        if (!existing.logoUrl && logoUrl) existing.logoUrl = logoUrl;
        if (existing.stadium === 'Club Stadium' && m.venue) existing.stadium = m.venue;
        return;
      }
      map.set(id, {
        id,
        externalTeamId,
        name,
        shortName,
        country: m.country,
        leagueId: m.leagueId,
        leagueName: m.league,
        region: m.region,
        stadium: m.venue || 'Club Stadium',
        capacity: 'Official Venue',
        manager: 'Not provided by live API',
        founded: null,
        primaryColor: color,
        secondaryColor: '#FFFFFF',
        logoUrl,
        leaguePosition: null,
        form: [],
        summary: `Competing in ${m.league} (${m.country}). Real matchday schedules and scores synced via Sky Sports live feed.`,
        source: 'live',
      });
    };

    enrichTeam(m.homeTeamId, m.homeExternalTeamId, m.homeTeam, m.homeShort, m.homeColor, m.homeLogo);
    enrichTeam(m.awayTeamId, m.awayExternalTeamId, m.awayTeam, m.awayShort, m.awayColor, m.awayLogo);
  }

  return Array.from(map.values());
}

function mapPositionAbbrev(raw?: string): PlayerPosition | 'N/A' {
  const v = (raw || '').trim().toUpperCase();
  if (v === 'G' || v === 'GK') return 'GK';
  if (v === 'D' || v === 'DF' || v.includes('DEF')) return 'DF';
  if (v === 'M' || v === 'MF' || v.includes('MID')) return 'MF';
  if (v === 'F' || v === 'FW' || v.includes('FOR') || v.includes('STR')) return 'FW';
  return 'N/A';
}

export function parseEspnLeagueLeaders(leagueId: string, payload: unknown): PlayerStat[] {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta) return [];

  const root = asRecord(payload);
  const statGroups = asArray(root.stats);
  const byPlayerId = new Map<string, PlayerStat>();

  for (const rawGroup of statGroups) {
    const group = asRecord(rawGroup);
    const leaders = asArray(group.leaders);

    for (const rawLeader of leaders) {
      const leader = asRecord(rawLeader);
      const athlete = asRecord(leader.athlete);
      const extId = asString(athlete.id);
      const name = asString(athlete.displayName) || asString(athlete.shortName);
      if (!name || !extId) continue;

      const team = asRecord(athlete.team);
      const teamName = asString(team.displayName) || asString(team.name) || meta.name;
      const extTeamId = asString(team.id) || undefined;
      const teamId = slugifyTeamId(teamName, extTeamId);
      const logos = asArray(team.logos);
      const clubLogoUrl = asString(asRecord(logos[0]).href) || undefined;

      const statsArr = asArray(athlete.statistics).map(asRecord);
      const getStat = (statNames: string[]): number => {
        for (const s of statsArr) {
          if (statNames.includes(asString(s.name).toLowerCase())) {
            return asNumber(s.value, 0);
          }
        }
        return 0;
      };

      const links = asArray(athlete.links).map(asRecord);
      const overviewLink = links.find((l) => {
        const rel = asArray(l.rel).map(String);
        return rel.includes('overview') && rel.includes('desktop');
      });

      const key = `${leagueId}-${extId}`;
      const existing = byPlayerId.get(key);
      const appearances = Math.round(getStat(['appearances']));
      const goals = Math.round(getStat(['totalgoals', 'goals']));
      const assists = Math.round(getStat(['goalassists', 'assists']));

      if (existing) {
        existing.appearances = Math.max(existing.appearances, appearances);
        existing.goals = Math.max(existing.goals, goals);
        existing.assists = Math.max(existing.assists, assists);
        continue;
      }

      const posRec = asRecord(athlete.position);
      const headshotRec = asRecord(athlete.headshot);

      byPlayerId.set(key, {
        id: key,
        externalPlayerId: extId,
        name,
        teamId,
        externalTeamId: extTeamId,
        teamName,
        teamShort: asString(team.abbreviation, teamName.slice(0, 3).toUpperCase()),
        teamColor: normalizeHex(asString(team.color), '#10B981'),
        clubLogoUrl,
        headshotUrl: asString(headshotRec.href) || undefined,
        jersey: asString(athlete.jersey) || undefined,
        leagueId,
        leagueName: meta.name,
        nationality: asString(athlete.citizenship, '—'),
        position: mapPositionAbbrev(asString(posRec.abbreviation)),
        age: typeof athlete.age === 'number' && athlete.age > 0 ? athlete.age : null,
        appearances,
        minutes: null,
        goals,
        assists,
        shotsOnTarget: 0,
        passAccuracy: null,
        cleanSheets: null,
        saves: null,
        yellowCards: 0,
        rating: null,
        externalUrl: asString(overviewLink?.href) || undefined,
      });
    }
  }

  return Array.from(byPlayerId.values());
}

export function parseEspnTeamDetailAndRoster(
  leagueId: string,
  externalTeamId: string,
  teamPayload: unknown,
  rosterPayload: unknown
): { team: TeamProfile | null; squad: PlayerStat[] } {
  const meta = LEAGUE_API_MAPPINGS[leagueId];
  if (!meta) return { team: null, squad: [] };

  const teamRoot = asRecord(asRecord(teamPayload).team);
  const rosterRoot = asRecord(rosterPayload);
  const rosterTeam = asRecord(rosterRoot.team);

  const name =
    asString(teamRoot.displayName) ||
    asString(rosterTeam.displayName) ||
    asString(rosterTeam.name);

  if (!name) return { team: null, squad: [] };

  const teamId = slugifyTeamId(name, externalTeamId);
  const shortName =
    asString(teamRoot.abbreviation) ||
    asString(rosterTeam.abbreviation, name.slice(0, 3).toUpperCase());
  const color = normalizeHex(
    asString(teamRoot.color) || asString(rosterTeam.color),
    '#10B981'
  );
  const logos = asArray(teamRoot.logos);
  const logoUrl =
    asString(asRecord(logos[0]).href) || asString(rosterTeam.logo) || undefined;

  const standingSummary =
    asString(teamRoot.standingSummary) || asString(rosterTeam.standingSummary) || undefined;
  const recordItems = asArray(asRecord(teamRoot.record).items);
  const recordSummary =
    asString(asRecord(recordItems[0]).summary) ||
    asString(rosterTeam.recordSummary) ||
    undefined;

  const venueObj = asRecord(teamRoot.venue);
  const stadium = asString(venueObj.fullName) || 'Official Club Ground';

  let parsedPos: number | null = null;
  if (standingSummary) {
    const m = standingSummary.match(/^(\d+)/);
    if (m) parsedPos = Number(m[1]);
  }

  const athletes = asArray(rosterRoot.athletes);
  const squad: PlayerStat[] = [];

  for (const rawAthlete of athletes) {
    const a = asRecord(rawAthlete);
    const extPlayerId = asString(a.id);
    const pName = asString(a.displayName) || asString(a.fullName);
    if (!extPlayerId || !pName) continue;

    const cats = asArray(asRecord(asRecord(a.statistics).splits).categories).map(asRecord);
    const readCatStat = (statNames: string[]): number => {
      for (const c of cats) {
        const stats = asArray(c.stats).map(asRecord);
        for (const st of stats) {
          if (statNames.includes(asString(st.name).toLowerCase())) {
            return asNumber(st.value, 0);
          }
        }
      }
      return 0;
    };

    const posRec = asRecord(a.position);
    const headshotRec = asRecord(a.headshot);
    const links = asArray(a.links).map(asRecord);
    const overviewLink = links.find((l) => {
      const rel = asArray(l.rel).map(String);
      return rel.includes('overview') && rel.includes('desktop');
    });

    const posMapped = mapPositionAbbrev(asString(posRec.abbreviation));

    squad.push({
      id: `${leagueId}-${extPlayerId}`,
      externalPlayerId: extPlayerId,
      name: pName,
      teamId,
      externalTeamId,
      teamName: name,
      teamShort: shortName,
      teamColor: color,
      clubLogoUrl: logoUrl,
      headshotUrl: asString(headshotRec.href) || undefined,
      jersey: asString(a.jersey) || undefined,
      leagueId,
      leagueName: meta.name,
      nationality: asString(a.citizenship, '—'),
      position: posMapped,
      age: typeof a.age === 'number' && a.age > 0 ? a.age : null,
      appearances: Math.round(readCatStat(['appearances'])),
      minutes: null,
      goals: Math.round(readCatStat(['totalgoals', 'goals'])),
      assists: Math.round(readCatStat(['goalassists', 'assists'])),
      shotsOnTarget: Math.round(readCatStat(['shotsontarget'])),
      totalShots: Math.round(readCatStat(['totalshots'])),
      passAccuracy: null,
      cleanSheets: posMapped === 'GK' ? null : null,
      saves: posMapped === 'GK' ? Math.round(readCatStat(['saves'])) : null,
      yellowCards: Math.round(readCatStat(['yellowcards'])),
      redCards: Math.round(readCatStat(['redcards'])),
      rating: null,
      externalUrl: asString(overviewLink?.href) || undefined,
    });
  }

  squad.sort((a, b) => {
    if (b.appearances !== a.appearances) return b.appearances - a.appearances;
    if (b.goals !== a.goals) return b.goals - a.goals;
    return b.assists - a.assists;
  });

  const team: TeamProfile = {
    id: teamId,
    externalTeamId,
    name,
    shortName,
    country: meta.country,
    leagueId,
    leagueName: meta.name,
    region: meta.region,
    stadium,
    capacity: 'Official Club Ground',
    manager: 'Not provided by live API',
    founded: null,
    primaryColor: color,
    secondaryColor: '#FFFFFF',
    logoUrl,
    standingSummary,
    recordSummary,
    leaguePosition: parsedPos,
    form: [],
    summary: `${name} (${meta.name})${standingSummary ? ` — ${standingSummary}` : ''}${recordSummary ? ` (${recordSummary})` : ''}. Live squad roster of ${squad.length} registered players retrieved automatically.`,
    source: 'live',
  };

  return { team, squad };
}

export const CLUB_WIKIPEDIA_TITLE_OVERRIDES: Record<string, string> = {
  'young africans': 'Young Africans S.C.',
  'yanga': 'Young Africans S.C.',
  'simba': 'Simba S.C.',
  'simba sc': 'Simba S.C.',
  'azam': 'Azam F.C.',
  'azam fc': 'Azam F.C.',
  'gor mahia': 'Gor Mahia F.C.',
  'afc leopards': 'AFC Leopards',
  'kenya police': 'Kenya Police F.C.',
  'tusker': 'Tusker F.C.',
  'tusker fc': 'Tusker F.C.',
  'kcb': 'Kenya Commercial Bank S.C.',
  'shabana': 'Shabana F.C.',
  'kariobangi sharks': 'Kariobangi Sharks F.C.',
  'kakamega homeboyz': 'Kakamega Homeboyz F.C.',
  'bandari': 'Bandari F.C. (Kenya)',
  'bandari mtwara': 'Bandari F.C. (Kenya)',
  'sofapaka': 'Sofapaka F.C.',
  'bidco united': 'Bidco United F.C.',
  'mathare united': 'Mathare United F.C.',
  'murang a seal fc': "Murang'a Seal F.C.",
  "murang'a seal fc": "Murang'a Seal F.C.",
  'post rangers': 'Posta Rangers F.C.',
  'posta rangers': 'Posta Rangers F.C.',
  'ulinzi stars': 'Ulinzi Stars F.C.',
  'mara sugar': 'Mara Sugar F.C.',
  'nairobi city stars': 'Nairobi City Stars F.C.',
  'nairobi united': 'Nairobi United F.C.',
  'aps bomet': 'APS Bomet F.C.',
  'zamalek': 'Zamalek SC',
  'pyramids fc': 'Pyramids FC',
  'pyramids': 'Pyramids FC',
  'al ahly': 'Al Ahly SC',
  'rsb berkane': 'RSB Berkane',
  'mc alger': 'MC Alger',
  'club africain': 'Club Africain',
  'esperance': 'Espérance Sportive de Tunis',
  'esperance de tunis': 'Espérance Sportive de Tunis',
  'raja casablanca': 'Raja CA',
  'wydad ac': 'Wydad AC',
  'far rabat': 'AS FAR (football)',
  'as far': 'AS FAR (football)',
  'mamelodi sundowns': 'Mamelodi Sundowns F.C.',
  'orlando pirates': 'Orlando Pirates F.C.',
  'kaizer chiefs': 'Kaizer Chiefs F.C.',
  'al hilal': 'Al-Hilal Omdurman',
  'stade malien': 'Stade Malien',
  'power dynamos': 'Power Dynamos F.C.',
  'rivers united': 'Rivers United F.C.',
  'petro de luanda': 'Atlético Petróleos de Luanda',
  'wiliete sc': 'Wiliete S.C.',
  'asec mimosas': 'ASEC Mimosas',
  'js kabylie': 'JS Kabylie',
  'cr belouizdad': 'CR Belouizdad',
  'tp mazembe': 'TP Mazembe',
  'usm alger': 'USM Alger',
};

export function normalizeLookupName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

export function buildClubWikipediaCandidates(clubName: string): string[] {
  const norm = normalizeLookupName(clubName);
  const override = CLUB_WIKIPEDIA_TITLE_OVERRIDES[norm];
  const candidates: string[] = [];
  if (override) candidates.push(override);

  const trimmed = clubName.trim();
  if (trimmed) {
    candidates.push(trimmed);
    if (!/\b(FC|F\.C\.|SC|S\.C\.|CF|AC|AS)\b/i.test(trimmed)) {
      candidates.push(`${trimmed} F.C.`);
      candidates.push(`${trimmed} FC`);
      candidates.push(`${trimmed} S.C.`);
      candidates.push(`${trimmed} SC`);
    } else if (/\bFC$/i.test(trimmed)) {
      candidates.push(trimmed.replace(/\bFC$/i, 'F.C.'));
    } else if (/\bSC$/i.test(trimmed)) {
      candidates.push(trimmed.replace(/\bSC$/i, 'S.C.'));
    }
  }
  return Array.from(new Set(candidates));
}

export function extractWikipediaInfoboxLogoFile(wikitext: string): string | null {
  if (!wikitext) return null;
  const match = wikitext.match(
    /\|\s*(?:image|logo|clubname_image|crest)\s*=\s*(?:\[\[(?:File|Image):)?([^\|\n\]<>]+?\.(?:png|svg|jpg|jpeg|webp))/i
  );
  if (!match || !match[1]) return null;
  const fileName = match[1]
    .trim()
    .replace(/^(?:File|Image):/i, '')
    .replace(/\s+/g, ' ');
  if (!fileName || /flag_of|soccerball|commons-logo|kit_/i.test(fileName)) {
    return null;
  }
  return `File:${fileName}`;
}

export function parseWikipediaImageInfoUrls(payload: unknown): Record<string, string> {
  const root = asRecord(payload);
  const query = asRecord(root.query);
  const pages = asRecord(query.pages);
  const normalizedList = asArray(query.normalized).map(asRecord);
  const normMap = new Map<string, string>();
  for (const n of normalizedList) {
    const from = asString(n.from);
    const to = asString(n.to);
    if (from && to) normMap.set(to, from);
  }

  const out: Record<string, string> = {};
  for (const rawPage of Object.values(pages)) {
    const p = asRecord(rawPage);
    const title = asString(p.title);
    const info = asRecord(asArray(p.imageinfo)[0]);
    const url = asString(info.thumburl) || asString(info.url);
    if (title && url) {
      out[title] = url;
      const orig = normMap.get(title);
      if (orig) out[orig] = url;
    }
  }
  return out;
}

export function parseWikipediaPortraitMap(payload: unknown): Record<string, string> {
  const root = asRecord(payload);
  const query = asRecord(root.query);
  const pages = asRecord(query.pages);
  const normalized = asArray(query.normalized).map(asRecord);
  const redirects = asArray(query.redirects).map(asRecord);

  // Map resolved final title back to any requested source titles
  const aliasesByTarget = new Map<string, string[]>();
  const addAlias = (target: string, alias: string) => {
    const list = aliasesByTarget.get(target) || [];
    list.push(alias);
    aliasesByTarget.set(target, list);
  };

  const redirSourceByTo = new Map<string, string[]>();
  for (const r of redirects) {
    const from = asString(r.from);
    const to = asString(r.to);
    if (from && to) {
      const arr = redirSourceByTo.get(to) || [];
      arr.push(from);
      redirSourceByTo.set(to, arr);
    }
  }

  for (const n of normalized) {
    const from = asString(n.from);
    const to = asString(n.to);
    if (from && to) {
      addAlias(to, from);
      // Also propagate through redirects
      for (const r of redirects) {
        if (asString(r.from) === to && asString(r.to)) {
          addAlias(asString(r.to), from);
        }
      }
    }
  }
  for (const [to, froms] of redirSourceByTo.entries()) {
    for (const f of froms) addAlias(to, f);
  }

  const result: Record<string, string> = {};
  for (const rawPage of Object.values(pages)) {
    const p = asRecord(rawPage);
    const title = asString(p.title);
    const thumb = asRecord(p.thumbnail);
    const src = asString(thumb.source);
    if (!title || !src) continue;
    // Skip obvious country flags / non-portrait icons
    if (/flag_of|soccerball|commons-logo/i.test(src)) continue;

    result[normalizeLookupName(title)] = src;
    for (const alias of aliasesByTarget.get(title) || []) {
      result[normalizeLookupName(alias)] = src;
    }
  }

  return result;
}

function assignStandingZones(leagueId: string, rows: StandingRow[]): StandingRow[] {
  const total = rows.length;
  return rows.map((row, idx) => {
    const pos = idx + 1;
    let zone: StandingRow['zone'] = row.zone;
    if (!zone) {
      if (leagueId === 'ucl') {
        if (pos <= 8) zone = 'champions';
        else if (pos <= 24) zone = 'continental';
        else zone = 'relegation';
      } else {
        if (pos <= 4) zone = 'champions';
        else if (pos <= 6) zone = 'continental';
        else if (total >= 12 && pos > total - 3) zone = 'relegation';
      }
    }
    return { ...row, pos, zone };
  });
}

export function calculateStandingsFromResults(
  leagueId: string,
  matches: FootballMatch[]
): StandingRow[] {
  const completed = matches
    .filter(
      (m) =>
        m.leagueId === leagueId &&
        m.status === 'result' &&
        typeof m.homeScore === 'number' &&
        typeof m.awayScore === 'number'
    )
    .sort((a, b) => {
      const tA = a.kickoffIso ? Date.parse(a.kickoffIso) : 0;
      const tB = b.kickoffIso ? Date.parse(b.kickoffIso) : 0;
      return tA - tB;
    });

  if (completed.length === 0) return [];

  const table = new Map<string, StandingRow>();
  const ensureTeam = (
    teamId: string,
    extId: string | undefined,
    teamName: string,
    shortName: string,
    color: string,
    logoUrl?: string
  ): StandingRow => {
    let row = table.get(teamId);
    if (!row) {
      row = {
        pos: 0,
        teamId,
        externalTeamId: extId,
        teamName,
        shortName,
        color,
        logoUrl,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        gf: 0,
        ga: 0,
        gd: 0,
        pts: 0,
        form: [],
        source: 'live',
      };
      table.set(teamId, row);
    }
    if (!row.logoUrl && logoUrl) row.logoUrl = logoUrl;
    return row;
  };

  for (const m of completed) {
    const hs = m.homeScore!;
    const as = m.awayScore!;
    const home = ensureTeam(
      m.homeTeamId,
      m.homeExternalTeamId,
      m.homeTeam,
      m.homeShort,
      m.homeColor,
      m.homeLogo
    );
    const away = ensureTeam(
      m.awayTeamId,
      m.awayExternalTeamId,
      m.awayTeam,
      m.awayShort,
      m.awayColor,
      m.awayLogo
    );

    home.played += 1;
    away.played += 1;
    home.gf += hs;
    home.ga += as;
    away.gf += as;
    away.ga += hs;

    if (hs > as) {
      home.won += 1;
      home.pts += 3;
      home.form.push('W');
      away.lost += 1;
      away.form.push('L');
    } else if (hs < as) {
      away.won += 1;
      away.pts += 3;
      away.form.push('W');
      home.lost += 1;
      home.form.push('L');
    } else {
      home.drawn += 1;
      home.pts += 1;
      home.form.push('D');
      away.drawn += 1;
      away.pts += 1;
      away.form.push('D');
    }
  }

  const rows = Array.from(table.values())
    .map((r) => ({
      ...r,
      gd: r.gf - r.ga,
      form: r.form.slice(-5),
    }))
    .sort((a, b) => {
      if (b.pts !== a.pts) return b.pts - a.pts;
      if (b.gd !== a.gd) return b.gd - a.gd;
      if (b.gf !== a.gf) return b.gf - a.gf;
      return a.teamName.localeCompare(b.teamName);
    });

  return assignStandingZones(leagueId, rows);
}

export function enrichStandingsWithResults(
  leagueId: string,
  officialRows: StandingRow[],
  matches: FootballMatch[]
): StandingRow[] {
  if (officialRows.length === 0) {
    return calculateStandingsFromResults(leagueId, matches);
  }

  const completed = matches
    .filter(
      (m) =>
        m.leagueId === leagueId &&
        m.status === 'result' &&
        typeof m.homeScore === 'number' &&
        typeof m.awayScore === 'number'
    )
    .sort((a, b) => {
      const tA = a.kickoffIso ? Date.parse(a.kickoffIso) : 0;
      const tB = b.kickoffIso ? Date.parse(b.kickoffIso) : 0;
      return tA - tB;
    });

  if (completed.length === 0) return officialRows;

  const formByTeamId = new Map<string, ('W' | 'D' | 'L')[]>();
  const formByName = new Map<string, ('W' | 'D' | 'L')[]>();

  const pushForm = (teamId: string, name: string, res: 'W' | 'D' | 'L') => {
    const arrId = formByTeamId.get(teamId) || [];
    arrId.push(res);
    formByTeamId.set(teamId, arrId);

    const norm = normalizeLookupName(name);
    const arrName = formByName.get(norm) || [];
    arrName.push(res);
    formByName.set(norm, arrName);
  };

  for (const m of completed) {
    const hs = m.homeScore!;
    const as = m.awayScore!;
    if (hs > as) {
      pushForm(m.homeTeamId, m.homeTeam, 'W');
      pushForm(m.awayTeamId, m.awayTeam, 'L');
    } else if (hs < as) {
      pushForm(m.homeTeamId, m.homeTeam, 'L');
      pushForm(m.awayTeamId, m.awayTeam, 'W');
    } else {
      pushForm(m.homeTeamId, m.homeTeam, 'D');
      pushForm(m.awayTeamId, m.awayTeam, 'D');
    }
  }

  return officialRows.map((row) => {
    if (row.form.length > 0) return row;
    const matched =
      formByTeamId.get(row.teamId) || formByName.get(normalizeLookupName(row.teamName)) || [];
    return matched.length > 0 ? { ...row, form: matched.slice(-5) } : row;
  });
}

export function parseFootballDataStandings(leagueId: string, payload: unknown): StandingRow[] {
  const root = asRecord(payload);
  const standingsList = asArray(root.standings).map(asRecord);
  const totalTable =
    standingsList.find((s) => asString(s.type) === 'TOTAL') || standingsList[0];
  const tableRows = asArray(asRecord(totalTable).table).map(asRecord);

  const parsed: StandingRow[] = tableRows.map((r, idx) => {
    const team = asRecord(r.team);
    const teamName = asString(team.name) || asString(team.shortName) || `Club ${idx + 1}`;
    const shortName = asString(team.tla, teamName.slice(0, 3).toUpperCase());
    const formRaw = asString(r.form);
    const formArr = formRaw
      .split(',')
      .map((x) => x.trim())
      .filter((c): c is 'W' | 'D' | 'L' => c === 'W' || c === 'D' || c === 'L')
      .slice(-5);

    const gf = asNumber(r.goalsFor, 0);
    const ga = asNumber(r.goalsAgainst, 0);
    return {
      pos: asNumber(r.position, idx + 1),
      teamId: slugifyTeamId(teamName, String(team.id ?? '')),
      externalTeamId: team.id ? String(team.id) : undefined,
      teamName,
      shortName,
      color: '#10B981',
      logoUrl: asString(team.crest) || undefined,
      played: asNumber(r.playedGames, 0),
      won: asNumber(r.won, 0),
      drawn: asNumber(r.draw, 0),
      lost: asNumber(r.lost, 0),
      gf,
      ga,
      gd: asNumber(r.goalDifference, gf - ga),
      pts: asNumber(r.points, 0),
      form: formArr,
      source: 'live',
    };
  });

  return assignStandingZones(leagueId, parsed.sort((a, b) => a.pos - b.pos));
}

export function parseEspnMultiSportScoreboard(
  sport: SportCategoryId,
  leagueLabel: string,
  payload: unknown
): MultiSportEvent[] {
  const root = asRecord(payload);
  const events = asArray(root.events);
  const out: MultiSportEvent[] = [];

  for (const rawEv of events) {
    const ev = asRecord(rawEv);
    const comp = asRecord(asArray(ev.competitions)[0]);
    const competitors = asArray(comp.competitors).map(asRecord);

    if (competitors.length >= 2) {
      const homeComp = competitors.find((c) => asString(c.homeAway) === 'home') || competitors[0]!;
      const awayComp = competitors.find((c) => asString(c.homeAway) === 'away') || competitors[1]!;
      const homeTeamRec = asRecord(homeComp.team);
      const awayTeamRec = asRecord(awayComp.team);
      const homeAthlete = asRecord(homeComp.athlete);
      const awayAthlete = asRecord(awayComp.athlete);

      const homeTeam =
        asString(homeTeamRec.displayName) ||
        asString(homeAthlete.displayName) ||
        asString(homeTeamRec.shortDisplayName) ||
        'Home';
      const awayTeam =
        asString(awayTeamRec.displayName) ||
        asString(awayAthlete.displayName) ||
        asString(awayTeamRec.shortDisplayName) ||
        'Away';

      const statusObj = asRecord(comp.status || ev.status);
      const statusType = asRecord(statusObj.type);
      const state = asString(statusType.state, 'pre');
      let status: MatchStatus = 'upcoming';
      if (state === 'in') status = 'live';
      else if (state === 'post') status = 'result';

      const isoDate = asString(comp.date) || asString(ev.date);
      const timeLabel = formatKickoffLabel(
        isoDate,
        state,
        asString(statusType.shortDetail),
        asString(statusObj.displayClock)
      );

      const hasScore = status === 'live' || status === 'result';
      const venueRec = asRecord(comp.venue);

      out.push({
        id: `${sport}-${asString(ev.id, `${homeTeam}-${awayTeam}`)}`,
        sport,
        league: leagueLabel,
        status,
        timeLabel,
        kickoffIso: isoDate || undefined,
        venue: asString(venueRec.fullName) || 'International Arena',
        homeTeam,
        awayTeam,
        homeShort: asString(homeTeamRec.abbreviation, homeTeam.slice(0, 3).toUpperCase()),
        awayShort: asString(awayTeamRec.abbreviation, awayTeam.slice(0, 3).toUpperCase()),
        homeLogo: asString(homeTeamRec.logo) || undefined,
        awayLogo: asString(awayTeamRec.logo) || undefined,
        homeScore: hasScore ? asString(homeComp.score) || String(asNumber(homeComp.score, 0)) : undefined,
        awayScore: hasScore ? asString(awayComp.score) || String(asNumber(awayComp.score, 0)) : undefined,
        detailNote: asString(statusType.detail) || undefined,
      });
    } else if (asString(ev.name)) {
      // Tournament-based events (e.g., Tennis ATP / Grand Slam groupings)
      const statusObj = asRecord(ev.status);
      const statusType = asRecord(statusObj.type);
      const state = asString(statusType.state, 'pre');
      const isoDate = asString(ev.date);
      out.push({
        id: `${sport}-${asString(ev.id, asString(ev.name))}`,
        sport,
        league: leagueLabel,
        status: state === 'in' ? 'live' : state === 'post' ? 'result' : 'upcoming',
        timeLabel: formatKickoffLabel(isoDate, state, asString(statusType.shortDetail)),
        kickoffIso: isoDate || undefined,
        venue: asString(ev.shortName, leagueLabel),
        homeTeam: asString(ev.name),
        awayTeam: asString(statusType.detail, 'Tournament Draw'),
        homeShort: sport.slice(0, 3).toUpperCase(),
        awayShort: 'EVT',
      });
    }
  }

  return out;
}



