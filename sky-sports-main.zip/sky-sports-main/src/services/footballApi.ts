import type {
  FootballMatch,
  LeagueStatsApiResponse,
  MultiSportApiResponse,
  NewsApiResponse,
  OverviewApiResponse,
  PlayersApiResponse,
  SportCategoryId,
  StandingsApiResponse,
  TeamDetailApiResponse,
  TransfersApiResponse,
} from '../types/football';

async function readJsonSafe<T>(res: Response): Promise<T> {
  const data = (await res.json()) as T & { ok?: boolean; error?: string };
  if (!res.ok) {
    throw new Error(data?.error || `Request failed with status ${res.status}`);
  }
  return data;
}

export async function fetchFootballOverview(forceRefresh = false): Promise<OverviewApiResponse> {
  const url = forceRefresh ? '/api/football/overview?refresh=1' : '/api/football/overview';
  const res = await fetch(url, {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<OverviewApiResponse>(res);
}

export async function fetchLeagueMatches(leagueId: string): Promise<{
  ok: boolean;
  available: boolean;
  leagueId: string;
  matches: FootballMatch[];
  reason?: string;
}> {
  const res = await fetch(`/api/football/league/${encodeURIComponent(leagueId)}`, {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe(res);
}

export async function fetchLeagueStandings(
  leagueId: string,
  forceRefresh = false
): Promise<StandingsApiResponse> {
  const qs = forceRefresh ? '?refresh=1' : '';
  const res = await fetch(`/api/football/standings/${encodeURIComponent(leagueId)}${qs}`, {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<StandingsApiResponse>(res);
}

export async function fetchLeagueStats(leagueId: string): Promise<LeagueStatsApiResponse> {
  const res = await fetch(`/api/football/league-stats/${encodeURIComponent(leagueId)}`, {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<LeagueStatsApiResponse>(res);
}

export async function fetchMatchDetail(
  leagueId: string,
  eventId: string,
  forceRefresh = false
): Promise<{ ok: boolean; match: FootballMatch }> {
  const qs = forceRefresh ? '?refresh=1' : '';
  const res = await fetch(
    `/api/football/match/${encodeURIComponent(leagueId)}/${encodeURIComponent(eventId)}${qs}`,
    {
      headers: { Accept: 'application/json' },
    }
  );
  return readJsonSafe(res);
}

export async function fetchPlayers(): Promise<PlayersApiResponse> {
  const res = await fetch('/api/football/players', {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<PlayersApiResponse>(res);
}

export async function fetchTeamDetail(
  leagueId: string,
  externalTeamId: string
): Promise<TeamDetailApiResponse> {
  const res = await fetch(
    `/api/football/team/${encodeURIComponent(leagueId)}/${encodeURIComponent(externalTeamId)}`,
    {
      headers: { Accept: 'application/json' },
    }
  );
  return readJsonSafe<TeamDetailApiResponse>(res);
}

export async function fetchLiveTransfers(): Promise<TransfersApiResponse> {
  const res = await fetch('/api/football/transfers', {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<TransfersApiResponse>(res);
}

export async function fetchFootballNews(): Promise<NewsApiResponse> {
  const res = await fetch('/api/football/news', {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<NewsApiResponse>(res);
}

export async function fetchMultiSportScoreboard(
  sport: Exclude<SportCategoryId, 'football'>
): Promise<MultiSportApiResponse> {
  const res = await fetch(`/api/sports/${encodeURIComponent(sport)}`, {
    headers: { Accept: 'application/json' },
  });
  return readJsonSafe<MultiSportApiResponse>(res);
}

