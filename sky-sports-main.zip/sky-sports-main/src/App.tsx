import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeftRight,
  BarChart3,
  BellRing,
  Calendar,
  CheckCircle2,
  Loader2,
  Radio,
  Search,
  Trophy,
  X,
} from 'lucide-react';
import { AfricanFootballView } from './components/AfricanFootballView';
import { FeaturedMatchBanner } from './components/FeaturedMatchBanner';
import { Header, MobileBottomNav } from './components/Header';
import { LeagueTablesView } from './components/LeagueTablesView';
import { LiveDataStatusBar } from './components/LiveDataStatusBar';
import { LiveNewsTicker } from './components/LiveNewsTicker';
import { MatchAlertsModal, MatchAlertToast } from './components/MatchAlertsModal';
import { MatchCard } from './components/MatchCard';
import { MatchDetailModal } from './components/MatchDetailModal';
import { NewsView } from './components/NewsView';
import { PlayersView } from './components/PlayersView';
import { ProfileView } from './components/ProfileView';
import { SeasonContinuationStrip } from './components/SeasonContinuationStrip';
import { SportSidebar } from './components/SportSidebar';
import { TeamsView } from './components/TeamsView';
import { TransfersView } from './components/TransfersView';
import { LEAGUES_CATALOG, REGIONS_META } from './data/leaguesCatalog';
import {
  fetchFootballNews,
  fetchFootballOverview,
  fetchLeagueMatches,
  fetchLiveTransfers,
  fetchMatchDetail,
  fetchMultiSportScoreboard,
  fetchPlayers,
} from './services/footballApi';
import type {
  AppView,
  FootballMatch,
  LeagueLeaderItem,
  MatchAlertItem,
  MatchStatus,
  MultiSportEvent,
  NewsHeadline,
  PlayerStat,
  RegionId,
  SportCategoryId,
  TeamProfile,
  UserProfileData,
} from './types/football';
import {
  classifyMatchTimeBucket,
  detectMatchAlertNotifications,
  filterMatches,
  formatMatchAlertMessage,
  toggleMatchAlert,
  updateMatchAlertPreferences,
} from './utils/footballUtils';

const PROFILE_STORAGE_KEY = 'sky_sports_profile_v1';
const FOLLOWED_STORAGE_KEY = 'sky_sports_followed_teams_v1';
const ALERTS_STORAGE_KEY = 'sky_sports_match_alerts_v1';
const ALERT_SNAPSHOTS_STORAGE_KEY = 'sky_sports_match_alert_snapshots_v1';
const BROWSER_NOTIF_PREF_KEY = 'sky_sports_browser_notif_v1';
const LIVE_SCORE_REFRESH_SEC = 20;
const FIXTURE_IDLE_REFRESH_SEC = 45;
const HISTORICAL_REFRESH_MS = 300_000;

const SPORT_CATEGORIES: { id: SportCategoryId; label: string }[] = [
  { id: 'football', label: 'Football' },
  { id: 'basketball', label: 'Basketball' },
  { id: 'tennis', label: 'Tennis' },
  { id: 'cricket', label: 'Cricket' },
  { id: 'rugby', label: 'Rugby' },
  { id: 'baseball', label: 'Baseball' },
  { id: 'hockey', label: 'Hockey' },
  { id: 'volleyball', label: 'Volleyball' },
];

const HEADLINE_QUICK_LEAGUES = [
  { id: 'epl', label: 'Premier League' },
  { id: 'ucl', label: 'Champions League' },
  { id: 'laliga', label: 'La Liga' },
  { id: 'bundesliga', label: 'Bundesliga' },
  { id: 'serie-a', label: 'Serie A' },
  { id: 'roshn', label: 'Roshn Saudi League' },
  { id: 'sa-psl', label: 'Betway PSL (SA)' },
  { id: 'kenya-fkf', label: 'Kenya FKF' },
  { id: 'tanzania-nbc', label: 'Tanzania NBC' },
];

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('home');

  // Live Football API State (100% Real Data — Zero Demo/Fake Scores)
  const [liveMatches, setLiveMatches] = useState<FootballMatch[]>([]);
  const [liveLeagueMatches, setLiveLeagueMatches] = useState<Record<string, FootballMatch[]>>({});
  const [liveHeadlines, setLiveHeadlines] = useState<NewsHeadline[]>([]);
  const [liveLeaders, setLiveLeaders] = useState<LeagueLeaderItem[]>([]);
  const [liveTeams, setLiveTeams] = useState<TeamProfile[]>([]);
  const [liveLoading, setLiveLoading] = useState<boolean>(true);
  const [liveRefreshing, setLiveRefreshing] = useState<boolean>(false);
  const [liveError, setLiveError] = useState<string | null>(null);
  const [lastUpdatedIso, setLastUpdatedIso] = useState<string | null>(null);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState<boolean>(true);
  const [secondsToRefresh, setSecondsToRefresh] = useState<number>(FIXTURE_IDLE_REFRESH_SEC);
  const [standingsRevision, setStandingsRevision] = useState<number>(0);
  const [leagueFetchLoading, setLeagueFetchLoading] = useState<boolean>(false);
  const [leagueUnavailableNote, setLeagueUnavailableNote] = useState<string | null>(null);

  // Sport Category State (Football + Multi-Sport Scoreboards)
  const [activeSport, setActiveSport] = useState<SportCategoryId>('football');
  const [multiSportEvents, setMultiSportEvents] = useState<MultiSportEvent[]>([]);
  const [multiSportLoading, setMultiSportLoading] = useState<boolean>(false);
  const [multiSportError, setMultiSportError] = useState<string | null>(null);
  const [multiSportProvider, setMultiSportProvider] = useState<string>('');

  // Live Player Stats State
  const [livePlayers, setLivePlayers] = useState<PlayerStat[]>([]);
  const [playersLoading, setPlayersLoading] = useState<boolean>(false);
  const [playersError, setPlayersError] = useState<string | null>(null);

  // Live Transfers Wire State
  const [liveTransfers, setLiveTransfers] = useState<NewsHeadline[]>([]);
  const [transfersLoading, setTransfersLoading] = useState<boolean>(false);
  const [transfersError, setTransfersError] = useState<string | null>(null);
  const [transfersFetchedAt, setTransfersFetchedAt] = useState<string | null>(null);

  // Daily Sports News State
  const [liveNews, setLiveNews] = useState<NewsHeadline[]>([]);
  const [newsLoading, setNewsLoading] = useState<boolean>(false);
  const [newsError, setNewsError] = useState<string | null>(null);
  const [newsFetchedAt, setNewsFetchedAt] = useState<string | null>(null);

  // Filters & Navigation State
  const [selectedRegion, setSelectedRegion] = useState<RegionId>('all');
  const [selectedLeagueId, setSelectedLeagueId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | MatchStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [tableLeagueId, setTableLeagueId] = useState<string>('epl');
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [activeMatchDetail, setActiveMatchDetail] = useState<FootballMatch | null>(null);
  const [matchDetailLoading, setMatchDetailLoading] = useState<boolean>(false);
  const [alertsModalOpen, setAlertsModalOpen] = useState(false);
  const [toastAlert, setToastAlert] = useState<{ match: FootballMatch; headline: string } | null>(null);
  const prevMatchesRef = useRef<FootballMatch[]>([]);
  const activeMatchDetailRef = useRef<FootballMatch | null>(null);

  const [browserNotifStatus, setBrowserNotifStatus] = useState<
    'unsupported' | 'default' | 'granted' | 'denied'
  >(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
    return window.Notification.permission;
  });

  const [browserNotifEnabled, setBrowserNotifEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem(BROWSER_NOTIF_PREF_KEY) === '1';
    } catch {
      return false;
    }
  });

  const [matchAlerts, setMatchAlerts] = useState<MatchAlertItem[]>(() => {
    try {
      const raw = localStorage.getItem(ALERTS_STORAGE_KEY);
      if (raw) return JSON.parse(raw) as MatchAlertItem[];
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  const [alertMatchSnapshots, setAlertMatchSnapshots] = useState<Record<string, FootballMatch>>(() => {
    try {
      const raw = localStorage.getItem(ALERT_SNAPSHOTS_STORAGE_KEY);
      if (raw) return JSON.parse(raw) as Record<string, FootballMatch>;
    } catch {
      // Ignore storage errors
    }
    return {};
  });

  const matchAlertsRef = useRef<MatchAlertItem[]>(matchAlerts);
  useEffect(() => {
    matchAlertsRef.current = matchAlerts;
  }, [matchAlerts]);

  useEffect(() => {
    activeMatchDetailRef.current = activeMatchDetail;
  }, [activeMatchDetail]);

  const dispatchBrowserNotification = useCallback(
    (title: string, body: string, icon?: string) => {
      if (
        !browserNotifEnabled ||
        typeof window === 'undefined' ||
        !('Notification' in window) ||
        window.Notification.permission !== 'granted'
      ) {
        return;
      }
      try {
        new window.Notification(title, { body, icon });
      } catch {
        // Ignore browser notification exceptions in sandboxed contexts
      }
    },
    [browserNotifEnabled]
  );

  const [userProfile, setUserProfile] = useState<UserProfileData | null>(() => {
    try {
      const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as UserProfileData) : null;
    } catch {
      return null;
    }
  });

  const [followedTeams, setFollowedTeams] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(FOLLOWED_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as string[]) : ['epl-359'];
    } catch {
      return ['epl-359'];
    }
  });

  const loadLiveData = useCallback(async (isManualOrBackgroundRefresh = false) => {
    if (isManualOrBackgroundRefresh) {
      setLiveRefreshing(true);
    } else {
      setLiveLoading(true);
    }
    try {
      const overview = await fetchFootballOverview(isManualOrBackgroundRefresh);
      const prevMatches = prevMatchesRef.current;
      if (prevMatches.length > 0 && matchAlertsRef.current.length > 0) {
        const triggered = detectMatchAlertNotifications(
          prevMatches,
          overview.matches,
          matchAlertsRef.current
        );
        if (triggered.length > 0) {
          const latest = triggered[0]!;
          setToastAlert({ match: latest.match, headline: latest.headline });
          dispatchBrowserNotification(
            `Sky Sports · ${latest.match.homeTeam} vs ${latest.match.awayTeam}`,
            latest.headline,
            latest.match.homeLogo || latest.match.awayLogo
          );
        }
      }

      prevMatchesRef.current = overview.matches;
      setLiveMatches(overview.matches);
      setLiveHeadlines(overview.headlines);
      setLiveLeaders(overview.leaders);
      setLiveTeams(overview.teams);
      setLastUpdatedIso(overview.fetchedAt);
      setLiveError(null);

      const hasLiveNow = overview.matches.some((m) => m.status === 'live');
      setSecondsToRefresh(hasLiveNow ? LIVE_SCORE_REFRESH_SEC : FIXTURE_IDLE_REFRESH_SEC);
      if (overview.completedLeagues && overview.completedLeagues.length > 0) {
        setStandingsRevision((n) => n + 1);
      }

      // Update stored alert snapshots with freshest data
      if (matchAlertsRef.current.length > 0) {
        const alertIds = new Set(matchAlertsRef.current.map((a) => a.matchId));
        setAlertMatchSnapshots((prev) => {
          const next = { ...prev };
          for (const m of overview.matches) {
            if (alertIds.has(m.id)) next[m.id] = m;
          }
          return next;
        });
      }

      // If Match Center modal is open for a live match during background refresh, sync its detail too
      const openModal = activeMatchDetailRef.current;
      if (
        isManualOrBackgroundRefresh &&
        openModal &&
        openModal.externalEventId &&
        openModal.status === 'live'
      ) {
        fetchMatchDetail(openModal.leagueId, openModal.externalEventId, true)
          .then((detailRes) => {
            if (detailRes.ok && detailRes.match) {
              setActiveMatchDetail((curr) =>
                curr && curr.id === openModal.id ? detailRes.match : curr
              );
            }
          })
          .catch(() => {
            // Non-fatal
          });
      }
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Unable to connect to the live football data backend.';
      setLiveError(msg);
    } finally {
      setLiveLoading(false);
      setLiveRefreshing(false);
    }
  }, [dispatchBrowserNotification]);

  const loadLivePlayers = useCallback(async () => {
    setPlayersLoading(true);
    setPlayersError(null);
    try {
      const res = await fetchPlayers();
      if (!res.available && res.players.length === 0) {
        setPlayersError(res.reason || 'Live player statistics are currently unavailable.');
      }
      setLivePlayers(res.players);
    } catch (err) {
      setPlayersError(
        err instanceof Error ? err.message : 'Unable to fetch live player statistics.'
      );
    } finally {
      setPlayersLoading(false);
    }
  }, []);

  const loadLiveTransfers = useCallback(async () => {
    setTransfersLoading(true);
    setTransfersError(null);
    try {
      const res = await fetchLiveTransfers();
      setLiveTransfers(res.stories);
      setTransfersFetchedAt(res.fetchedAt);
      if (!res.available && res.stories.length === 0) {
        setTransfersError(res.reason || 'Live transfer wire is currently unavailable.');
      }
    } catch (err) {
      setTransfersError(
        err instanceof Error ? err.message : 'Unable to fetch live transfer wire.'
      );
    } finally {
      setTransfersLoading(false);
    }
  }, []);

  const loadLiveNews = useCallback(async () => {
    setNewsLoading(true);
    setNewsError(null);
    try {
      const res = await fetchFootballNews();
      setLiveNews(res.articles);
      setNewsFetchedAt(res.fetchedAt);
      if (!res.available && res.articles.length === 0) {
        setNewsError(res.reason || 'Live sports news wire is currently unavailable.');
      }
    } catch (err) {
      setNewsError(err instanceof Error ? err.message : 'Unable to fetch live sports news.');
    } finally {
      setNewsLoading(false);
    }
  }, []);

  // Initial load of live overview, players, transfers, and daily news
  useEffect(() => {
    loadLiveData(false);
    loadLivePlayers();
    loadLiveTransfers();
    loadLiveNews();
  }, [loadLiveData, loadLivePlayers, loadLiveTransfers, loadLiveNews]);

  // Multi-sport scoreboard fetch when switching sports
  useEffect(() => {
    if (activeSport === 'football') return;
    let cancelled = false;
    setMultiSportLoading(true);
    setMultiSportError(null);
    setMultiSportEvents([]);

    fetchMultiSportScoreboard(activeSport)
      .then((res) => {
        if (cancelled) return;
        setMultiSportProvider(res.provider);
        setMultiSportEvents(res.events);
        if (!res.available) {
          setMultiSportError(
            res.reason || `Live ${activeSport} scoreboard is unavailable from the provider.`
          );
        }
      })
      .catch((err) => {
        if (cancelled) return;
        setMultiSportError(
          err instanceof Error ? err.message : `Unable to load ${activeSport} scoreboard.`
        );
      })
      .finally(() => {
        if (!cancelled) setMultiSportLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeSport]);

  const activeLiveCount = useMemo(
    () => liveMatches.filter((m) => m.status === 'live').length,
    [liveMatches]
  );

  const currentRefreshIntervalSec =
    activeLiveCount > 0 ? LIVE_SCORE_REFRESH_SEC : FIXTURE_IDLE_REFRESH_SEC;

  // Tiered live score / fixture countdown (20s during live matches, 45s otherwise; paused when tab hidden)
  useEffect(() => {
    if (!autoRefreshEnabled) return undefined;

    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setSecondsToRefresh((prev) => {
        if (prev <= 1) {
          loadLiveData(true);
          return activeLiveCount > 0 ? LIVE_SCORE_REFRESH_SEC : FIXTURE_IDLE_REFRESH_SEC;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [autoRefreshEnabled, loadLiveData, activeLiveCount]);

  // Slower 5-minute refresh for historical player statistics, transfers, and news
  useEffect(() => {
    if (!autoRefreshEnabled) return undefined;
    const timer = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      loadLivePlayers();
      loadLiveTransfers();
      loadLiveNews();
    }, HISTORICAL_REFRESH_MS);
    return () => window.clearInterval(timer);
  }, [autoRefreshEnabled, loadLivePlayers, loadLiveTransfers, loadLiveNews]);

  // On-demand fetch when user filters to any specific league
  useEffect(() => {
    setLeagueUnavailableNote(null);
    if (!selectedLeagueId) return;

    let cancelled = false;
    setLeagueFetchLoading(true);
    fetchLeagueMatches(selectedLeagueId)
      .then((res) => {
        if (cancelled) return;
        if (!res.available) {
          setLeagueUnavailableNote(
            res.reason || 'Live API fixture feed is currently unavailable for this league.'
          );
        } else {
          setLiveLeagueMatches((prev) => ({ ...prev, [selectedLeagueId]: res.matches }));
        }
      })
      .catch((err) => {
        if (cancelled) return;
        setLeagueUnavailableNote(
          err instanceof Error ? err.message : 'Could not fetch league schedule.'
        );
      })
      .finally(() => {
        if (!cancelled) setLeagueFetchLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedLeagueId]);

  useEffect(() => {
    try {
      if (userProfile) {
        localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(userProfile));
      } else {
        localStorage.removeItem(PROFILE_STORAGE_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }, [userProfile]);

  useEffect(() => {
    try {
      localStorage.setItem(FOLLOWED_STORAGE_KEY, JSON.stringify(followedTeams));
    } catch {
      // Ignore storage errors
    }
  }, [followedTeams]);

  useEffect(() => {
    try {
      localStorage.setItem(ALERTS_STORAGE_KEY, JSON.stringify(matchAlerts));
    } catch {
      // Ignore storage errors
    }
  }, [matchAlerts]);

  useEffect(() => {
    try {
      localStorage.setItem(ALERT_SNAPSHOTS_STORAGE_KEY, JSON.stringify(alertMatchSnapshots));
    } catch {
      // Ignore storage errors
    }
  }, [alertMatchSnapshots]);

  useEffect(() => {
    try {
      localStorage.setItem(BROWSER_NOTIF_PREF_KEY, browserNotifEnabled ? '1' : '0');
    } catch {
      // Ignore storage errors
    }
  }, [browserNotifEnabled]);

  useEffect(() => {
    if (!toastAlert) return undefined;
    const timer = window.setTimeout(() => setToastAlert(null), 6500);
    return () => window.clearTimeout(timer);
  }, [toastAlert]);

  // Merge overview live matches + any on-demand fetched league schedule
  const combinedLiveMatches = useMemo(() => {
    const map = new Map<string, FootballMatch>();
    for (const m of liveMatches) {
      map.set(m.id, m);
    }
    if (selectedLeagueId && liveLeagueMatches[selectedLeagueId]) {
      for (const m of liveLeagueMatches[selectedLeagueId]!) {
        map.set(m.id, m);
      }
    }
    return Array.from(map.values());
  }, [liveMatches, liveLeagueMatches, selectedLeagueId]);

  const activeHeadlines: NewsHeadline[] =
    liveHeadlines.length > 0
      ? liveHeadlines
      : [
          {
            id: 'live-status-wire',
            category: 'Match Update',
            timeAgo: 'Live',
            title: liveLoading
              ? 'Connecting to Sky Sports live football feed (Tanzania EAT · UTC+3)...'
              : 'Live football feed active — automatic score & fixture synchronization running',
            summary:
              'Retrieving live football fixtures, scores, league tables, and headlines from the secure API backend.',
            leagueName: 'Global Football',
            source: 'live',
          },
        ];

  const featuredMatch = useMemo(() => {
    if (combinedLiveMatches.length === 0) return null;
    return (
      combinedLiveMatches.find((m) => m.featured && m.status === 'live') ||
      combinedLiveMatches.find((m) => m.status === 'live') ||
      combinedLiveMatches.find((m) => m.featured) ||
      combinedLiveMatches[0]!
    );
  }, [combinedLiveMatches]);

  const filteredAllMatches = useMemo(
    () =>
      filterMatches(combinedLiveMatches, {
        status: statusFilter,
        region: selectedRegion,
        leagueId: selectedLeagueId,
        query: searchQuery,
      }),
    [combinedLiveMatches, statusFilter, selectedRegion, selectedLeagueId, searchQuery]
  );

  const homeBaseMatches = useMemo(
    () =>
      filterMatches(combinedLiveMatches, {
        status: 'all',
        region: selectedRegion,
        leagueId: selectedLeagueId,
        query: searchQuery,
      }),
    [combinedLiveMatches, selectedRegion, selectedLeagueId, searchQuery]
  );

  const sectionLiveMatches = useMemo(
    () => homeBaseMatches.filter((m) => m.status === 'live'),
    [homeBaseMatches]
  );

  const sectionUpcomingMatches = useMemo(
    () => homeBaseMatches.filter((m) => m.status === 'upcoming'),
    [homeBaseMatches]
  );

  const sectionRecentResults = useMemo(
    () => homeBaseMatches.filter((m) => m.status === 'result'),
    [homeBaseMatches]
  );

  const eatFixturesGrouped = useMemo(() => {
    const today: FootballMatch[] = [];
    const tomorrow: FootballMatch[] = [];
    const upcomingOther: FootballMatch[] = [];
    for (const m of sectionUpcomingMatches) {
      const bucket = classifyMatchTimeBucket(m);
      if (bucket === 'today') today.push(m);
      else if (bucket === 'tomorrow') tomorrow.push(m);
      else upcomingOther.push(m);
    }
    return { today, tomorrow, upcomingOther };
  }, [sectionUpcomingMatches]);

  const eatResultsGrouped = useMemo(() => {
    const yesterday: FootballMatch[] = [];
    const earlier: FootballMatch[] = [];
    for (const m of sectionRecentResults) {
      const bucket = classifyMatchTimeBucket(m);
      if (bucket === 'yesterday') yesterday.push(m);
      else earlier.push(m);
    }
    return { yesterday, earlier };
  }, [sectionRecentResults]);

  const selectedLeagueMeta = useMemo(
    () => (selectedLeagueId ? LEAGUES_CATALOG.find((l) => l.id === selectedLeagueId) || null : null),
    [selectedLeagueId]
  );

  const handleOpenMatchDetail = useCallback(async (match: FootballMatch) => {
    setActiveMatchDetail(match);
    if (match.externalEventId) {
      setMatchDetailLoading(true);
      try {
        const res = await fetchMatchDetail(match.leagueId, match.externalEventId);
        if (res.ok && res.match) {
          setActiveMatchDetail((current) =>
            current && current.id === match.id ? res.match : current
          );
        }
      } catch {
        // Keep base match details visible if optional summary fails
      } finally {
        setMatchDetailLoading(false);
      }
    }
  }, []);

  const handleOpenMatchById = (matchId: string) => {
    const found = combinedLiveMatches.find((m) => m.id === matchId);
    if (found) handleOpenMatchDetail(found);
  };

  const handleOpenTeamProfile = (teamId: string) => {
    setSelectedTeamId(teamId);
    setActiveView('teams');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLeagueTable = (leagueId: string) => {
    setTableLeagueId(leagueId);
    setActiveView('tables');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectView = (view: AppView) => {
    if (view !== 'teams') {
      setSelectedTeamId(null);
    }
    setActiveView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleFollowTeam = (teamId: string) => {
    setFollowedTeams((prev) =>
      prev.includes(teamId) ? prev.filter((id) => id !== teamId) : [...prev, teamId]
    );
  };

  const alertMatchIds = useMemo(
    () => new Set(matchAlerts.map((a) => a.matchId)),
    [matchAlerts]
  );

  const handleToggleMatchAlert = (match: FootballMatch) => {
    const { nextAlerts, added } = toggleMatchAlert(matchAlerts, match.id);
    setMatchAlerts(nextAlerts);
    if (added) {
      setAlertMatchSnapshots((prev) => ({ ...prev, [match.id]: match }));
      const headline = formatMatchAlertMessage(match);
      setToastAlert({
        match,
        headline,
      });
      dispatchBrowserNotification(
        `Match Alert Set · ${match.homeTeam} vs ${match.awayTeam}`,
        headline,
        match.homeLogo || match.awayLogo
      );
    } else {
      setAlertMatchSnapshots((prev) => {
        const next = { ...prev };
        delete next[match.id];
        return next;
      });
      if (toastAlert?.match.id === match.id) {
        setToastAlert(null);
      }
    }
  };

  const handleUpdateAlertPrefs = (
    matchId: string,
    patch: Partial<Pick<MatchAlertItem, 'notifyKickoff' | 'notifyGoals' | 'notifyFullTime'>>
  ) => {
    setMatchAlerts((prev) => updateMatchAlertPreferences(prev, matchId, patch));
  };

  const handleRemoveAlert = (matchId: string) => {
    setMatchAlerts((prev) => prev.filter((a) => a.matchId !== matchId));
    setAlertMatchSnapshots((prev) => {
      const next = { ...prev };
      delete next[matchId];
      return next;
    });
  };

  const handlePreviewAlert = (match: FootballMatch) => {
    const headline = formatMatchAlertMessage(match);
    setToastAlert({
      match,
      headline,
    });
    dispatchBrowserNotification(
      `Sky Sports · ${match.homeTeam} vs ${match.awayTeam}`,
      headline,
      match.homeLogo || match.awayLogo
    );
  };

  const handleToggleBrowserNotif = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setBrowserNotifStatus('unsupported');
      return;
    }
    if (window.Notification.permission === 'granted') {
      setBrowserNotifEnabled((prev) => !prev);
      setBrowserNotifStatus('granted');
      return;
    }
    try {
      const perm = await window.Notification.requestPermission();
      setBrowserNotifStatus(perm);
      setBrowserNotifEnabled(perm === 'granted');
    } catch {
      setBrowserNotifEnabled(false);
    }
  };

  const alertKnownMatches = useMemo(() => {
    const map = new Map<string, FootballMatch>();
    for (const m of Object.values(alertMatchSnapshots)) {
      map.set(m.id, m);
    }
    for (const m of combinedLiveMatches) {
      map.set(m.id, m);
    }
    return Array.from(map.values());
  }, [alertMatchSnapshots, combinedLiveMatches]);

  const resetFilters = () => {
    setSelectedRegion('all');
    setSelectedLeagueId(null);
    setStatusFilter('all');
    setSearchQuery('');
  };

  const hasActiveFilter =
    selectedRegion !== 'all' || selectedLeagueId !== null || searchQuery.trim().length > 0;

  return (
    <div className="min-h-screen flex flex-col bg-[#0B1117] text-slate-100">
      <Header
        activeView={activeView}
        onSelectView={handleSelectView}
        userLabel={userProfile ? userProfile.displayName : 'Sign In / Profile'}
        isSignedIn={Boolean(userProfile)}
      />

      {activeView === 'home' && (
        <LiveNewsTicker
          headlines={activeHeadlines}
          onOpenMatch={handleOpenMatchById}
          onOpenTeam={handleOpenTeamProfile}
        />
      )}

      <main className="flex-1 mx-auto w-full max-w-[1440px] px-4 sm:px-6 py-5 pb-20 md:pb-8 space-y-5">
        <LiveDataStatusBar
          loading={liveLoading}
          refreshing={liveRefreshing}
          error={liveError}
          lastUpdatedIso={lastUpdatedIso}
          autoRefreshEnabled={autoRefreshEnabled}
          secondsToRefresh={secondsToRefresh}
          liveCount={activeLiveCount}
          refreshIntervalSec={currentRefreshIntervalSec}
          onToggleAutoRefresh={() => setAutoRefreshEnabled((prev) => !prev)}
          onManualRefresh={() => loadLiveData(true)}
        />

        {(activeView === 'home' || activeView === 'matches') && (
          <div className="flex flex-col lg:flex-row gap-6 items-start">
            <SportSidebar
              regions={REGIONS_META}
              leagues={LEAGUES_CATALOG}
              matches={combinedLiveMatches}
              selectedRegion={selectedRegion}
              selectedLeagueId={selectedLeagueId}
              onSelectRegion={setSelectedRegion}
              onSelectLeague={setSelectedLeagueId}
              onOpenLeagueTable={handleOpenLeagueTable}
            />

            <div className="flex-1 min-w-0 w-full space-y-6">
              {/* Multi-Sport Switcher + Search & Headline Competitions Strip */}
              <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 space-y-3">
                {/* Sports Categories */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-[#1D2834]">
                  {SPORT_CATEGORIES.map((sc) => {
                    const active = activeSport === sc.id;
                    return (
                      <button
                        key={sc.id}
                        type="button"
                        onClick={() => setActiveSport(sc.id)}
                        className={`min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-emerald-600 border-emerald-500 text-white'
                            : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                        }`}
                      >
                        {sc.label}
                      </button>
                    );
                  })}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="relative flex-1">
                    <Search
                      className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                      aria-hidden="true"
                    />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search clubs, competitions, countries, or venues..."
                      aria-label="Search football matches, teams, and leagues"
                      className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-10 pr-10 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        aria-label="Clear search"
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-white"
                      >
                        <X className="w-4 h-4" aria-hidden="true" />
                      </button>
                    )}
                  </div>

                  {hasActiveFilter && (
                    <button
                      type="button"
                      onClick={resetFilters}
                      className="min-h-[44px] px-4 py-2 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-medium text-slate-200 hover:border-amber-400/60 hover:text-white transition-colors whitespace-nowrap shrink-0"
                    >
                      Reset Filters
                    </button>
                  )}
                </div>

                {activeSport === 'football' && (
                  <>
                    {/* Headline Competition Quick Filters */}
                    <div className="flex items-center gap-2 overflow-x-auto md:flex-wrap pb-1">
                      {HEADLINE_QUICK_LEAGUES.map((ql) => {
                        const active = selectedLeagueId === ql.id;
                        return (
                          <button
                            key={ql.id}
                            type="button"
                            onClick={() => setSelectedLeagueId(active ? null : ql.id)}
                            className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                              active
                                ? 'bg-emerald-600 border-emerald-500 text-white'
                                : 'bg-[#0F1720] border-[#1D2834] text-slate-300 hover:border-slate-500 hover:text-white'
                            }`}
                          >
                            {ql.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Quick Hub Tools */}
                    <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#1D2834]">
                      <button
                        type="button"
                        onClick={() => handleOpenLeagueTable(selectedLeagueId || 'epl')}
                        className="min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-amber-400/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0"
                      >
                        League Tables
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectView('africa')}
                        className="min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 transition-colors whitespace-nowrap shrink-0"
                      >
                        African Football
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectView('transfers')}
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-[#24313F] bg-[#18222C] text-slate-200 hover:border-emerald-500/50 hover:text-white transition-colors whitespace-nowrap shrink-0"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Transfer Wire</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectView('news')}
                        className="min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-[#24313F] bg-[#18222C] text-slate-200 hover:border-emerald-500/50 hover:text-white transition-colors whitespace-nowrap shrink-0"
                      >
                        Sports News
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectView('players')}
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-[#24313F] bg-[#18222C] text-slate-200 hover:border-emerald-500/50 hover:text-white transition-colors whitespace-nowrap shrink-0"
                      >
                        <BarChart3 className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
                        <span>Player Comparison</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setAlertsModalOpen(true)}
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 transition-colors whitespace-nowrap shrink-0"
                      >
                        <BellRing className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Match Alerts</span>
                        <span className="font-mono tabular-nums">({matchAlerts.length})</span>
                      </button>
                    </div>
                  </>
                )}
              </div>

              {activeSport !== 'football' ? (
                <section aria-label={`${activeSport} live scoreboard`} className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                        {multiSportProvider || `Live ${activeSport} Scoreboard`}
                      </p>
                      <h2 className="font-display text-2xl font-bold text-white capitalize">
                        {activeSport} Live Scores, Fixtures &amp; Results (EAT)
                      </h2>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveSport('football')}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-semibold text-emerald-300 hover:border-emerald-500/60"
                    >
                      Back to Football
                    </button>
                  </div>

                  {multiSportLoading ? (
                    <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex items-center justify-center gap-2.5 text-sm text-slate-300">
                      <Loader2 className="w-6 h-6 animate-spin text-emerald-400" aria-hidden="true" />
                      <span>Retrieving live {activeSport} scoreboard from official feed...</span>
                    </div>
                  ) : multiSportError && multiSportEvents.length === 0 ? (
                    <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-6 space-y-2">
                      <h3 className="font-display text-base font-bold text-white capitalize">
                        Live {activeSport} Data Unavailable
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-300">{multiSportError}</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {multiSportEvents
                        .filter((ev) => {
                          const q = searchQuery.trim().toLowerCase();
                          if (!q) return true;
                          return `${ev.homeTeam} ${ev.awayTeam} ${ev.league} ${ev.venue}`
                            .toLowerCase()
                            .includes(q);
                        })
                        .map((ev) => (
                          <article
                            key={ev.id}
                            className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 flex flex-col justify-between gap-3"
                          >
                            <div className="flex items-center justify-between gap-2 text-xs">
                              <span className="font-medium text-slate-200 truncate">{ev.league}</span>
                              <div className="flex items-center gap-1.5 shrink-0">
                                {ev.status === 'live' && (
                                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-500/15 border border-rose-500/50 text-[10px] font-bold text-rose-400">
                                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
                                    LIVE
                                  </span>
                                )}
                                <span
                                  className={`font-mono tabular-nums font-semibold ${
                                    ev.status === 'live'
                                      ? 'text-emerald-400'
                                      : ev.status === 'result'
                                      ? 'text-amber-400'
                                      : 'text-slate-400'
                                  }`}
                                >
                                  {ev.timeLabel}
                                </span>
                              </div>
                            </div>

                            <div className="space-y-2 py-1">
                              <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2 min-w-0">
                                  {ev.homeLogo && (
                                    <img
                                      src={ev.homeLogo}
                                      alt={ev.homeTeam}
                                      className="w-5 h-5 object-contain shrink-0"
                                      referrerPolicy="no-referrer"
                                    />
                                  )}
                                  <span className="text-sm font-semibold text-white truncate">
                                    {ev.homeTeam}
                                  </span>
                                </div>
                                <span className="font-mono tabular-nums text-base font-bold text-white shrink-0">
                                  {ev.homeScore ?? '—'}
                                </span>
                              </div>
                              <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2 min-w-0">
                                  {ev.awayLogo && (
                                    <img
                                      src={ev.awayLogo}
                                      alt={ev.awayTeam}
                                      className="w-5 h-5 object-contain shrink-0"
                                      referrerPolicy="no-referrer"
                                    />
                                  )}
                                  <span className="text-sm font-semibold text-white truncate">
                                    {ev.awayTeam}
                                  </span>
                                </div>
                                <span className="font-mono tabular-nums text-base font-bold text-white shrink-0">
                                  {ev.awayScore ?? '—'}
                                </span>
                              </div>
                            </div>

                            <div className="border-t border-[#1D2834] pt-2 text-[11px] text-slate-400 truncate">
                              {ev.venue}
                              {ev.detailNote ? ` · ${ev.detailNote}` : ''}
                            </div>
                          </article>
                        ))}
                    </div>
                  )}
                </section>
              ) : activeView === 'home' ? (
                <>
                  {!hasActiveFilter && featuredMatch && (
                    <>
                      <FeaturedMatchBanner
                        match={featuredMatch}
                        isAlertSet={alertMatchIds.has(featuredMatch.id)}
                        onToggleAlert={handleToggleMatchAlert}
                        onOpenMatchDetail={handleOpenMatchDetail}
                        onOpenTeamProfile={handleOpenTeamProfile}
                      />
                      <SeasonContinuationStrip
                        liveLeaders={liveLeaders}
                        loading={liveLoading}
                        onOpenLeagueTable={handleOpenLeagueTable}
                        onOpenTransfers={() => handleSelectView('transfers')}
                      />
                    </>
                  )}

                  {!hasActiveFilter && liveLoading && !featuredMatch && (
                    <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3 text-center">
                      <Loader2 className="w-8 h-8 animate-spin text-emerald-400" aria-hidden="true" />
                      <p className="text-sm font-medium text-white">
                        Retrieving real football scores, fixtures, club crests, and standings...
                      </p>
                    </div>
                  )}

                  {selectedLeagueMeta && (
                    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-400/35 bg-[#121A22] px-4 py-3">
                      <div>
                        <p className="text-xs font-semibold text-amber-400">
                          Filtered Competition · {selectedLeagueMeta.country}
                        </p>
                        <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
                          <span>{selectedLeagueMeta.name}</span>
                          {leagueFetchLoading && (
                            <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
                          )}
                        </h2>
                        {leagueUnavailableNote && (
                          <p className="mt-1 text-xs text-amber-300">{leagueUnavailableNote}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleOpenLeagueTable(selectedLeagueMeta.id)}
                          className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
                        >
                          Open Standings Table
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Section 1: LIVE NOW */}
                  <section aria-label="Live football scores" className="space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500/15 border border-rose-500/50 text-[10px] font-bold tracking-wider text-rose-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
                          LIVE NOW
                        </span>
                        <h2 className="font-display text-lg font-bold text-white">
                          Live Football Scores
                        </h2>
                        <span className="font-mono tabular-nums text-xs text-emerald-400">
                          ({sectionLiveMatches.length})
                        </span>
                      </div>
                      <span className="text-xs text-slate-400">
                        Live API · Auto-updating (EAT)
                      </span>
                    </div>

                    {sectionLiveMatches.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                        {sectionLiveMatches.map((match) => (
                          <MatchCard
                            key={match.id}
                            match={match}
                            isAlertSet={alertMatchIds.has(match.id)}
                            onToggleAlert={handleToggleMatchAlert}
                            onOpenMatchDetail={handleOpenMatchDetail}
                            onOpenTeamProfile={handleOpenTeamProfile}
                          />
                        ))}
                      </div>
                    ) : (
                      <p className="rounded-xl border border-[#24313F] bg-[#121A22] px-4 py-4 text-xs text-slate-400">
                        {liveLoading
                          ? 'Checking live matchdays across global competitions...'
                          : 'No live kickoffs in progress right now for the active filter. Check Today & Upcoming Fixtures or Completed Results below.'}
                      </p>
                    )}
                  </section>

                  {/* Section 2: TODAY & TOMORROW'S FIXTURES (EAT) */}
                  <section aria-label="Upcoming football fixtures" className="space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-amber-400" aria-hidden="true" />
                        <h2 className="font-display text-lg font-bold text-white">
                          Today &amp; Upcoming Fixtures (EAT)
                        </h2>
                        <span className="font-mono tabular-nums text-xs text-slate-400">
                          ({sectionUpcomingMatches.length})
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setStatusFilter('upcoming');
                          handleSelectView('matches');
                        }}
                        className="text-xs font-semibold text-emerald-400 hover:text-emerald-300"
                      >
                        All fixtures →
                      </button>
                    </div>

                    {sectionUpcomingMatches.length > 0 ? (
                      <div className="space-y-4">
                        {eatFixturesGrouped.today.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                              Today&apos;s Matches (EAT · {eatFixturesGrouped.today.length})
                            </p>
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                              {eatFixturesGrouped.today.slice(0, 6).map((match) => (
                                <MatchCard
                                  key={match.id}
                                  match={match}
                                  isAlertSet={alertMatchIds.has(match.id)}
                                  onToggleAlert={handleToggleMatchAlert}
                                  onOpenMatchDetail={handleOpenMatchDetail}
                                  onOpenTeamProfile={handleOpenTeamProfile}
                                />
                              ))}
                            </div>
                          </div>
                        )}

                        {eatFixturesGrouped.tomorrow.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                              Tomorrow&apos;s Fixtures (EAT · {eatFixturesGrouped.tomorrow.length})
                            </p>
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                              {eatFixturesGrouped.tomorrow.slice(0, 6).map((match) => (
                                <MatchCard
                                  key={match.id}
                                  match={match}
                                  isAlertSet={alertMatchIds.has(match.id)}
                                  onToggleAlert={handleToggleMatchAlert}
                                  onOpenMatchDetail={handleOpenMatchDetail}
                                  onOpenTeamProfile={handleOpenTeamProfile}
                                />
                              ))}
                            </div>
                          </div>
                        )}

                        {eatFixturesGrouped.today.length === 0 &&
                          eatFixturesGrouped.tomorrow.length === 0 && (
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                              {eatFixturesGrouped.upcomingOther.slice(0, 6).map((match) => (
                                <MatchCard
                                  key={match.id}
                                  match={match}
                                  isAlertSet={alertMatchIds.has(match.id)}
                                  onToggleAlert={handleToggleMatchAlert}
                                  onOpenMatchDetail={handleOpenMatchDetail}
                                  onOpenTeamProfile={handleOpenTeamProfile}
                                />
                              ))}
                            </div>
                          )}
                      </div>
                    ) : (
                      <p className="rounded-xl border border-[#24313F] bg-[#121A22] px-4 py-4 text-xs text-slate-400">
                        {liveLoading || leagueFetchLoading
                          ? 'Loading scheduled fixtures...'
                          : leagueUnavailableNote || 'No upcoming fixtures available for your current selection.'}
                      </p>
                    )}
                  </section>

                  {/* Section 3: YESTERDAY'S RESULTS & FINISHED */}
                  <section aria-label="Recent match results" className="space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-amber-400" aria-hidden="true" />
                        <h2 className="font-display text-lg font-bold text-white">
                          Yesterday&apos;s Results &amp; Finished (EAT)
                        </h2>
                        <span className="font-mono tabular-nums text-xs text-slate-400">
                          ({sectionRecentResults.length})
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setStatusFilter('result');
                          handleSelectView('matches');
                        }}
                        className="text-xs font-semibold text-emerald-400 hover:text-emerald-300"
                      >
                        All results →
                      </button>
                    </div>

                    {sectionRecentResults.length > 0 ? (
                      <div className="space-y-4">
                        {eatResultsGrouped.yesterday.length > 0 && (
                          <p className="text-xs font-semibold uppercase tracking-wider text-amber-300">
                            Yesterday&apos;s Results ({eatResultsGrouped.yesterday.length})
                          </p>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                          {(eatResultsGrouped.yesterday.length > 0
                            ? eatResultsGrouped.yesterday
                            : eatResultsGrouped.earlier
                          )
                            .slice(0, 6)
                            .map((match) => (
                              <MatchCard
                                key={match.id}
                                match={match}
                                isAlertSet={alertMatchIds.has(match.id)}
                                onToggleAlert={handleToggleMatchAlert}
                                onOpenMatchDetail={handleOpenMatchDetail}
                                onOpenTeamProfile={handleOpenTeamProfile}
                              />
                            ))}
                        </div>
                      </div>
                    ) : (
                      <p className="rounded-xl border border-[#24313F] bg-[#121A22] px-4 py-4 text-xs text-slate-400">
                        {liveLoading || leagueFetchLoading
                          ? 'Loading completed matchday results...'
                          : leagueUnavailableNote || 'No completed matches available for your current selection.'}
                      </p>
                    )}
                  </section>

                  {/* League Tables & Transfer Centre Quick Entry Footer Strip */}
                  <section
                    aria-label="Explore league tables and transfer wire"
                    className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <Trophy className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" aria-hidden="true" />
                      <div>
                        <h2 className="font-display text-base font-bold text-white">
                          Global &amp; African Football Hub ({LEAGUES_CATALOG.length} Competitions)
                        </h2>
                        <p className="mt-0.5 text-xs text-slate-400">
                          Automatic standings, fixtures &amp; authentic club crests for Premier League, Champions League, La Liga, Bundesliga, Serie A, Roshn Saudi League, South Africa PSL, Kenya FKF, plus Player Comparison &amp; Live Transfers.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleSelectView('transfers')}
                        className="min-h-[44px] px-4 py-2.5 rounded-lg border border-[#24313F] bg-[#18222C] text-xs sm:text-sm font-semibold text-amber-300 hover:border-amber-400/50 transition-colors whitespace-nowrap"
                      >
                        Transfer Wire
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenLeagueTable(selectedLeagueId || 'epl')}
                        className="min-h-[44px] px-5 py-2.5 rounded-lg bg-emerald-600 text-xs sm:text-sm font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
                      >
                        View League Tables
                      </button>
                    </div>
                  </section>
                </>
              ) : (
                /* Full Fixtures & Scores View */
                <section aria-label="All global football fixtures and scores" className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h1 className="font-display text-2xl font-bold text-white tracking-tight">
                        Global Fixtures, Live Scores &amp; Results
                      </h1>
                      <p className="text-xs text-slate-400">
                        Showing {filteredAllMatches.length} real matches retrieved from live football backend (Tanzania EAT)
                      </p>
                    </div>

                    <div className="flex items-center gap-2 overflow-x-auto pb-1">
                      {(
                        [
                          { id: 'all', label: 'All' },
                          { id: 'live', label: 'Live' },
                          { id: 'upcoming', label: 'Upcoming' },
                          { id: 'result', label: 'Results' },
                        ] as const
                      ).map((tab) => {
                        const active = statusFilter === tab.id;
                        return (
                          <button
                            key={tab.id}
                            type="button"
                            onClick={() => setStatusFilter(tab.id)}
                            className={`min-h-[40px] px-4 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                              active
                                ? 'bg-emerald-600 border-emerald-500 text-white'
                                : 'bg-[#121A22] border-[#24313F] text-slate-300 hover:text-white'
                            }`}
                          >
                            {tab.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {(liveLoading || leagueFetchLoading) && filteredAllMatches.length === 0 ? (
                    <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3">
                      <Loader2 className="w-7 h-7 animate-spin text-emerald-400" aria-hidden="true" />
                      <p className="text-xs sm:text-sm text-slate-300">Fetching live matches and fixtures...</p>
                    </div>
                  ) : filteredAllMatches.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {filteredAllMatches.map((match) => (
                        <MatchCard
                          key={match.id}
                          match={match}
                          isAlertSet={alertMatchIds.has(match.id)}
                          onToggleAlert={handleToggleMatchAlert}
                          onOpenMatchDetail={handleOpenMatchDetail}
                          onOpenTeamProfile={handleOpenTeamProfile}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 text-center space-y-3">
                      <p className="text-sm text-slate-300">
                        {leagueUnavailableNote || 'No live football matches found for your current filters.'}
                      </p>
                      <button
                        type="button"
                        onClick={resetFilters}
                        className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
                      >
                        Clear All Filters
                      </button>
                    </div>
                  )}
                </section>
              )}
            </div>
          </div>
        )}

        {activeView === 'tables' && (
          <LeagueTablesView
            leagues={LEAGUES_CATALOG}
            selectedLeagueId={tableLeagueId}
            autoRefreshEnabled={autoRefreshEnabled}
            standingsRefreshTrigger={standingsRevision}
            onSelectLeagueId={setTableLeagueId}
            onOpenTeamProfile={handleOpenTeamProfile}
          />
        )}

        {activeView === 'africa' && (
          <AfricanFootballView
            onOpenMatchDetail={handleOpenMatchDetail}
            onOpenTeamProfile={handleOpenTeamProfile}
            onOpenLeagueTable={handleOpenLeagueTable}
            isAlertSet={(id) => alertMatchIds.has(id)}
            onToggleAlert={handleToggleMatchAlert}
          />
        )}

        {activeView === 'teams' && (
          <TeamsView
            teams={liveTeams}
            leagues={LEAGUES_CATALOG}
            matches={combinedLiveMatches}
            players={livePlayers}
            loading={liveLoading}
            selectedTeamId={selectedTeamId}
            followedTeams={followedTeams}
            onSelectTeam={setSelectedTeamId}
            onToggleFollowTeam={handleToggleFollowTeam}
            onOpenMatchDetail={handleOpenMatchDetail}
            onOpenLeagueTable={handleOpenLeagueTable}
          />
        )}

        {activeView === 'players' && (
          <PlayersView
            players={livePlayers}
            leagues={LEAGUES_CATALOG}
            loading={playersLoading}
            error={playersError}
            onRetry={loadLivePlayers}
            onOpenTeamProfile={handleOpenTeamProfile}
          />
        )}

        {activeView === 'transfers' && (
          <TransfersView
            stories={liveTransfers}
            loading={transfersLoading}
            error={transfersError}
            lastUpdatedIso={transfersFetchedAt}
            onRefresh={loadLiveTransfers}
          />
        )}

        {activeView === 'news' && (
          <NewsView
            articles={liveNews}
            loading={newsLoading}
            error={newsError}
            lastUpdatedIso={newsFetchedAt}
            onRefresh={loadLiveNews}
          />
        )}

        {activeView === 'profile' && (
          <ProfileView
            profile={userProfile}
            leagues={LEAGUES_CATALOG}
            teams={liveTeams}
            followedTeams={followedTeams}
            onSaveProfile={setUserProfile}
            onSignOutProfile={() => setUserProfile(null)}
            onOpenTeamProfile={handleOpenTeamProfile}
            onToggleFollowTeam={handleToggleFollowTeam}
          />
        )}
      </main>

      <footer className="border-t border-[#1D2834] bg-[#0B1117] py-5 px-4 sm:px-6 mb-14 md:mb-0">
        <div className="mx-auto max-w-[1440px] flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <span className="font-display font-semibold text-slate-300">SKY SPORTS</span>
          <span>
            Automatic real-time football scores, fixtures, standings &amp; club crests · Tanzania Local Time (EAT / UTC+3)
          </span>
        </div>
      </footer>

      <MobileBottomNav activeView={activeView} onSelectView={handleSelectView} />

      <MatchDetailModal
        match={activeMatchDetail}
        loading={matchDetailLoading}
        isAlertSet={activeMatchDetail ? alertMatchIds.has(activeMatchDetail.id) : false}
        onToggleAlert={handleToggleMatchAlert}
        onClose={() => setActiveMatchDetail(null)}
        onOpenTeamProfile={handleOpenTeamProfile}
      />

      <MatchAlertsModal
        isOpen={alertsModalOpen}
        alerts={matchAlerts}
        matches={alertKnownMatches}
        browserNotifStatus={browserNotifStatus}
        browserNotifEnabled={browserNotifEnabled}
        onToggleBrowserNotif={handleToggleBrowserNotif}
        onClose={() => setAlertsModalOpen(false)}
        onUpdateAlert={handleUpdateAlertPrefs}
        onRemoveAlert={handleRemoveAlert}
        onPreviewAlert={handlePreviewAlert}
        onOpenMatchDetail={handleOpenMatchDetail}
      />

      <MatchAlertToast
        match={toastAlert?.match || null}
        headline={toastAlert?.headline || ''}
        onDismiss={() => setToastAlert(null)}
        onOpenMatchDetail={(match) => {
          setToastAlert(null);
          handleOpenMatchDetail(match);
        }}
      />
    </div>
  );
}
