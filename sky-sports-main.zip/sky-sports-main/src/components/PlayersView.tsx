import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  Award,
  BarChart3,
  ExternalLink,
  Loader2,
  Search,
  Trophy,
  X,
} from 'lucide-react';
import {
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import type { LeagueInfo, PlayerPosition, PlayerStat } from '../types/football';
import {
  buildComparisonRadarData,
  buildPlayerComparison,
  filterAndSortPlayers,
  type PlayerSortKey,
} from '../utils/footballUtils';
import { PlayerAvatar } from './PlayerAvatar';
import { TeamCrest } from './TeamCrest';

interface PlayersViewProps {
  players: PlayerStat[];
  leagues: LeagueInfo[];
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  onOpenTeamProfile: (teamId: string) => void;
}

export const PlayersView: React.FC<PlayersViewProps> = ({
  players,
  leagues,
  loading = false,
  error = null,
  onRetry,
  onOpenTeamProfile,
}) => {
  const [mode, setMode] = useState<'leaderboard' | 'compare'>('leaderboard');
  const [leagueId, setLeagueId] = useState('all');
  const [position, setPosition] = useState<'all' | PlayerPosition>('all');
  const [sortBy, setSortBy] = useState<PlayerSortKey>('goals');
  const [query, setQuery] = useState('');
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerStat | null>(null);

  const [compareIdA, setCompareIdA] = useState<string>('');
  const [compareIdB, setCompareIdB] = useState<string>('');

  // Initialize or keep valid comparison pair from loaded live players
  useEffect(() => {
    if (players.length === 0) return;
    if (!compareIdA || !players.some((p) => p.id === compareIdA)) {
      setCompareIdA(players[0]!.id);
    }
    if (!compareIdB || !players.some((p) => p.id === compareIdB)) {
      setCompareIdB((players[1] || players[0])!.id);
    }
  }, [players, compareIdA, compareIdB]);

  const playerLeagues = useMemo(() => {
    const ids = new Set(players.map((p) => p.leagueId));
    return leagues.filter((l) => ids.has(l.id));
  }, [players, leagues]);

  const filteredPlayers = useMemo(
    () =>
      filterAndSortPlayers(players, {
        leagueId,
        position,
        query,
        sortBy,
      }),
    [players, leagueId, position, query, sortBy]
  );

  const playerA = useMemo(
    () => players.find((p) => p.id === compareIdA) || players[0],
    [players, compareIdA]
  );

  const playerB = useMemo(
    () => players.find((p) => p.id === compareIdB) || players[1] || players[0],
    [players, compareIdB]
  );

  const comparisonMetrics = useMemo(() => {
    if (!playerA || !playerB) return [];
    return buildPlayerComparison(playerA, playerB);
  }, [playerA, playerB]);

  const radarData = useMemo(() => {
    if (!playerA || !playerB) return [];
    return buildComparisonRadarData(playerA, playerB);
  }, [playerA, playerB]);

  const dynamicPresets = useMemo(() => {
    if (players.length < 2) return [];
    const presets: { label: string; idA: string; idB: string }[] = [];
    for (let i = 0; i + 1 < Math.min(players.length, 8); i += 2) {
      const a = players[i]!;
      const b = players[i + 1]!;
      presets.push({
        label: `${a.name} vs ${b.name}`,
        idA: a.id,
        idB: b.id,
      });
    }
    return presets;
  }, [players]);

  const handleStartCompare = (player: PlayerStat) => {
    setCompareIdA(player.id);
    if (player.id === compareIdB) {
      const alt = players.find((p) => p.id !== player.id);
      if (alt) setCompareIdB(alt.id);
    }
    setSelectedPlayer(null);
    setMode('compare');
  };

  const handleSwapPlayers = () => {
    setCompareIdA(compareIdB);
    setCompareIdB(compareIdA);
  };

  const positions: { id: 'all' | PlayerPosition; label: string }[] = [
    { id: 'all', label: 'All Positions' },
    { id: 'FW', label: 'Forwards' },
    { id: 'MF', label: 'Midfielders' },
    { id: 'DF', label: 'Defenders' },
    { id: 'GK', label: 'Goalkeepers' },
  ];

  const hasPositionData = useMemo(
    () => players.some((p) => p.position !== 'N/A'),
    [players]
  );

  return (
    <section aria-label="Player statistics and comparison" className="space-y-5">
      {/* Header & Mode Switch */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
              <Award className="w-4 h-4" aria-hidden="true" />
              <span>2026/27 Live Season Leaders · Official League Statistics</span>
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-white tracking-tight">
              {mode === 'leaderboard' ? 'Player Statistics' : 'Player Comparison'}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setMode('leaderboard')}
              aria-pressed={mode === 'leaderboard'}
              className={`inline-flex items-center gap-2 min-h-[42px] px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold border transition-colors whitespace-nowrap ${
                mode === 'leaderboard'
                  ? 'bg-emerald-600 border-emerald-500 text-white'
                  : 'bg-[#0B1117] border-[#24313F] text-slate-300 hover:text-white'
              }`}
            >
              <Trophy className="w-4 h-4" aria-hidden="true" />
              <span>Leaderboard</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('compare')}
              aria-pressed={mode === 'compare'}
              disabled={players.length < 2}
              className={`inline-flex items-center gap-2 min-h-[42px] px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold border transition-colors whitespace-nowrap disabled:opacity-50 ${
                mode === 'compare'
                  ? 'bg-emerald-600 border-emerald-500 text-white'
                  : 'bg-[#0B1117] border-[#24313F] text-slate-300 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4 h-4" aria-hidden="true" />
              <span>Player Comparison</span>
            </button>
          </div>
        </div>

        {mode === 'leaderboard' && (
          <div className="mt-4 pt-4 border-t border-[#1D2834] space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <select
                aria-label="Filter players by competition"
                value={leagueId}
                onChange={(e) => setLeagueId(e.target.value)}
                className="min-h-[42px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="all">All Competitions</option>
                {playerLeagues.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>

              <select
                aria-label="Sort players by metric"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as PlayerSortKey)}
                className="min-h-[42px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="goals">Sort: Goals</option>
                <option value="assists">Sort: Assists</option>
                <option value="appearances">Sort: Appearances</option>
              </select>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {hasPositionData ? (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {positions.map((pos) => (
                    <button
                      key={pos.id}
                      type="button"
                      onClick={() => setPosition(pos.id)}
                      className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                        position === pos.id
                          ? 'bg-emerald-600 border-emerald-500 text-white'
                          : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                      }`}
                    >
                      {pos.label}
                    </button>
                  ))}
                </div>
              ) : (
                <span className="text-xs text-slate-400">
                  Showing official scoring &amp; assist leaders across {playerLeagues.length} leagues
                </span>
              )}

              <div className="relative w-full sm:w-64">
                <Search
                  className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search player or club..."
                  aria-label="Search player statistics"
                  className="w-full min-h-[40px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-8 pr-8 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery('')}
                    aria-label="Clear player search"
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Loading / Error / Empty States */}
      {loading && players.length === 0 ? (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3 text-center">
          <Loader2 className="w-7 h-7 animate-spin text-emerald-400" aria-hidden="true" />
          <p className="text-sm font-medium text-white">
            Retrieving live player goalscorers, assists &amp; club logos...
          </p>
        </div>
      ) : error && players.length === 0 ? (
        <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-6 space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Live Player Statistics Unavailable
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">{error}</p>
            </div>
          </div>
          {onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Retry Player Stats
            </button>
          )}
        </div>
      ) : players.length === 0 ? (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 text-center text-sm text-slate-400">
          Live player statistics are currently unavailable from the data provider.
        </div>
      ) : mode === 'leaderboard' ? (
        /* Player Stats Table */
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#24313F] bg-[#0F1720] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <th className="py-3 pl-4 pr-2">#</th>
                  <th className="py-3 px-2 min-w-[180px]">Player</th>
                  <th className="py-3 px-2 hidden sm:table-cell">Club</th>
                  <th className="py-3 px-2 hidden lg:table-cell">League</th>
                  <th className="py-3 px-2 text-center font-mono">Apps</th>
                  <th className="py-3 px-2 text-center font-mono text-emerald-400">Goals</th>
                  <th className="py-3 px-2 text-center font-mono">Assists</th>
                  <th className="py-3 px-2 text-center font-mono hidden md:table-cell">G + A</th>
                  <th className="py-3 pl-2 pr-4 text-right">Compare</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D2834] text-xs sm:text-sm">
                {filteredPlayers.map((player, index) => (
                  <tr
                    key={player.id}
                    className="hover:bg-[#18222C]/70 transition-colors"
                  >
                    <td className="py-3 pl-4 pr-2 font-mono tabular-nums text-slate-400">
                      {index + 1}
                    </td>
                    <td className="py-3 px-2">
                      <button
                        type="button"
                        onClick={() => setSelectedPlayer(player)}
                        className="flex items-center gap-2.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
                      >
                        <PlayerAvatar
                          name={player.name}
                          src={player.headshotUrl}
                          accentColor={player.teamColor}
                          size="sm"
                        />
                        <div className="min-w-0">
                          <div className="font-semibold text-white group-hover:text-emerald-300 transition-colors truncate">
                            {player.name}
                          </div>
                          <div className="text-[11px] text-slate-400 sm:hidden truncate">
                            {player.teamName} · {player.leagueName}
                          </div>
                        </div>
                      </button>
                    </td>
                    <td className="py-3 px-2 hidden sm:table-cell">
                      <button
                        type="button"
                        onClick={() => onOpenTeamProfile(player.teamId)}
                        className="inline-flex items-center gap-2 text-left text-slate-300 hover:text-white"
                      >
                        <TeamCrest
                          teamId={player.teamId}
                          shortName={player.teamShort}
                          color={player.teamColor}
                          logoUrl={player.clubLogoUrl}
                          size="sm"
                        />
                        <span>{player.teamName}</span>
                      </button>
                    </td>
                    <td className="py-3 px-2 text-xs text-slate-400 hidden lg:table-cell">
                      {player.leagueName}
                    </td>
                    <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                      {player.appearances}
                    </td>
                    <td className="py-3 px-2 text-center font-mono tabular-nums font-bold text-emerald-400">
                      {player.goals}
                    </td>
                    <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-200">
                      {player.assists}
                    </td>
                    <td className="py-3 px-2 text-center font-mono tabular-nums font-semibold text-amber-300 hidden md:table-cell">
                      {player.goals + player.assists}
                    </td>
                    <td className="py-3 pl-2 pr-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleStartCompare(player)}
                        aria-label={`Compare ${player.name}`}
                        className="min-h-[34px] px-2.5 py-1 rounded-lg border border-[#24313F] bg-[#0B1117] text-[11px] font-semibold text-slate-200 hover:border-emerald-500/60 hover:text-emerald-300 transition-colors whitespace-nowrap"
                      >
                        Compare
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredPlayers.length === 0 && (
            <p className="p-6 text-center text-sm text-slate-400">
              No player statistics match the selected filters.
            </p>
          )}
        </div>
      ) : (
        /* Player Comparison Dashboard */
        playerA &&
        playerB && (
          <div className="space-y-5">
            {/* Quick Presets from Top Live Leaders */}
            {dynamicPresets.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                <span className="text-xs font-semibold text-slate-400 shrink-0">Quick Matchups:</span>
                {dynamicPresets.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setCompareIdA(preset.idA);
                      setCompareIdB(preset.idB);
                    }}
                    className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                      compareIdA === preset.idA && compareIdB === preset.idB
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#121A22] border-[#24313F] text-slate-300 hover:text-white'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            )}

            {/* Player A vs Player B Selectors & Identity Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-4 items-center">
              {/* Player A Card */}
              <div className="rounded-xl border border-emerald-500/40 bg-[#121A22] p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="compare-player-a" className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                    Player A
                  </label>
                  <span className="font-mono text-xs text-slate-400">
                    {playerA.appearances} Apps · {playerA.goals + playerA.assists} G+A
                  </span>
                </div>
                <select
                  id="compare-player-a"
                  aria-label="Select Player A for comparison"
                  value={playerA.id}
                  onChange={(e) => setCompareIdA(e.target.value)}
                  className="w-full min-h-[42px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
                >
                  {players.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.teamName} · {p.leagueName})
                    </option>
                  ))}
                </select>
                <div className="flex items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => onOpenTeamProfile(playerA.teamId)}
                    className="flex items-center gap-3 text-left group min-w-0"
                  >
                    <PlayerAvatar
                      name={playerA.name}
                      src={playerA.headshotUrl}
                      accentColor={playerA.teamColor}
                      size="md"
                    />
                    <TeamCrest
                      teamId={playerA.teamId}
                      shortName={playerA.teamShort}
                      color={playerA.teamColor}
                      logoUrl={playerA.clubLogoUrl}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="font-display text-base font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                        {playerA.name}
                      </div>
                      <div className="text-xs text-slate-400 truncate">
                        {playerA.teamName} · {playerA.leagueName}
                      </div>
                    </div>
                  </button>
                  <div className="text-right">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">Goals</div>
                    <div className="font-mono text-xl font-bold text-emerald-400">{playerA.goals}</div>
                  </div>
                </div>
              </div>

              {/* Swap Button */}
              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={handleSwapPlayers}
                  aria-label="Swap Player A and Player B"
                  className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-[#24313F] bg-[#18222C] text-slate-200 hover:border-amber-400 hover:text-amber-300 transition-colors"
                >
                  <ArrowLeftRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>

              {/* Player B Card */}
              <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="compare-player-b" className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                    Player B
                  </label>
                  <span className="font-mono text-xs text-slate-400">
                    {playerB.appearances} Apps · {playerB.goals + playerB.assists} G+A
                  </span>
                </div>
                <select
                  id="compare-player-b"
                  aria-label="Select Player B for comparison"
                  value={playerB.id}
                  onChange={(e) => setCompareIdB(e.target.value)}
                  className="w-full min-h-[42px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                >
                  {players.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.teamName} · {p.leagueName})
                    </option>
                  ))}
                </select>
                <div className="flex items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => onOpenTeamProfile(playerB.teamId)}
                    className="flex items-center gap-3 text-left group min-w-0"
                  >
                    <PlayerAvatar
                      name={playerB.name}
                      src={playerB.headshotUrl}
                      accentColor={playerB.teamColor}
                      size="md"
                    />
                    <TeamCrest
                      teamId={playerB.teamId}
                      shortName={playerB.teamShort}
                      color={playerB.teamColor}
                      logoUrl={playerB.clubLogoUrl}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="font-display text-base font-bold text-white group-hover:text-amber-300 transition-colors truncate">
                        {playerB.name}
                      </div>
                      <div className="text-xs text-slate-400 truncate">
                        {playerB.teamName} · {playerB.leagueName}
                      </div>
                    </div>
                  </button>
                  <div className="text-right">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">Goals</div>
                    <div className="font-mono text-xl font-bold text-amber-400">{playerB.goals}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Radar Chart & Head-to-Head Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <div className="lg:col-span-5 rounded-xl border border-[#24313F] bg-[#121A22] p-5">
                <h2 className="font-display text-base font-bold text-white">
                  Performance Profile (Normalized 0–100)
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {playerA.name} vs {playerB.name}
                </p>
                <div className="h-[300px] w-full mt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="72%" data={radarData}>
                      <PolarGrid stroke="#24313F" />
                      <PolarAngleAxis dataKey="metric" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                      <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                      <Radar
                        name={playerA.name}
                        dataKey="A"
                        stroke="#10B981"
                        fill="#10B981"
                        fillOpacity={0.28}
                      />
                      <Radar
                        name={playerB.name}
                        dataKey="B"
                        stroke="#F59E0B"
                        fill="#F59E0B"
                        fillOpacity={0.25}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0B1117',
                          borderColor: '#24313F',
                          borderRadius: '8px',
                          fontSize: '12px',
                          color: '#F8FAFC',
                        }}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="lg:col-span-7 rounded-xl border border-[#24313F] bg-[#121A22] p-5">
                <h2 className="font-display text-base font-bold text-white">
                  Head-to-Head Statistical Breakdown
                </h2>
                <div className="mt-4 space-y-3">
                  {comparisonMetrics.map((m) => {
                    const isUnavailable = m.winner === 'unavailable' || m.valueA === null || m.valueB === null;
                    const total = !isUnavailable ? (m.valueA ?? 0) + (m.valueB ?? 0) : 0;
                    const pctA = !isUnavailable && total > 0 ? Math.round(((m.valueA ?? 0) / total) * 100) : 50;
                    const pctB = 100 - pctA;

                    return (
                      <div key={m.key} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span
                            className={`font-mono tabular-nums font-bold ${
                              m.winner === 'A'
                                ? 'text-emerald-400'
                                : isUnavailable
                                ? 'text-slate-500'
                                : 'text-slate-300'
                            }`}
                          >
                            {m.displayA}
                          </span>
                          <span className="text-slate-400 font-medium">{m.label}</span>
                          <span
                            className={`font-mono tabular-nums font-bold ${
                              m.winner === 'B'
                                ? 'text-amber-400'
                                : isUnavailable
                                ? 'text-slate-500'
                                : 'text-slate-300'
                            }`}
                          >
                            {m.displayB}
                          </span>
                        </div>
                        {isUnavailable ? (
                          <div className="h-2 w-full rounded-full bg-[#1D2834]" />
                        ) : (
                          <div className="flex h-2 w-full overflow-hidden rounded-full bg-[#0B1117]">
                            <div
                              className="bg-emerald-500 transition-all"
                              style={{ width: `${pctA}%` }}
                            />
                            <div
                              className="bg-amber-400 transition-all"
                              style={{ width: `${pctB}%` }}
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )
      )}

      {/* Player Stat Detail Modal */}
      {selectedPlayer && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Player details for ${selectedPlayer.name}`}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setSelectedPlayer(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <PlayerAvatar
                  name={selectedPlayer.name}
                  src={selectedPlayer.headshotUrl}
                  accentColor={selectedPlayer.teamColor}
                  size="lg"
                />
                <TeamCrest
                  teamId={selectedPlayer.teamId}
                  shortName={selectedPlayer.teamShort}
                  color={selectedPlayer.teamColor}
                  logoUrl={selectedPlayer.clubLogoUrl}
                  size="sm"
                />
                <div className="min-w-0">
                  <h2 className="font-display text-xl font-bold text-white truncate">
                    {selectedPlayer.name}
                  </h2>
                  <p className="text-xs text-slate-400 truncate">
                    {selectedPlayer.teamName} · {selectedPlayer.leagueName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPlayer(null)}
                aria-label="Close player statistics"
                className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-[#18222C]"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-3 text-center">
              <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                <div className="text-[11px] text-slate-400">Goals</div>
                <div className="mt-1 font-mono tabular-nums text-xl font-bold text-emerald-400">
                  {selectedPlayer.goals}
                </div>
              </div>
              <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                <div className="text-[11px] text-slate-400">Assists</div>
                <div className="mt-1 font-mono tabular-nums text-xl font-bold text-white">
                  {selectedPlayer.assists}
                </div>
              </div>
              <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                <div className="text-[11px] text-slate-400">Appearances</div>
                <div className="mt-1 font-mono tabular-nums text-xl font-bold text-amber-400">
                  {selectedPlayer.appearances}
                </div>
              </div>
            </div>

            <dl className="mt-4 divide-y divide-[#1D2834] text-xs">
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Goal Contributions (G+A)</dt>
                <dd className="font-mono tabular-nums text-white font-semibold">
                  {selectedPlayer.goals + selectedPlayer.assists}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Goals per Match</dt>
                <dd className="font-mono tabular-nums text-white">
                  {selectedPlayer.appearances > 0
                    ? (selectedPlayer.goals / selectedPlayer.appearances).toFixed(2)
                    : '0.00'}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Nationality &amp; Jersey</dt>
                <dd className="text-white font-medium">
                  {selectedPlayer.nationality}
                  {selectedPlayer.jersey ? ` · #${selectedPlayer.jersey}` : ''}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Position &amp; Age</dt>
                <dd className="text-white font-medium">
                  {selectedPlayer.position} ·{' '}
                  {typeof selectedPlayer.age === 'number' ? `${selectedPlayer.age} yrs` : 'N/A'}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Market Value</dt>
                <dd className="text-slate-400 font-medium">
                  {selectedPlayer.marketValue || 'Not provided by live API'}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Previous Clubs</dt>
                <dd className="text-slate-400 font-medium text-right">
                  {selectedPlayer.previousClubs && selectedPlayer.previousClubs.length > 0
                    ? selectedPlayer.previousClubs.join(', ')
                    : 'Not provided by live API'}
                </dd>
              </div>
              <div className="py-2 flex justify-between">
                <dt className="text-slate-400">Pass Accuracy / Rating</dt>
                <dd className="font-mono tabular-nums text-white">
                  {selectedPlayer.passAccuracy !== null ? `${selectedPlayer.passAccuracy}%` : 'N/A'} ·{' '}
                  {selectedPlayer.rating !== null ? selectedPlayer.rating.toFixed(2) : 'N/A'}
                </dd>
              </div>
            </dl>

            <p className="mt-3 rounded-lg border border-[#1D2834] bg-[#0F1720] px-3 py-2 text-[11px] text-slate-300 leading-relaxed">
              {selectedPlayer.name} features for {selectedPlayer.teamName} in {selectedPlayer.leagueName}, recording {selectedPlayer.goals} goals and {selectedPlayer.assists} assists across {selectedPlayer.appearances} verified appearances in the 2026/27 campaign.
            </p>

            <div className="mt-5 flex flex-wrap items-center justify-end gap-2">
              {selectedPlayer.externalUrl && (
                <a
                  href={selectedPlayer.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg border border-amber-400/50 bg-amber-500/10 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors"
                >
                  <span>Full Stats</span>
                  <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                </a>
              )}
              <button
                type="button"
                onClick={() => handleStartCompare(selectedPlayer)}
                className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
              >
                Compare {selectedPlayer.name}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
