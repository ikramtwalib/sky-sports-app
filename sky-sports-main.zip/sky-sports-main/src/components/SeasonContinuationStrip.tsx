import React from 'react';
import { Calendar, ChevronRight, Layers, Loader2 } from 'lucide-react';
import type { LeagueLeaderItem } from '../types/football';
import { TeamCrest } from './TeamCrest';

interface SeasonContinuationStripProps {
  liveLeaders: LeagueLeaderItem[];
  loading?: boolean;
  onOpenLeagueTable: (leagueId: string) => void;
  onOpenTransfers: () => void;
}

export const SeasonContinuationStrip: React.FC<SeasonContinuationStripProps> = ({
  liveLeaders,
  loading = false,
  onOpenLeagueTable,
  onOpenTransfers,
}) => {
  return (
    <section
      aria-label="2026/27 League Continuation Tracker"
      className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 space-y-3"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-400 shrink-0" aria-hidden="true" />
          <div>
            <h2 className="font-display text-sm sm:text-base font-bold text-white leading-tight">
              2026/27 Season Continuation · Live League Leaders
            </h2>
            <p className="text-[11px] text-slate-400">
              Automatically retrieved table leaders, authentic club crests, and current points across major leagues
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenTransfers}
          className="inline-flex items-center gap-1 self-start sm:self-auto text-xs font-semibold text-amber-300 hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Transfer Wire</span>
          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
      </div>

      {loading && liveLeaders.length === 0 ? (
        <div className="flex items-center gap-2 py-4 text-xs text-slate-400">
          <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
          <span>Syncing live 2026/27 league leaders...</span>
        </div>
      ) : liveLeaders.length === 0 ? (
        <div className="rounded-lg border border-[#1D2834] bg-[#0B1117] px-3 py-3 text-xs text-slate-400">
          Live league leader summary is currently unavailable. Refresh or open Tables to inspect competitions.
        </div>
      ) : (
        <div className="flex items-stretch gap-2.5 overflow-x-auto pb-1">
          {liveLeaders.map((item) => (
            <button
              key={item.leagueId}
              type="button"
              onClick={() => onOpenLeagueTable(item.leagueId)}
              className="min-w-[186px] rounded-lg border border-[#1D2834] bg-[#0B1117] px-3 py-2.5 text-left hover:border-emerald-500/55 transition-colors shrink-0 group"
            >
              <div className="flex items-center justify-between gap-2 text-[10px] font-semibold">
                <span className="text-slate-400 truncate group-hover:text-emerald-300 transition-colors">
                  {item.leagueLabel}
                </span>
                <span className="font-mono text-amber-400 shrink-0">{item.roundLabel}</span>
              </div>

              <div className="mt-2 flex items-center gap-2">
                <TeamCrest
                  teamId={item.leaderId}
                  shortName={item.leaderShort}
                  color={item.leaderColor}
                  logoUrl={item.leaderLogo}
                  size="sm"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-white truncate">
                    {item.leaderName}
                  </div>
                  <div className="flex items-center justify-between gap-1 text-[10px]">
                    <span className="font-mono font-semibold text-emerald-400">{item.ptsLabel}</span>
                    <span className="text-slate-500 truncate">{item.resumeDateLabel}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </section>
  );
};
