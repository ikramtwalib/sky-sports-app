import React from 'react';
import { Bell, BellRing, Clock, History, Loader2, MapPin, Shield, Users, X } from 'lucide-react';
import type { FootballMatch } from '../types/football';
import { TeamCrest } from './TeamCrest';

interface MatchDetailModalProps {
  match: FootballMatch | null;
  loading?: boolean;
  isAlertSet?: boolean;
  onToggleAlert?: (match: FootballMatch) => void;
  onClose: () => void;
  onOpenTeamProfile: (teamId: string) => void;
}

export const MatchDetailModal: React.FC<MatchDetailModalProps> = ({
  match,
  loading = false,
  isAlertSet = false,
  onToggleAlert,
  onClose,
  onOpenTeamProfile,
}) => {
  if (!match) return null;

  const candidateRows: {
    label: string;
    homeVal: number | null;
    awayVal: number | null;
    format: (v: number) => string | number;
  }[] = [
    {
      label: 'Possession',
      homeVal: match.stats.possessionHome,
      awayVal: match.stats.possessionAway,
      format: (v) => `${v}%`,
    },
    {
      label: 'Total Shots',
      homeVal: match.stats.shotsHome,
      awayVal: match.stats.shotsAway,
      format: (v) => v,
    },
    {
      label: 'Shots on Target',
      homeVal: match.stats.shotsOnTargetHome,
      awayVal: match.stats.shotsOnTargetAway,
      format: (v) => v,
    },
    {
      label: 'Corners',
      homeVal: match.stats.cornersHome,
      awayVal: match.stats.cornersAway,
      format: (v) => v,
    },
    {
      label: 'Expected Goals (xG)',
      homeVal: match.stats.xgHome,
      awayVal: match.stats.xgAway,
      format: (v) => v.toFixed(2),
    },
  ];

  const statRows = candidateRows
    .filter(
      (r): r is { label: string; homeVal: number; awayVal: number; format: (v: number) => string | number } =>
        typeof r.homeVal === 'number' && typeof r.awayVal === 'number'
    )
    .map((r) => {
      const total = r.homeVal + r.awayVal;
      return {
        label: r.label,
        home: r.format(r.homeVal),
        away: r.format(r.awayVal),
        pctHome: total > 0 ? Math.round((r.homeVal / total) * 100) : 50,
      };
    });

  const goalEvents = match.events.filter((ev) => ev.type === 'goal');

  const eventLabel = (type: FootballMatch['events'][number]['type']) => {
    switch (type) {
      case 'goal':
        return 'Goal';
      case 'yellow':
        return 'Yellow Card';
      case 'red':
        return 'Red Card';
      case 'sub':
        return 'Substitution';
      default:
        return 'Assist';
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Match Center: ${match.homeTeam} vs ${match.awayTeam}`}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-5 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-[#24313F] bg-[#121A22] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-[#24313F] bg-[#0F1720]/95 backdrop-blur-sm px-5 py-3.5">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-emerald-400 truncate">
              {match.league} · {match.round}
            </p>
            <p className="text-[11px] text-slate-400 truncate flex items-center gap-1.5">
              <span>Live Football API · Match Center</span>
              {loading && (
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" />
                  Syncing match stats...
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {onToggleAlert && (
              <button
                type="button"
                onClick={() => onToggleAlert(match)}
                aria-pressed={isAlertSet}
                className={`inline-flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap ${
                  isAlertSet
                    ? 'bg-amber-500/15 border-amber-400/60 text-amber-300'
                    : 'bg-[#18222C] border-[#24313F] text-slate-200 hover:border-amber-400/60 hover:text-amber-300'
                }`}
              >
                {isAlertSet ? (
                  <BellRing className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <Bell className="w-3.5 h-3.5" aria-hidden="true" />
                )}
                <span>{isAlertSet ? 'Alert Active' : 'Match Alert'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Match Center"
              className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border border-[#24313F] bg-[#18222C] text-slate-300 hover:text-white hover:border-slate-500 transition-colors shrink-0"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Scoreboard Hero */}
        <div className="p-5 sm:p-6 border-b border-[#1D2834] bg-[#0E151C]">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-5">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenTeamProfile(match.homeTeamId);
              }}
              className="flex items-center gap-3 group text-left"
            >
              <TeamCrest
                teamId={match.homeTeamId}
                shortName={match.homeShort}
                color={match.homeColor}
                logoUrl={match.homeLogo}
                size="lg"
              />
              <div>
                <div className="font-display text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">
                  {match.homeTeam}
                </div>
                <div className="text-xs text-slate-400">Home · View Club Profile</div>
              </div>
            </button>

            <div className="text-center shrink-0">
              <div className="font-mono tabular-nums text-3xl sm:text-4xl font-bold text-white">
                {typeof match.homeScore === 'number' && typeof match.awayScore === 'number'
                  ? `${match.homeScore} — ${match.awayScore}`
                  : 'vs'}
              </div>
              <div
                className={`mt-1 inline-flex items-center justify-center gap-1.5 font-mono tabular-nums text-xs font-semibold ${
                  match.status === 'live'
                    ? 'text-rose-400'
                    : match.status === 'result'
                    ? 'text-amber-400'
                    : 'text-slate-400'
                }`}
              >
                {match.status === 'live' && (
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-500/15 border border-rose-500/50 text-[10px] font-bold text-rose-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
                    LIVE
                  </span>
                )}
                <span>{match.timeLabel}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenTeamProfile(match.awayTeamId);
              }}
              className="flex items-center gap-3 group text-left sm:text-right sm:flex-row-reverse"
            >
              <TeamCrest
                teamId={match.awayTeamId}
                shortName={match.awayShort}
                color={match.awayColor}
                logoUrl={match.awayLogo}
                size="lg"
              />
              <div>
                <div className="font-display text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">
                  {match.awayTeam}
                </div>
                <div className="text-xs text-slate-400">Away · View Club Profile</div>
              </div>
            </button>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
              {match.venue}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
              {match.country}
            </span>
          </div>
        </div>

        {/* Body Sections */}
        <div className="p-5 sm:p-6 space-y-6">
          {/* Event Timeline & Goal Scorers */}
          <section aria-label="Match event timeline">
            <div className="flex items-center justify-between gap-2 mb-3">
              <h3 className="font-display text-sm font-bold text-white">
                Goal Scorers &amp; Key Events
              </h3>
              {goalEvents.length > 0 && (
                <span className="font-mono text-xs text-emerald-400">
                  {goalEvents.length} {goalEvents.length === 1 ? 'Goal' : 'Goals'}
                </span>
              )}
            </div>
            {match.events.length > 0 ? (
              <div className="divide-y divide-[#1D2834] rounded-xl border border-[#24313F] bg-[#0F1720]">
                {match.events.map((ev, index) => (
                  <div
                    key={`${ev.minute}-${ev.player}-${index}`}
                    className={`flex items-center justify-between gap-4 px-4 py-2.5 text-xs ${
                      ev.type === 'goal' ? 'bg-emerald-500/[0.04]' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="font-mono tabular-nums font-bold text-amber-400 w-10 shrink-0">
                        {ev.minute}
                      </span>
                      <span
                        className={`font-semibold shrink-0 ${
                          ev.type === 'goal'
                            ? 'text-emerald-400'
                            : ev.type === 'yellow'
                            ? 'text-amber-300'
                            : ev.type === 'sub'
                            ? 'text-sky-300'
                            : 'text-rose-400'
                        }`}
                      >
                        {eventLabel(ev.type)}
                      </span>
                      <span className="font-semibold text-white truncate">{ev.player}</span>
                      {ev.detail && ev.detail !== 'Goal' && (
                        <span className="hidden sm:inline text-slate-400 truncate">
                          ({ev.detail})
                        </span>
                      )}
                    </div>
                    <span
                      className={`font-mono text-[11px] font-semibold shrink-0 ${
                        ev.team === 'home' ? 'text-emerald-300' : 'text-amber-300'
                      }`}
                    >
                      {ev.team === 'home' ? match.homeShort : match.awayShort}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                {match.status === 'upcoming'
                  ? 'Kickoff awaits — live match events and goalscorers will appear here once play starts.'
                  : 'No goalscorer or card timeline events were reported for this fixture.'}
              </p>
            )}
          </section>

          {/* Match Statistics Comparison */}
          <section aria-label="Match statistics">
            <h3 className="font-display text-sm font-bold text-white mb-3">
              Match Statistics
            </h3>
            {match.status === 'upcoming' ? (
              <p className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                Pre-match fixture scheduled. Live possession, shots, corners, and expected goals (xG) will populate during the match.
              </p>
            ) : statRows.length === 0 ? (
              <p className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                Official match statistics (possession, shots, corners) are unavailable from the live API feed for this competition or fixture.
              </p>
            ) : (
              <div className="space-y-3 rounded-xl border border-[#24313F] bg-[#0F1720] p-4">
                {statRows.map((row) => (
                  <div key={row.label} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono tabular-nums font-semibold text-emerald-300">
                        {row.home}
                      </span>
                      <span className="text-slate-300 font-medium">{row.label}</span>
                      <span className="font-mono tabular-nums font-semibold text-amber-300">
                        {row.away}
                      </span>
                    </div>
                    <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-[#1D2834]">
                      <div
                        className="bg-emerald-500 transition-all"
                        style={{ width: `${row.pctHome}%` }}
                      />
                      <div
                        className="bg-amber-400 transition-all"
                        style={{ width: `${100 - row.pctHome}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Starting Lineups */}
          <section aria-label="Starting lineups">
            <div className="flex items-center gap-2 mb-3">
              <Users className="w-4 h-4 text-emerald-400" aria-hidden="true" />
              <h3 className="font-display text-sm font-bold text-white">
                Projected / Starting XI
              </h3>
            </div>
            {match.homeLineup.length > 0 || match.awayLineup.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-xl border border-[#24313F] bg-[#0F1720] p-4">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300 mb-2.5">
                    <Shield className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{match.homeTeam}</span>
                  </div>
                  <ol className="space-y-1.5 text-xs text-slate-300">
                    {match.homeLineup.map((player, i) => (
                      <li key={player} className="flex items-center gap-2">
                        <span className="font-mono tabular-nums text-slate-500 w-5">{i + 1}.</span>
                        <span>{player}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                <div className="rounded-xl border border-[#24313F] bg-[#0F1720] p-4">
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-300 mb-2.5">
                    <Shield className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{match.awayTeam}</span>
                  </div>
                  <ol className="space-y-1.5 text-xs text-slate-300">
                    {match.awayLineup.map((player, i) => (
                      <li key={player} className="flex items-center gap-2">
                        <span className="font-mono tabular-nums text-slate-500 w-5">{i + 1}.</span>
                        <span>{player}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            ) : (
              <p className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                Official matchday lineups are released 60 minutes before kickoff.
              </p>
            )}
          </section>

          {/* Head-to-Head History (Last 5 Meetings) */}
          <section aria-label="Head-to-Head statistics">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" aria-hidden="true" />
                <h3 className="font-display text-sm font-bold text-white">
                  Head-to-Head (Last 5 Matches)
                </h3>
              </div>
              {match.headToHead?.summaryText && (
                <span className="text-xs font-medium text-emerald-400">
                  {match.headToHead.summaryText}
                </span>
              )}
            </div>

            {loading && !match.headToHead ? (
              <div className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 flex items-center gap-2 text-xs text-slate-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" aria-hidden="true" />
                <span>Retrieving historical Head-to-Head outcomes...</span>
              </div>
            ) : match.headToHead && match.headToHead.matches.length > 0 ? (
              <div className="divide-y divide-[#1D2834] rounded-xl border border-[#24313F] bg-[#0F1720]">
                {match.headToHead.matches.map((h2h) => (
                  <div
                    key={h2h.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-4 py-3 text-xs"
                  >
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 shrink-0">
                      <span className="font-mono tabular-nums">{h2h.dateLabel}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="truncate max-w-[160px]">{h2h.competition}</span>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 min-w-0">
                      <span
                        className={`truncate ${
                          h2h.winnerSide === 'home' ? 'font-bold text-emerald-300' : 'text-slate-200'
                        }`}
                      >
                        {h2h.homeTeam}
                      </span>
                      <span className="font-mono tabular-nums font-bold px-2 py-0.5 rounded bg-[#18222C] border border-[#24313F] text-white shrink-0">
                        {h2h.homeScore !== null && h2h.awayScore !== null
                          ? `${h2h.homeScore} - ${h2h.awayScore}`
                          : '—'}
                      </span>
                      <span
                        className={`truncate ${
                          h2h.winnerSide === 'away' ? 'font-bold text-emerald-300' : 'text-slate-200'
                        }`}
                      >
                        {h2h.awayTeam}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                Historical Head-to-Head records between these clubs are currently unavailable from the live football API feed.
              </p>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
