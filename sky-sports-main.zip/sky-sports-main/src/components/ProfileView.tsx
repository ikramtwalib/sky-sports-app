import React, { useState } from 'react';
import { Bell, CheckCircle2, LogOut, Shield, UserCheck } from 'lucide-react';
import type { LeagueInfo, TeamProfile, UserProfileData } from '../types/football';
import { sanitizeProfilePayload, validateUserProfileInput } from '../utils/footballUtils';

interface ProfileViewProps {
  profile: UserProfileData | null;
  leagues: LeagueInfo[];
  teams: TeamProfile[];
  followedTeams: string[];
  onSaveProfile: (nextProfile: UserProfileData) => void;
  onSignOutProfile: () => void;
  onOpenTeamProfile: (teamId: string) => void;
  onToggleFollowTeam: (teamId: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  leagues,
  teams,
  followedTeams,
  onSaveProfile,
  onSignOutProfile,
  onOpenTeamProfile,
  onToggleFollowTeam,
}) => {
  const [displayName, setDisplayName] = useState(profile?.displayName ?? '');
  const [username, setUsername] = useState(profile?.username ?? '');
  const [email, setEmail] = useState(profile?.email ?? '');
  const [favoriteLeague, setFavoriteLeague] = useState(
    profile?.favoriteLeague ?? 'English Premier League'
  );
  const [favoriteTeam, setFavoriteTeam] = useState(profile?.favoriteTeam ?? 'Arsenal');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [alertsEnabled, setAlertsEnabled] = useState(profile?.alertsEnabled ?? true);
  const [errors, setErrors] = useState<
    Partial<Record<'displayName' | 'username' | 'email' | 'favoriteLeague' | 'favoriteTeam' | 'bio', string>>
  >({});
  const [savedMessage, setSavedMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedMessage(null);

    const validation = validateUserProfileInput({
      displayName,
      username,
      favoriteLeague,
      favoriteTeam,
      bio,
    });

    const nextErrors: typeof errors = { ...validation.errors };
    const cleanEmail = email.trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      nextErrors.email = 'Please enter a valid email address.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setErrors({});
    const clean = sanitizeProfilePayload({
      email: cleanEmail,
      displayName,
      username,
      favoriteLeague,
      favoriteTeam,
      bio,
      followedTeams,
      alertsEnabled,
    });

    onSaveProfile({
      uid: profile?.uid || `fan-${clean.username}`,
      ...clean,
    });
    setSavedMessage(
      profile
        ? 'Your Sky Sports supporter profile has been updated locally.'
        : 'Welcome to Sky Sports! Your supporter profile is now active.'
    );
  };

  const followedClubObjects = teams.filter((t) => followedTeams.includes(t.id));

  return (
    <section aria-label="User registration and supporter profile" className="space-y-6 max-w-4xl">
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1D2834] pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <UserCheck className="w-4 h-4" aria-hidden="true" />
              <span>Supporter Profile · Local Browser Storage</span>
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-white tracking-tight">
              {profile ? `${profile.displayName}` : 'Supporter Registration & Profile'}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-slate-400">
              {profile
                ? `@${profile.username} · Favorite Club: ${profile.favoriteTeam}`
                : 'Create your Sky Sports football supporter profile to personalize favorite competitions and followed clubs.'}
            </p>
          </div>

          {profile && (
            <button
              type="button"
              onClick={() => {
                onSignOutProfile();
                setDisplayName('');
                setUsername('');
                setEmail('');
                setBio('');
                setSavedMessage(null);
              }}
              className="inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-medium text-slate-200 hover:border-rose-400/60 hover:text-white transition-colors shrink-0"
            >
              <LogOut className="w-4 h-4" aria-hidden="true" />
              <span>Reset Profile</span>
            </button>
          )}
        </div>

        {savedMessage && (
          <div
            role="status"
            className="mt-4 flex items-center gap-2.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs sm:text-sm text-emerald-300"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{savedMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="profile-display-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                Full Name / Display Name
              </label>
              <input
                id="profile-display-name"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. Alex Morgan"
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {errors.displayName && (
                <p className="mt-1 text-xs text-rose-400">{errors.displayName}</p>
              )}
            </div>

            <div>
              <label htmlFor="profile-username" className="block text-xs font-medium text-slate-300 mb-1.5">
                Supporter Handle
              </label>
              <input
                id="profile-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase())}
                placeholder="e.g. alex_gunner"
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3.5 py-2 text-sm font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {errors.username && (
                <p className="mt-1 text-xs text-rose-400">{errors.username}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="profile-email" className="block text-xs font-medium text-slate-300 mb-1.5">
                Email Address
              </label>
              <input
                id="profile-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="supporter@example.com"
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {errors.email && <p className="mt-1 text-xs text-rose-400">{errors.email}</p>}
            </div>

            <div>
              <label htmlFor="profile-league" className="block text-xs font-medium text-slate-300 mb-1.5">
                Favorite League
              </label>
              <select
                id="profile-league"
                value={favoriteLeague}
                onChange={(e) => setFavoriteLeague(e.target.value)}
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                {leagues.map((l) => (
                  <option key={l.id} value={l.name}>
                    {l.name}
                  </option>
                ))}
              </select>
              {errors.favoriteLeague && (
                <p className="mt-1 text-xs text-rose-400">{errors.favoriteLeague}</p>
              )}
            </div>

            <div>
              <label htmlFor="profile-team" className="block text-xs font-medium text-slate-300 mb-1.5">
                Favorite Club
              </label>
              <select
                id="profile-team"
                value={favoriteTeam}
                onChange={(e) => setFavoriteTeam(e.target.value)}
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                {favoriteTeam && !teams.some((t) => t.name === favoriteTeam) && (
                  <option value={favoriteTeam}>{favoriteTeam}</option>
                )}
                {teams.map((t) => (
                  <option key={t.id} value={t.name}>
                    {t.name}
                  </option>
                ))}
              </select>
              {errors.favoriteTeam && (
                <p className="mt-1 text-xs text-rose-400">{errors.favoriteTeam}</p>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="profile-bio" className="block text-xs font-medium text-slate-300 mb-1.5">
              Supporter Bio
            </label>
            <textarea
              id="profile-bio"
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Share the leagues you follow, favorite matchday memories, or tactical takes..."
              className="w-full rounded-lg border border-[#24313F] bg-[#0B1117] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
            {errors.bio && <p className="mt-1 text-xs text-rose-400">{errors.bio}</p>}
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <label className="inline-flex items-center gap-2.5 text-xs sm:text-sm text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={alertsEnabled}
                onChange={(e) => setAlertsEnabled(e.target.checked)}
                className="h-4 w-4 rounded border-[#24313F] bg-[#0B1117] accent-emerald-500"
              />
              <Bell className="w-4 h-4 text-amber-400" aria-hidden="true" />
              <span>Enable kickoff &amp; full-time score updates</span>
            </label>

            <button
              type="submit"
              className="inline-flex items-center justify-center min-h-[44px] px-6 py-2.5 rounded-lg bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
            >
              {profile ? 'Save Profile Changes' : 'Register Supporter Profile'}
            </button>
          </div>
        </form>
      </div>

      {/* Followed Clubs Panel */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6">
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-amber-400" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-white">
              Followed Clubs ({followedClubObjects.length})
            </h2>
          </div>
        </div>

        {followedClubObjects.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {followedClubObjects.map((club) => (
              <div
                key={club.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-[#1D2834] bg-[#0F1720] px-4 py-3"
              >
                <button
                  type="button"
                  onClick={() => onOpenTeamProfile(club.id)}
                  className="text-left min-w-0 hover:text-emerald-300 transition-colors"
                >
                  <div className="text-sm font-semibold text-white truncate">{club.name}</div>
                  <div className="text-xs text-slate-400 truncate">{club.leagueName}</div>
                </button>
                <button
                  type="button"
                  onClick={() => onToggleFollowTeam(club.id)}
                  className="min-h-[34px] px-3 py-1 rounded-lg border border-[#24313F] text-xs text-slate-300 hover:border-rose-400/60 hover:text-rose-300 shrink-0"
                >
                  Unfollow
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs sm:text-sm text-slate-400">
            You are not following any clubs yet. Visit the Teams tab or click any club name in a match card to follow teams.
          </p>
        )}
      </div>
    </section>
  );
};
