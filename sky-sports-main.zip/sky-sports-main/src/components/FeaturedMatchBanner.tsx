import React, { useState } from 'react';
import { Bell, BellRing, ChevronRight } from 'lucide-react';
import type { FootballMatch } from '../types/football';
import { TeamCrest } from './TeamCrest';

interface FeaturedMatchBannerProps {
  match: FootballMatch;
  isAlertSet?: boolean;
  onToggleAlert?: (match: FootballMatch) => void;
  onOpenMatchDetail: (match: FootballMatch) => void;
  onOpenTeamProfile: (teamId: string) => void;
}

export const FeaturedMatchBanner: React.FC<FeaturedMatchBannerProps> = ({
  match,
  isAlertSet = false,
  onToggleAlert,
  onOpenMatchDetail,
  onOpenTeamProfile,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      aria-label="Featured football match spotlight"
      className="relative overflow-hidden rounded-xl border border-[#24313F] bg-[#121A22]"
    >
      <div className="relative min-h-[270px] sm:min-h-[288px] w-full overflow-hidden">
        {!imgError && match.heroImage ? (
          <img
            src={match.heroImage}
            alt={`${match.homeTeam} vs ${match.awayTeam} stadium spotlight`}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="absolute inset-0 h-full w-full object-cover object-center"
          />
        ) : (
          <div className="absolute inset-0 h-full w-full bg-gradient-to-br from-[#18222C] via-[#121A22] to-[#0B1117]" />
        )}

        {/* Contrast Scrim */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-[#0B1117] via-[#0B1117]/80 to-[#0B1117]/30"
        />

        <div className="relative z-10 flex min-h-[270px] sm:min-h-[288px] flex-col justify-between gap-6 p-5 sm:p-6">
          {/* Top Metadata */}
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-slate-200">
            {match.status === 'live' && (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500/20 border border-rose-500/60 text-[10px] font-bold tracking-wider text-rose-300">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
                LIVE NOW
              </span>
            )}
            <span className="text-amber-400 font-semibold">{match.timeLabel}</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span>{match.league}</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="text-slate-300">{match.round}</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="text-emerald-300 font-semibold">Live Football Feed</span>
          </div>

          {/* Center / Bottom Matchup */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onOpenTeamProfile(match.homeTeamId)}
                  className="inline-flex items-center gap-2 hover:text-emerald-300 transition-colors"
                >
                  <TeamCrest
                    teamId={match.homeTeamId}
                    shortName={match.homeShort}
                    color={match.homeColor}
                    logoUrl={match.homeLogo}
                    size="md"
                  />
                  <span className="font-display text-xl sm:text-3xl font-bold text-white tracking-tight">
                    {match.homeTeam}
                  </span>
                </button>

                <span className="font-mono tabular-nums text-2xl sm:text-3xl font-bold text-amber-400 px-1">
                  {typeof match.homeScore === 'number' && typeof match.awayScore === 'number'
                    ? `${match.homeScore} — ${match.awayScore}`
                    : 'vs'}
                </span>

                <button
                  type="button"
                  onClick={() => onOpenTeamProfile(match.awayTeamId)}
                  className="inline-flex items-center gap-2 hover:text-emerald-300 transition-colors"
                >
                  <TeamCrest
                    teamId={match.awayTeamId}
                    shortName={match.awayShort}
                    color={match.awayColor}
                    logoUrl={match.awayLogo}
                    size="md"
                  />
                  <span className="font-display text-xl sm:text-3xl font-bold text-white tracking-tight">
                    {match.awayTeam}
                  </span>
                </button>
              </div>
              <p className="mt-2 text-xs sm:text-sm text-slate-300">
                {match.venue}
              </p>
              {match.events.some((e) => e.type === 'goal') && (
                <p className="mt-1.5 text-xs text-emerald-300 font-medium">
                  Goals:{' '}
                  {match.events
                    .filter((e) => e.type === 'goal')
                    .slice(0, 4)
                    .map((e) => `${e.minute} ${e.player} (${e.team === 'home' ? match.homeShort : match.awayShort})`)
                    .join(' · ')}
                </p>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {onToggleAlert && (
                <button
                  type="button"
                  onClick={() => onToggleAlert(match)}
                  aria-pressed={isAlertSet}
                  className={`inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2.5 rounded-lg border text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    isAlertSet
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 hover:bg-amber-500/30'
                      : 'bg-[#121A22]/90 border-[#24313F] text-slate-100 hover:border-amber-400/60 hover:text-amber-300'
                  }`}
                >
                  {isAlertSet ? (
                    <BellRing className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <Bell className="w-4 h-4" aria-hidden="true" />
                  )}
                  <span>{isAlertSet ? 'Alert Active' : 'Match Alert'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => onOpenMatchDetail(match)}
                className="inline-flex items-center justify-center gap-2 min-h-[44px] px-5 py-2.5 rounded-lg bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
              >
                <span>Open Match Center</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
