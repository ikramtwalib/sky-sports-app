import React from 'react';
import {
  ArrowLeftRight,
  Calendar,
  Globe2,
  Home,
  Newspaper,
  Shield,
  Table2,
  User,
  Users,
} from 'lucide-react';
import type { AppView } from '../types/football';

interface HeaderProps {
  activeView: AppView;
  onSelectView: (view: AppView) => void;
  userLabel: string;
  isSignedIn: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onSelectView,
  userLabel,
  isSignedIn,
}) => {
  const navItems: { id: AppView; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'matches', label: 'Fixtures' },
    { id: 'tables', label: 'Tables' },
    { id: 'africa', label: 'Africa' },
    { id: 'teams', label: 'Teams' },
    { id: 'players', label: 'Players' },
    { id: 'transfers', label: 'Transfers' },
    { id: 'news', label: 'News' },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-[#24313F] bg-[#0B1117]/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-4 py-3 sm:px-6">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={() => onSelectView('home')}
          className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-sm"
        >
          SKY <span className="text-emerald-400">SPORTS</span>
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-4 lg:gap-5 overflow-x-auto">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectView(item.id)}
                className={`relative py-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-sm ${
                  isActive ? 'text-white' : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[13px] h-0.5 bg-emerald-500"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single primary profile & registration CTA */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => onSelectView('profile')}
            aria-label={isSignedIn ? `Open profile for ${userLabel}` : 'Sign in or register Sky Sports profile'}
            className={`inline-flex items-center gap-2 min-h-[40px] px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
              activeView === 'profile'
                ? 'bg-emerald-600 border-emerald-500 text-white'
                : isSignedIn
                ? 'bg-[#18222C] border-amber-400/50 text-amber-300 hover:border-amber-400'
                : 'bg-[#18222C] border-[#24313F] text-white hover:border-emerald-500/60 hover:bg-[#1E2A36]'
            }`}
          >
            <User className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span className="truncate max-w-[130px]">{userLabel}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

interface MobileBottomNavProps {
  activeView: AppView;
  onSelectView: (view: AppView) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeView,
  onSelectView,
}) => {
  const items: { id: AppView; label: string; Icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', Icon: Home },
    { id: 'matches', label: 'Fixtures', Icon: Calendar },
    { id: 'tables', label: 'Tables', Icon: Table2 },
    { id: 'africa', label: 'Africa', Icon: Globe2 },
    { id: 'teams', label: 'Teams', Icon: Shield },
    { id: 'players', label: 'Players', Icon: Users },
    { id: 'transfers', label: 'Transfers', Icon: ArrowLeftRight },
    { id: 'news', label: 'News', Icon: Newspaper },
  ];

  return (
    <nav
      aria-label="Mobile bottom navigation"
      className="fixed bottom-0 inset-x-0 z-30 md:hidden border-t border-[#24313F] bg-[#0B1117]/95 backdrop-blur-md"
    >
      <div className="flex items-center overflow-x-auto h-14 px-1">
        {items.map(({ id, label, Icon }) => {
          const active = activeView === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectView(id)}
              className={`flex-1 min-w-[62px] flex flex-col items-center justify-center gap-0.5 min-h-[44px] transition-colors shrink-0 ${
                active ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" aria-hidden="true" />
              <span className="text-[10px] font-medium tracking-tight">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
