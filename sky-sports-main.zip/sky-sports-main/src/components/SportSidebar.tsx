import React, { useMemo, useState } from 'react';
import { Globe2, Search, Table2, X } from 'lucide-react';
import type { FootballMatch, LeagueInfo, RegionId } from '../types/football';

interface SportSidebarProps {
  regions: { id: RegionId; label: string }[];
  leagues: LeagueInfo[];
  matches: FootballMatch[];
  selectedRegion: RegionId;
  selectedLeagueId: string | null;
  onSelectRegion: (region: RegionId) => void;
  onSelectLeague: (leagueId: string | null) => void;
  onOpenLeagueTable: (leagueId: string) => void;
}

export const SportSidebar: React.FC<SportSidebarProps> = ({
  regions,
  leagues,
  matches,
  selectedRegion,
  selectedLeagueId,
  onSelectRegion,
  onSelectLeague,
  onOpenLeagueTable,
}) => {
  const [leagueQuery, setLeagueQuery] = useState('');

  const matchCountsByLeague = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const m of matches) {
      counts[m.leagueId] = (counts[m.leagueId] || 0) + 1;
    }
    return counts;
  }, [matches]);

  const filteredLeagues = useMemo(() => {
    const q = leagueQuery.trim().toLowerCase();
    return leagues.filter((l) => {
      if (selectedRegion !== 'all' && l.region !== selectedRegion) return false;
      if (!q) return true;
      return `${l.name} ${l.shortName} ${l.country} ${l.region}`
        .toLowerCase()
        .includes(q);
    });
  }, [leagues, selectedRegion, leagueQuery]);

  return (
    <aside aria-label="Competitions and regions" className="w-full lg:w-[272px] shrink-0">
      {/* Mobile / Tablet Compact Region Scroller */}
      <div className="lg:hidden mb-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {regions.map((region) => {
            const active = selectedRegion === region.id;
            return (
              <button
                key={region.id}
                type="button"
                onClick={() => onSelectRegion(region.id)}
                className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#121A22] border-[#24313F] text-slate-300 hover:border-slate-500'
                }`}
              >
                {region.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Desktop Left Directory Panel */}
      <div className="hidden lg:flex flex-col rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden sticky top-[76px] max-h-[calc(100vh-96px)]">
        <div className="p-4 border-b border-[#1D2834]">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-emerald-400" aria-hidden="true" />
              <h2 className="font-display text-sm font-bold text-white tracking-tight">
                World Leagues
              </h2>
            </div>
            <span className="font-mono tabular-nums text-xs text-slate-400">
              {leagues.length} leagues
            </span>
          </div>

          {/* Region Grid */}
          <div className="mt-3 grid grid-cols-2 gap-1.5">
            {regions.map((region) => {
              const active = selectedRegion === region.id;
              return (
                <button
                  key={region.id}
                  type="button"
                  onClick={() => onSelectRegion(region.id)}
                  className={`min-h-[34px] px-2.5 py-1.5 rounded-lg text-xs font-medium border text-left truncate transition-colors ${
                    active
                      ? 'bg-emerald-600/20 border-emerald-500/70 text-emerald-300'
                      : 'bg-[#0F1720] border-[#1D2834] text-slate-400 hover:text-slate-100 hover:border-[#2C3B4B]'
                  }`}
                >
                  {region.label}
                </button>
              );
            })}
          </div>

          {/* Quick Filter Within Sidebar */}
          <div className="relative mt-3">
            <Search
              className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={leagueQuery}
              onChange={(e) => setLeagueQuery(e.target.value)}
              placeholder="Filter competitions..."
              aria-label="Filter world leagues"
              className="w-full rounded-lg border border-[#24313F] bg-[#0B1117] pl-8 pr-8 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
            {leagueQuery && (
              <button
                type="button"
                onClick={() => setLeagueQuery('')}
                aria-label="Clear competition filter"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
              >
                <X className="w-3 h-3" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Leagues List */}
        <div className="overflow-y-auto p-2 space-y-1">
          <button
            type="button"
            onClick={() => onSelectLeague(null)}
            className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
              selectedLeagueId === null
                ? 'bg-[#18222C] text-emerald-300 border border-emerald-500/40'
                : 'text-slate-300 hover:bg-[#18222C]/70 border border-transparent'
            }`}
          >
            <span>All Competitions</span>
            <span className="font-mono tabular-nums text-[11px] text-slate-400">
              {matches.length}
            </span>
          </button>

          {filteredLeagues.map((league) => {
            const active = selectedLeagueId === league.id;
            const count = matchCountsByLeague[league.id] || 0;
            return (
              <div
                key={league.id}
                className={`flex items-center justify-between gap-1.5 rounded-lg border transition-colors ${
                  active
                    ? 'bg-[#18222C] border-amber-400/50'
                    : 'border-transparent hover:bg-[#18222C]/60'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectLeague(active ? null : league.id)}
                  className="flex-1 min-w-0 text-left px-3 py-2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-emerald-500 rounded-l-lg"
                >
                  <div
                    className={`text-xs font-medium truncate ${
                      active ? 'text-amber-300' : 'text-slate-200'
                    }`}
                  >
                    {league.name}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">
                    {league.country} · {league.tier}
                  </div>
                </button>

                <div className="flex items-center gap-1 pr-2 shrink-0">
                  {count > 0 && (
                    <span className="font-mono tabular-nums text-[11px] text-slate-400 px-1">
                      {count}
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => onOpenLeagueTable(league.id)}
                    aria-label={`View ${league.name} table`}
                    title={`View ${league.name} table`}
                    className="p-1.5 rounded text-slate-400 hover:text-emerald-400 hover:bg-[#0B1117] transition-colors"
                  >
                    <Table2 className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            );
          })}

          {filteredLeagues.length === 0 && (
            <p className="px-3 py-6 text-center text-xs text-slate-500">
              No competitions match &ldquo;{leagueQuery}&rdquo;.
            </p>
          )}
        </div>
      </div>
    </aside>
  );
};
