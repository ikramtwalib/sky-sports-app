import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Globe2,
  Loader2,
  Search,
  Shield,
  Table2,
  Trophy,
  X,
} from 'lucide-react';
import {
  AFRICAN_CONTINENTAL_COMPETITIONS,
  AFRICAN_COUNTRIES_CATALOG,
  type AfricanCountryHub,
} from '../data/africanCountries';
import { fetchLeagueMatches, fetchLeagueStandings } from '../services/footballApi';
import type { FootballMatch, StandingRow } from '../types/football';
import { MatchCard } from './MatchCard';
import { TeamCrest } from './TeamCrest';

interface AfricanFootballViewProps {
  onOpenMatchDetail: (match: FootballMatch) => void;
  onOpenTeamProfile: (teamId: string) => void;
  onOpenLeagueTable: (leagueId: string) => void;
  isAlertSet?: (matchId: string) => boolean;
  onToggleAlert?: (match: FootballMatch) => void;
}

const REGION_TAGS = [
  'all',
  'East Africa',
  'Southern Africa',
  'North Africa',
  'West Africa',
  'Central Africa',
] as const;

export const AfricanFootballView: React.FC<AfricanFootballViewProps> = ({
  onOpenMatchDetail,
  onOpenTeamProfile,
  onOpenLeagueTable,
  isAlertSet,
  onToggleAlert,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<AfricanCountryHub | null>(null);
  const [regionFilter, setRegionFilter] = useState<(typeof REGION_TAGS)[number]>('all');
  const [query, setQuery] = useState('');

  // Country sub-page live data state
  const [countryLoading, setCountryLoading] = useState(false);
  const [countryMatches, setCountryMatches] = useState<FootballMatch[]>([]);
  const [countryStandings, setCountryStandings] = useState<StandingRow[]>([]);
  const [countryMatchesNote, setCountryMatchesNote] = useState<string | null>(null);
  const [countryStandingsNote, setCountryStandingsNote] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedCountry) return;
    let cancelled = false;
    setCountryLoading(true);
    setCountryMatches([]);
    setCountryStandings([]);
    setCountryMatchesNote(null);
    setCountryStandingsNote(null);

    Promise.allSettled([
      fetchLeagueMatches(selectedCountry.leagueId),
      fetchLeagueStandings(selectedCountry.leagueId),
    ])
      .then(([mRes, sRes]) => {
        if (cancelled) return;

        if (mRes.status === 'fulfilled') {
          if (mRes.value.available && mRes.value.matches.length > 0) {
            setCountryMatches(mRes.value.matches);
          } else {
            setCountryMatchesNote(
              mRes.value.reason ||
                `No recent or upcoming fixtures returned for ${selectedCountry.leagueName}.`
            );
          }
        } else {
          setCountryMatchesNote(`Unable to load live fixtures for ${selectedCountry.leagueName}.`);
        }

        if (sRes.status === 'fulfilled') {
          if (sRes.value.available && sRes.value.standings.length > 0) {
            setCountryStandings(sRes.value.standings);
          } else {
            setCountryStandingsNote(
              sRes.value.reason ||
                `Live league standings are currently unavailable for ${selectedCountry.leagueName}.`
            );
          }
        } else {
          setCountryStandingsNote(
            `Unable to retrieve live standings for ${selectedCountry.leagueName}.`
          );
        }
      })
      .finally(() => {
        if (!cancelled) setCountryLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedCountry]);

  const filteredCountries = useMemo(() => {
    const q = query.trim().toLowerCase();
    return AFRICAN_COUNTRIES_CATALOG.filter((c) => {
      if (regionFilter !== 'all' && c.regionTag !== regionFilter) return false;
      if (!q) return true;
      return `${c.name} ${c.leagueName} ${c.nationalCup} ${c.continentalClubs.join(' ')}`
        .toLowerCase()
        .includes(q);
    });
  }, [regionFilter, query]);

  if (selectedCountry) {
    return (
      <section aria-label={`${selectedCountry.name} Football Hub`} className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setSelectedCountry(null)}
            className="inline-flex items-center gap-2 min-h-[40px] px-3.5 py-2 rounded-lg border border-[#24313F] bg-[#121A22] text-xs font-medium text-slate-200 hover:text-white hover:border-slate-500 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            <span>Back to African Football Hub</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLeagueTable(selectedCountry.leagueId)}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-[#24313F] bg-[#121A22] text-xs font-medium text-emerald-300 hover:border-emerald-500/60 hover:text-white transition-colors"
          >
            <Table2 className="w-4 h-4" aria-hidden="true" />
            <span>Open Full League Table</span>
          </button>
        </div>

        {/* Country Football Header */}
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                <Globe2 className="w-4 h-4" aria-hidden="true" />
                <span>African Football · {selectedCountry.regionTag}</span>
              </div>
              <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {selectedCountry.name} Football
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">
                Domestic League: <span className="text-white font-semibold">{selectedCountry.leagueName}</span> · National Cup:{' '}
                <span className="text-emerald-300 font-medium">{selectedCountry.nationalCup}</span>
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => onOpenLeagueTable('caf-cl')}
                className="min-h-[38px] px-3 py-1.5 rounded-lg border border-[#24313F] bg-[#0F1720] text-xs font-semibold text-amber-300 hover:border-amber-400/60 transition-colors"
              >
                CAF Champions League Table
              </button>
              <button
                type="button"
                onClick={() => onOpenLeagueTable('caf-confed')}
                className="min-h-[38px] px-3 py-1.5 rounded-lg border border-[#24313F] bg-[#0F1720] text-xs font-semibold text-emerald-300 hover:border-emerald-500/60 transition-colors"
              >
                CAF Confederation Cup
              </button>
            </div>
          </div>

          <div className="border-t border-[#1D2834] pt-3 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">Notable Clubs:</span>
            {selectedCountry.continentalClubs.map((club) => (
              <span
                key={club}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-[#24313F] bg-[#0F1720] text-slate-200"
              >
                <Shield className="w-3 h-3 text-emerald-400" aria-hidden="true" />
                {club}
              </span>
            ))}
          </div>
        </div>

        {/* Live Fixtures & Results for Country Domestic League */}
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" aria-hidden="true" />
              <h2 className="font-display text-lg font-bold text-white">
                {selectedCountry.leagueName} — Fixtures &amp; Results (EAT)
              </h2>
            </div>
            {countryLoading && (
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                Syncing live API...
              </span>
            )}
          </div>

          {countryLoading ? (
            <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 flex items-center justify-center gap-2.5 text-xs sm:text-sm text-slate-300">
              <Loader2 className="w-5 h-5 animate-spin text-emerald-400" aria-hidden="true" />
              <span>Checking live football feeds for {selectedCountry.leagueName}...</span>
            </div>
          ) : countryMatches.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {countryMatches.map((match) => (
                <MatchCard
                  key={match.id}
                  match={match}
                  isAlertSet={isAlertSet ? isAlertSet(match.id) : false}
                  onToggleAlert={onToggleAlert}
                  onOpenMatchDetail={onOpenMatchDetail}
                  onOpenTeamProfile={onOpenTeamProfile}
                />
              ))}
            </div>
          ) : (
            <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-5 flex items-start gap-3 text-xs sm:text-sm text-slate-300">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-semibold text-white">
                  Live Domestic Fixtures Unavailable for {selectedCountry.name}
                </p>
                <p className="mt-1 text-slate-300">
                  {countryMatchesNote ||
                    `The connected football data feed does not currently publish live domestic matchdays for ${selectedCountry.leagueName}. Clubs from ${selectedCountry.name} competing in CAF Champions League & CAF Confederation Cup remain tracked in continental competitions.`}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Live Standings for Country Domestic League */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" aria-hidden="true" />
            <h2 className="font-display text-lg font-bold text-white">
              {selectedCountry.leagueName} — Standings
            </h2>
          </div>

          {countryLoading ? (
            <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 flex items-center justify-center gap-2.5 text-xs text-slate-300">
              <Loader2 className="w-5 h-5 animate-spin text-emerald-400" aria-hidden="true" />
              <span>Loading standings...</span>
            </div>
          ) : countryStandings.length > 0 ? (
            <div className="rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#24313F] bg-[#0F1720] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                      <th className="py-3 pl-4 pr-2 w-12">Pos</th>
                      <th className="py-3 px-2 min-w-[180px]">Club</th>
                      <th className="py-3 px-2 text-center font-mono">P</th>
                      <th className="py-3 px-2 text-center font-mono">W</th>
                      <th className="py-3 px-2 text-center font-mono">D</th>
                      <th className="py-3 px-2 text-center font-mono">L</th>
                      <th className="py-3 px-2 text-center font-mono">GD</th>
                      <th className="py-3 pl-2 pr-4 text-center font-mono text-white">Pts</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1D2834] text-xs sm:text-sm">
                    {countryStandings.map((row) => (
                      <tr key={row.teamId} className="hover:bg-[#18222C]/70 transition-colors">
                        <td className="py-3 pl-4 pr-2 font-mono tabular-nums font-semibold text-slate-200">
                          {row.pos}
                        </td>
                        <td className="py-3 px-2">
                          <button
                            type="button"
                            onClick={() => onOpenTeamProfile(row.teamId)}
                            className="inline-flex items-center gap-2.5 text-left group"
                          >
                            <TeamCrest
                              teamId={row.teamId}
                              shortName={row.shortName}
                              color={row.color}
                              logoUrl={row.logoUrl}
                              size="sm"
                            />
                            <span className="font-semibold text-white group-hover:text-emerald-300 transition-colors">
                              {row.teamName}
                            </span>
                          </button>
                        </td>
                        <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                          {row.played}
                        </td>
                        <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                          {row.won}
                        </td>
                        <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                          {row.drawn}
                        </td>
                        <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                          {row.lost}
                        </td>
                        <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                          {row.gd > 0 ? `+${row.gd}` : row.gd}
                        </td>
                        <td className="py-3 pl-2 pr-4 text-center font-mono tabular-nums font-bold text-white">
                          {row.pts}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <p className="rounded-xl border border-[#24313F] bg-[#121A22] px-4 py-4 text-xs text-slate-400">
              {countryStandingsNote ||
                `Live standings are currently unavailable for ${selectedCountry.leagueName}.`}
            </p>
          )}
        </div>
      </section>
    );
  }

  return (
    <section aria-label="African Football Hub" className="space-y-6">
      {/* Header & Search */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 space-y-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <Globe2 className="w-4 h-4" aria-hidden="true" />
            <span>AFRICAN FOOTBALL · CONTINENTAL &amp; DOMESTIC HUB</span>
          </div>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
            African Football Leagues, Cups &amp; CAF Competitions
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-400">
            Follow CAF Champions League, CAF Confederation Cup, AFCON, World Cup African Qualifiers, and national leagues across Tanzania, Kenya, Uganda, South Africa, North &amp; West Africa.
          </p>
        </div>

        {/* CAF Continental Competition Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          {AFRICAN_CONTINENTAL_COMPETITIONS.map((comp) => (
            <button
              key={comp.id}
              type="button"
              onClick={() => onOpenLeagueTable(comp.id)}
              className="text-left rounded-xl border border-[#24313F] bg-[#0F1720] p-4 hover:border-emerald-500/50 transition-colors flex flex-col justify-between gap-2"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <Trophy className="w-4 h-4 text-amber-400" aria-hidden="true" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                    Live Feed
                  </span>
                </div>
                <div className="mt-2 font-display text-sm font-bold text-white">{comp.name}</div>
                <p className="mt-0.5 text-[11px] text-slate-400">{comp.subtitle}</p>
              </div>
              <span className="text-xs font-semibold text-emerald-400">Open Standings →</span>
            </button>
          ))}
        </div>

        {/* Country Filters */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[#1D2834]">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {REGION_TAGS.map((tag) => {
              const active = regionFilter === tag;
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setRegionFilter(tag)}
                  className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                  }`}
                >
                  {tag === 'all' ? 'All African Regions' : tag}
                </button>
              );
            })}
          </div>

          <div className="relative w-full sm:w-72">
            <Search
              className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search country, league, or club..."
              aria-label="Search African countries and leagues"
              className="w-full min-h-[40px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-8 pr-8 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear African search"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* African Countries Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCountries.map((country) => (
          <article
            key={country.id}
            className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 flex flex-col justify-between gap-4 hover:border-emerald-500/45 transition-colors"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-amber-400">{country.regionTag}</span>
                <span
                  className={`px-2 py-0.5 rounded border text-[10px] font-semibold ${
                    country.liveApiSupported
                      ? 'bg-emerald-500/15 border-emerald-500/45 text-emerald-300'
                      : 'bg-[#18222C] border-[#24313F] text-slate-400'
                  }`}
                >
                  {country.liveApiSupported ? 'Live Feed Active' : 'CAF / Limited Feed'}
                </span>
              </div>

              <h2 className="font-display text-lg font-bold text-white">{country.name}</h2>
              <div className="text-xs text-slate-300 space-y-1">
                <div>
                  League: <span className="font-medium text-white">{country.leagueName}</span>
                </div>
                <div>
                  Cup: <span className="text-slate-400">{country.nationalCup}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {country.continentalClubs.slice(0, 3).map((club) => (
                  <span
                    key={club}
                    className="px-2 py-0.5 rounded bg-[#0F1720] border border-[#1D2834] text-[11px] text-slate-300"
                  >
                    {club}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 border-t border-[#1D2834] pt-3 text-xs">
              <button
                type="button"
                onClick={() => onOpenLeagueTable(country.leagueId)}
                className="font-medium text-slate-300 hover:text-amber-300 transition-colors"
              >
                League Table
              </button>
              <button
                type="button"
                onClick={() => setSelectedCountry(country)}
                className="font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                Open {country.name} Hub →
              </button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
