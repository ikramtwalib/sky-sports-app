import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ExternalLink,
  Loader2,
  Newspaper,
  RefreshCw,
  Search,
  X,
} from 'lucide-react';
import type { NewsCategory, NewsHeadline } from '../types/football';
import { formatTanzaniaClock } from '../utils/footballUtils';

interface NewsViewProps {
  articles: NewsHeadline[];
  loading?: boolean;
  error?: string | null;
  lastUpdatedIso?: string | null;
  onRefresh?: () => void;
}

const CATEGORY_TABS: { id: 'all' | NewsCategory; label: string }[] = [
  { id: 'all', label: 'All News' },
  { id: 'Breaking', label: 'Breaking' },
  { id: 'Africa', label: 'Africa' },
  { id: 'Tanzania', label: 'Tanzania' },
  { id: 'International', label: 'International' },
  { id: 'Transfer', label: 'Transfers' },
  { id: 'Injury', label: 'Injuries' },
  { id: 'Manager', label: 'Managers' },
];

export const NewsView: React.FC<NewsViewProps> = ({
  articles,
  loading = false,
  error = null,
  lastUpdatedIso = null,
  onRefresh,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | NewsCategory>('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return articles.filter((art) => {
      if (categoryFilter !== 'all') {
        if (categoryFilter === 'Africa') {
          if (art.category !== 'Africa' && art.region !== 'Africa' && art.category !== 'Tanzania') {
            return false;
          }
        } else if (categoryFilter === 'International') {
          if (
            art.category !== 'International' &&
            art.region !== 'International' &&
            art.category !== 'UCL'
          ) {
            return false;
          }
        } else if (art.category !== categoryFilter) {
          return false;
        }
      }
      if (!q) return true;
      return `${art.title} ${art.summary} ${art.leagueName}`.toLowerCase().includes(q);
    });
  }, [articles, categoryFilter, query]);

  const syncedClock = lastUpdatedIso ? formatTanzaniaClock(lastUpdatedIso) : null;

  return (
    <section aria-label="Sports news headlines" className="space-y-5">
      {/* Header */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <Newspaper className="w-4 h-4" aria-hidden="true" />
              <span>
                {syncedClock
                  ? `Daily Sports News Wire · Synced ${syncedClock}`
                  : 'Daily Sports News Wire · Africa/Dar_es_Salaam (EAT)'}
              </span>
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-white tracking-tight">
              Football &amp; Global Sports News
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              Verified breaking headlines, African &amp; Tanzanian football stories, match reports, injury updates, and coaching news.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <div className="rounded-lg border border-[#1D2834] bg-[#0B1117] px-3.5 py-2 text-right">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Live Articles</div>
              <div className="font-mono tabular-nums text-lg font-bold text-emerald-400">
                {articles.length}
              </div>
            </div>
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={loading}
                className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-semibold text-slate-200 hover:border-emerald-500/60 hover:text-white disabled:opacity-60 transition-colors"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-emerald-400' : ''}`}
                  aria-hidden="true"
                />
                <span>Refresh News</span>
              </button>
            )}
          </div>
        </div>

        {/* Category Tabs & Search */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-2 border-t border-[#1D2834]">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {CATEGORY_TABS.map((tab) => {
              const active = categoryFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setCategoryFilter(tab.id)}
                  className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="relative w-full lg:w-72">
            <Search
              className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search headlines, clubs, players..."
              aria-label="Search sports news"
              className="w-full min-h-[40px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-8 pr-8 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear news search"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Articles */}
      {loading && articles.length === 0 ? (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3 text-center">
          <Loader2 className="w-7 h-7 animate-spin text-emerald-400" aria-hidden="true" />
          <p className="text-sm font-medium text-white">
            Retrieving latest international &amp; African football news...
          </p>
        </div>
      ) : error && articles.length === 0 ? (
        <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-6 space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Live Sports News Feed Unavailable
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">{error}</p>
            </div>
          </div>
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Retry News Feed
            </button>
          )}
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((art) => (
            <article
              key={art.id}
              className="rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden flex flex-col justify-between hover:border-emerald-500/45 transition-colors"
            >
              <div>
                {art.imageUrl && (
                  <div className="h-44 w-full overflow-hidden bg-[#0B1117]">
                    <img
                      src={art.imageUrl}
                      alt={art.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-center"
                      onError={(e) => {
                        (e.currentTarget.parentElement as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                )}

                <div className="p-4 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-amber-400 truncate">
                      {art.category} · {art.leagueName}
                    </span>
                    <span className="font-mono tabular-nums text-[11px] text-slate-400 shrink-0">
                      {art.publishedEatLabel || art.timeAgo}
                    </span>
                  </div>

                  <h2 className="font-display text-base font-bold text-white leading-snug">
                    {art.title}
                  </h2>
                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                    {art.summary}
                  </p>
                </div>
              </div>

              <div className="px-4 pb-4 pt-3 border-t border-[#1D2834] flex items-center justify-between gap-3 text-xs">
                <span className="text-slate-400 truncate">
                  {art.sourceName || 'ESPN Football Wire'}
                </span>
                {art.externalUrl && (
                  <a
                    href={art.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-emerald-400 hover:text-emerald-300 shrink-0"
                  >
                    <span>Read Story</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 text-center space-y-3">
          <p className="text-sm text-slate-300">
            No live news articles match your active category or search filter right now.
          </p>
          {(categoryFilter !== 'all' || query) && (
            <button
              type="button"
              onClick={() => {
                setCategoryFilter('all');
                setQuery('');
              }}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Show All News
            </button>
          )}
        </div>
      )}
    </section>
  );
};
