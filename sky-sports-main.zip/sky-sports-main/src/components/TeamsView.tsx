import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Check,
  ExternalLink,
  Globe2,
  Loader2,
  MapPin,
  Plus,
  Search,
  Table2,
  UserCheck,
  X,
} from 'lucide-react';
import { fetchTeamDetail } from '../services/footballApi';
import type {
  FootballMatch,
  LeagueInfo,
  PlayerStat,
  TeamDetailApiResponse,
  TeamProfile,
} from '../types/football';
import { searchTeamsAndCompetitions } from '../utils/footballUtils';
import { PlayerAvatar } from './PlayerAvatar';
import { TeamCrest } from './TeamCrest';

interface TeamsViewProps {
  teams: TeamProfile[];
  leagues: LeagueInfo[];
  matches: FootballMatch[];
  players: PlayerStat[];
  loading?: boolean;
  selectedTeamId: string | null;
  followedTeams: string[];
  onSelectTeam: (teamId: string | null) => void;
  onToggleFollowTeam: (teamId: string) => void;
  onOpenMatchDetail: (match: FootballMatch) => void;
  onOpenLeagueTable: (leagueId: string) => void;
}

export const TeamsView: React.FC<TeamsViewProps> = ({
  teams,
  leagues,
  matches,
  players,
  loading = false,
  selectedTeamId,
  followedTeams,
  onSelectTeam,
  onToggleFollowTeam,
  onOpenMatchDetail,
  onOpenLeagueTable,
}) => {
  const [query, setQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<'all' | string>('all');
  const [teamDetailState, setTeamDetailState] = useState<{
    loading: boolean;
    error: string | null;
    data: TeamDetailApiResponse | null;
  }>({ loading: false, error: null, data: null });
  const [selectedRosterPlayer, setSelectedRosterPlayer] = useState<PlayerStat | null>(null);

  const { teams: searchedTeams, leagues: searchedLeagues } = useMemo(
    () => searchTeamsAndCompetitions({ teams, leagues, query }),
    [teams, leagues, query]
  );

  const matchedTeams = useMemo(
    () =>
      selectedRegion === 'all'
        ? searchedTeams
        : searchedTeams.filter((t) => t.region === selectedRegion),
    [searchedTeams, selectedRegion]
  );

  const matchedLeagues = useMemo(
    () =>
      selectedRegion === 'all'
        ? searchedLeagues
        : searchedLeagues.filter((l) => l.region === selectedRegion),
    [searchedLeagues, selectedRegion]
  );

  const baseActiveTeam = useMemo(() => {
    if (!selectedTeamId) return null;
    const found = teams.find((t) => t.id === selectedTeamId);
    if (found) return found;

    // Synthesize reference when user opens a club directly from a live match card
    const matchRef = matches.find(
      (m) => m.homeTeamId === selectedTeamId || m.awayTeamId === selectedTeamId
    );
    if (!matchRef) return null;
    const isHome = matchRef.homeTeamId === selectedTeamId;
    return {
      id: selectedTeamId,
      externalTeamId: isHome ? matchRef.homeExternalTeamId : matchRef.awayExternalTeamId,
      name: isHome ? matchRef.homeTeam : matchRef.awayTeam,
      shortName: isHome ? matchRef.homeShort : matchRef.awayShort,
      country: matchRef.country,
      leagueId: matchRef.leagueId,
      leagueName: matchRef.league,
      region: matchRef.region,
      stadium: matchRef.venue,
      capacity: '',
      manager: '',
      founded: null,
      primaryColor: isHome ? matchRef.homeColor : matchRef.awayColor,
      secondaryColor: '#FFFFFF',
      logoUrl: isHome ? matchRef.homeLogo : matchRef.awayLogo,
      leaguePosition: null,
      form: [],
      summary: `Competing in ${matchRef.league} (${matchRef.country}).`,
      source: 'live' as const,
    };
  }, [selectedTeamId, teams, matches]);

  // Fetch live club detail, full squad roster & fixtures whenever an external team ID is available
  useEffect(() => {
    if (!baseActiveTeam?.externalTeamId || !baseActiveTeam.leagueId) {
      setTeamDetailState({ loading: false, error: null, data: null });
      return;
    }

    let cancelled = false;
    setTeamDetailState({ loading: true, error: null, data: null });

    fetchTeamDetail(baseActiveTeam.leagueId, baseActiveTeam.externalTeamId)
      .then((res) => {
        if (cancelled) return;
        setTeamDetailState({ loading: false, error: null, data: res });
      })
      .catch((err) => {
        if (cancelled) return;
        setTeamDetailState({
          loading: false,
          error: err instanceof Error ? err.message : 'Unable to fetch club squad details.',
          data: null,
        });
      });

    return () => {
      cancelled = true;
    };
  }, [baseActiveTeam?.leagueId, baseActiveTeam?.externalTeamId]);

  const activeTeam = useMemo(() => {
    if (!baseActiveTeam) return null;
    const enriched = teamDetailState.data?.team;
    if (!enriched) return baseActiveTeam;
    return {
      ...baseActiveTeam,
      ...enriched,
      id: baseActiveTeam.id,
      leaguePosition: baseActiveTeam.leaguePosition ?? enriched.leaguePosition,
      form: baseActiveTeam.form.length > 0 ? baseActiveTeam.form : enriched.form,
      stadium:
        enriched.stadium && enriched.stadium !== 'Club Venue'
          ? enriched.stadium
          : baseActiveTeam.stadium,
    };
  }, [baseActiveTeam, teamDetailState.data]);

  const teamMatches = useMemo(() => {
    if (!activeTeam) return [];
    const map = new Map<string, FootballMatch>();
    for (const m of teamDetailState.data?.matches || []) {
      map.set(m.id, m);
    }
    for (const m of matches) {
      if (m.homeTeamId === activeTeam.id || m.awayTeamId === activeTeam.id) {
        map.set(m.id, m);
      }
    }
    return Array.from(map.values());
  }, [activeTeam, matches, teamDetailState.data]);

  const teamPlayers = useMemo(() => {
    if (!activeTeam) return [];
    const squad = teamDetailState.data?.squad || [];
    if (squad.length > 0) return squad;
    return players.filter(
      (p) =>
        p.teamId === activeTeam.id ||
        (activeTeam.externalTeamId && p.externalTeamId === activeTeam.externalTeamId)
    );
  }, [activeTeam, players, teamDetailState.data]);

  if (activeTeam) {
    const isFollowed = followedTeams.includes(activeTeam.id);
    const standingLabel =
      activeTeam.standingSummary ||
      (typeof activeTeam.leaguePosition === 'number'
        ? `#${activeTeam.leaguePosition} in ${activeTeam.leagueName}`
        : 'Unavailable');

    return (
      <section aria-label={`Team profile: ${activeTeam.name}`} className="space-y-5">
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => onSelectTeam(null)}
            className="inline-flex items-center gap-2 min-h-[40px] px-3.5 py-2 rounded-lg border border-[#24313F] bg-[#121A22] text-xs font-medium text-slate-200 hover:text-white hover:border-slate-500 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            <span>Back to Teams &amp; Competitions</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenLeagueTable(activeTeam.leagueId)}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-[#24313F] bg-[#121A22] text-xs font-medium text-emerald-300 hover:border-emerald-500/60 hover:text-white transition-colors"
          >
            <Table2 className="w-4 h-4" aria-hidden="true" />
            <span>View League Table</span>
          </button>
        </div>

        {/* Club Hero Summary */}
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <TeamCrest
                teamId={activeTeam.id}
                shortName={activeTeam.shortName}
                color={activeTeam.primaryColor}
                secondaryColor={activeTeam.secondaryColor}
                logoUrl={activeTeam.logoUrl}
                size="lg"
              />
              <div>
                <p className="text-xs font-semibold text-amber-400">
                  {activeTeam.leagueName} · {activeTeam.country}
                </p>
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight">
                  {activeTeam.name}
                </h1>
                <p className="mt-1 text-xs text-slate-400">
                  Live Football API Club Profile
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onToggleFollowTeam(activeTeam.id)}
              className={`inline-flex items-center justify-center gap-2 min-h-[44px] px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                isFollowed
                  ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300 hover:bg-emerald-600/30'
                  : 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-500'
              }`}
            >
              {isFollowed ? (
                <>
                  <Check className="w-4 h-4" aria-hidden="true" />
                  <span>Following Club</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" aria-hidden="true" />
                  <span>Follow Club</span>
                </>
              )}
            </button>
          </div>

          <p className="mt-4 text-sm text-slate-300 leading-relaxed">{activeTeam.summary}</p>

          {/* Club Key Metadata Grid */}
          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
              <div className="text-[11px] text-slate-400">League Standing</div>
              <div className="mt-1 font-mono tabular-nums text-sm sm:text-base font-bold text-emerald-400 truncate">
                {standingLabel}
              </div>
            </div>
            <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
              <div className="text-[11px] text-slate-400">Season Record</div>
              <div className="mt-1 font-mono tabular-nums text-sm font-semibold text-white truncate">
                {activeTeam.recordSummary || 'See Standings'}
              </div>
            </div>
            <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
              <div className="text-[11px] text-slate-400">Home Ground</div>
              <div className="mt-1 text-sm font-semibold text-white truncate">
                {activeTeam.stadium || 'Club Stadium'}
              </div>
            </div>
            <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
              <div className="text-[11px] text-slate-400">Registered Squad</div>
              <div className="mt-1 font-mono tabular-nums text-sm font-semibold text-amber-300">
                {teamDetailState.loading
                  ? 'Loading...'
                  : teamPlayers.length > 0
                  ? `${teamPlayers.length} Players`
                  : 'Unavailable'}
              </div>
            </div>
          </div>
        </div>

        {/* Club Fixtures & Squad Roster */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-emerald-400" aria-hidden="true" />
              <h2 className="font-display text-base font-bold text-white">
                Club Fixtures &amp; Results
              </h2>
            </div>
            {teamMatches.length > 0 ? (
              <div className="space-y-2.5">
                {teamMatches.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onOpenMatchDetail(m)}
                    className="w-full text-left rounded-lg border border-[#1D2834] bg-[#0F1720] p-3.5 hover:border-emerald-500/50 transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">
                        {m.league} · {m.round}
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-amber-400">
                        {m.timeLabel}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-sm font-semibold text-white">
                      <span>
                        {m.homeTeam} vs {m.awayTeam}
                      </span>
                      <span className="font-mono tabular-nums">
                        {typeof m.homeScore === 'number'
                          ? `${m.homeScore} — ${m.awayScore}`
                          : 'Upcoming'}
                      </span>
                    </div>
                    <div className="mt-1 inline-flex items-center gap-1 text-[11px] text-slate-500">
                      <MapPin className="w-3 h-3" aria-hidden="true" />
                      {m.venue}
                    </div>
                  </button>
                ))}
              </div>
            ) : teamDetailState.loading ? (
              <div className="flex items-center gap-2 py-4 text-xs text-slate-400">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
                <span>Retrieving club matchday schedule...</span>
              </div>
            ) : (
              <p className="text-xs text-slate-400">
                No fixtures listed for this club in the current matchday window.
              </p>
            )}
          </div>

          {/* Real Squad Roster & Player Statistics */}
          <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-amber-400" aria-hidden="true" />
                <h2 className="font-display text-base font-bold text-white">
                  First-Team Squad &amp; Statistics
                </h2>
              </div>
              {teamDetailState.loading && (
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
              )}
            </div>

            {teamDetailState.loading && teamPlayers.length === 0 ? (
              <div className="flex items-center gap-2 py-6 text-xs text-slate-400">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
                <span>Retrieving live club squad roster and player stats...</span>
              </div>
            ) : teamDetailState.error ? (
              <div className="rounded-lg border border-amber-400/40 bg-[#0F1720] p-4 flex items-start gap-2.5 text-xs text-slate-300">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{teamDetailState.error}</span>
              </div>
            ) : teamPlayers.length > 0 ? (
              <div className="divide-y divide-[#1D2834] max-h-[460px] overflow-y-auto pr-1">
                {teamPlayers.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedRosterPlayer(p)}
                    className="w-full py-2.5 flex items-center justify-between gap-3 text-xs text-left hover:bg-[#18222C]/60 px-2 rounded-lg transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <PlayerAvatar
                        name={p.name}
                        src={p.headshotUrl}
                        accentColor={activeTeam.primaryColor}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <div className="font-semibold text-white text-sm truncate flex items-center gap-2">
                          {p.jersey && (
                            <span className="font-mono text-xs text-amber-400">#{p.jersey}</span>
                          )}
                          <span className="truncate">{p.name}</span>
                        </div>
                        <div className="text-slate-400 truncate">
                          {p.position} · {p.nationality}
                          {typeof p.age === 'number' ? ` · Age ${p.age}` : ''}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 font-mono tabular-nums shrink-0">
                      <div className="text-right">
                        <div className="text-emerald-400 font-bold">{p.goals}G</div>
                        <div className="text-[11px] text-slate-400">{p.assists}A</div>
                      </div>
                      <div className="text-right">
                        <div className="text-slate-200 font-semibold">{p.appearances}</div>
                        <div className="text-[11px] text-slate-400">Apps</div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400">
                Live squad roster is currently unavailable for this club from the current data provider.
              </p>
            )}
          </div>
        </div>

        {/* Squad Player Quick Modal */}
        {selectedRosterPlayer && (
          <div
            role="dialog"
            aria-modal="true"
            aria-label={`Player profile for ${selectedRosterPlayer.name}`}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
            onClick={() => setSelectedRosterPlayer(null)}
          >
            <div
              className="w-full max-w-md rounded-2xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <PlayerAvatar
                    name={selectedRosterPlayer.name}
                    src={selectedRosterPlayer.headshotUrl}
                    accentColor={selectedRosterPlayer.teamColor}
                    size="lg"
                  />
                  <TeamCrest
                    teamId={selectedRosterPlayer.teamId}
                    shortName={selectedRosterPlayer.teamShort}
                    color={selectedRosterPlayer.teamColor}
                    logoUrl={selectedRosterPlayer.clubLogoUrl || activeTeam.logoUrl}
                    size="sm"
                  />
                  <div className="min-w-0">
                    <h2 className="font-display text-xl font-bold text-white truncate">
                      {selectedRosterPlayer.name}
                    </h2>
                    <p className="text-xs text-slate-400 truncate">
                      {selectedRosterPlayer.teamName} · {selectedRosterPlayer.position}
                      {selectedRosterPlayer.jersey ? ` · #${selectedRosterPlayer.jersey}` : ''}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedRosterPlayer(null)}
                  aria-label="Close player profile"
                  className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-[#18222C]"
                >
                  <X className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>

              <div className="mt-5 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                  <div className="text-[11px] text-slate-400">Goals</div>
                  <div className="mt-1 font-mono tabular-nums text-xl font-bold text-emerald-400">
                    {selectedRosterPlayer.goals}
                  </div>
                </div>
                <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                  <div className="text-[11px] text-slate-400">Assists</div>
                  <div className="mt-1 font-mono tabular-nums text-xl font-bold text-white">
                    {selectedRosterPlayer.assists}
                  </div>
                </div>
                <div className="rounded-lg border border-[#1D2834] bg-[#0F1720] p-3">
                  <div className="text-[11px] text-slate-400">Appearances</div>
                  <div className="mt-1 font-mono tabular-nums text-xl font-bold text-amber-400">
                    {selectedRosterPlayer.appearances}
                  </div>
                </div>
              </div>

              <dl className="mt-4 divide-y divide-[#1D2834] text-xs">
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Nationality</dt>
                  <dd className="text-white font-medium">{selectedRosterPlayer.nationality}</dd>
                </div>
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Age</dt>
                  <dd className="text-white font-medium">
                    {typeof selectedRosterPlayer.age === 'number'
                      ? `${selectedRosterPlayer.age} yrs`
                      : 'N/A'}
                  </dd>
                </div>
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Shots on Target</dt>
                  <dd className="font-mono tabular-nums text-white">
                    {selectedRosterPlayer.shotsOnTarget}
                  </dd>
                </div>
                {typeof selectedRosterPlayer.saves === 'number' && selectedRosterPlayer.position === 'GK' && (
                  <div className="py-2 flex justify-between">
                    <dt className="text-slate-400">Saves</dt>
                    <dd className="font-mono tabular-nums text-white">
                      {selectedRosterPlayer.saves}
                    </dd>
                  </div>
                )}
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Yellow / Red Cards</dt>
                  <dd className="font-mono tabular-nums text-white">
                    {selectedRosterPlayer.yellowCards} / {selectedRosterPlayer.redCards ?? 0}
                  </dd>
                </div>
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Market Value</dt>
                  <dd className="text-slate-400 font-medium">
                    {selectedRosterPlayer.marketValue || 'Not provided by live API'}
                  </dd>
                </div>
                <div className="py-2 flex justify-between">
                  <dt className="text-slate-400">Previous Clubs</dt>
                  <dd className="text-slate-400 font-medium text-right">
                    {selectedRosterPlayer.previousClubs && selectedRosterPlayer.previousClubs.length > 0
                      ? selectedRosterPlayer.previousClubs.join(', ')
                      : 'Not provided by live API'}
                  </dd>
                </div>
              </dl>

              {selectedRosterPlayer.externalUrl && (
                <div className="mt-4 flex justify-end">
                  <a
                    href={selectedRosterPlayer.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 py-2 rounded-lg border border-amber-400/50 bg-amber-500/10 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors"
                  >
                    <span>Full Player Profile</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                </div>
              )}
            </div>
          </div>
        )}
      </section>
    );
  }

  return (
    <section aria-label="Teams and competitions search" className="space-y-6">
      {/* Search Bar */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5">
        <h1 className="font-display text-2xl font-bold text-white tracking-tight">
          Teams &amp; World Competitions
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-slate-400">
          Search clubs, squads, or all {leagues.length} global football leagues.
        </p>

        <div className="relative mt-4">
          <Search
            className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search clubs or leagues (e.g. Arsenal, Sundowns, Al-Hilal, Roshn, Premier League)..."
            aria-label="Search teams and competitions"
            className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-10 pr-10 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Clear search query"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          )}
        </div>

        {/* Region Filter Strip */}
        <div className="mt-3 flex items-center gap-2 overflow-x-auto pb-1">
          {[
            { id: 'all', label: 'All Regions' },
            { id: 'Europe', label: 'Europe' },
            { id: 'Africa', label: 'Africa (SA · TZ · KE · CAF)' },
            { id: 'Asia & Middle East', label: 'Asia & Middle East' },
            { id: 'Americas', label: 'Americas' },
          ].map((reg) => {
            const active = selectedRegion === reg.id;
            return (
              <button
                key={reg.id}
                type="button"
                aria-pressed={active}
                onClick={() => setSelectedRegion(reg.id)}
                className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 transition-colors ${
                  active
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:border-slate-500 hover:text-white'
                }`}
              >
                {reg.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Matching Teams Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-lg font-bold text-white">
            Club Profiles ({matchedTeams.length})
          </h2>
        </div>

        {loading && teams.length === 0 ? (
          <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 flex items-center justify-center gap-2.5 text-sm text-slate-300">
            <Loader2 className="w-5 h-5 animate-spin text-emerald-400" aria-hidden="true" />
            <span>Loading live club profiles and official crests...</span>
          </div>
        ) : matchedTeams.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {matchedTeams.map((team) => {
              const isFollowed = followedTeams.includes(team.id);
              return (
                <article
                  key={team.id}
                  className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 flex flex-col justify-between gap-4 hover:border-emerald-500/45 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => onSelectTeam(team.id)}
                      className="flex items-center gap-3 text-left min-w-0 group"
                    >
                      <TeamCrest
                        teamId={team.id}
                        shortName={team.shortName}
                        color={team.primaryColor}
                        secondaryColor={team.secondaryColor}
                        logoUrl={team.logoUrl}
                        size="md"
                      />
                      <div className="min-w-0">
                        <h3 className="font-display text-base font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                          {team.name}
                        </h3>
                        <p className="text-xs text-slate-400 truncate">
                          {team.leagueName} · {team.country}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onToggleFollowTeam(team.id)}
                      aria-label={isFollowed ? `Unfollow ${team.name}` : `Follow ${team.name}`}
                      className={`min-h-[36px] px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors shrink-0 ${
                        isFollowed
                          ? 'bg-emerald-600/20 border-emerald-500/60 text-emerald-300'
                          : 'bg-[#18222C] border-[#24313F] text-slate-300 hover:border-slate-500'
                      }`}
                    >
                      {isFollowed ? 'Following' : 'Follow'}
                    </button>
                  </div>

                  <div className="text-xs text-slate-400 space-y-1">
                    <div>
                      Competition: <span className="text-slate-200">{team.leagueName}</span>
                    </div>
                    {team.stadium && team.stadium !== 'Club Venue' && (
                      <div>
                        Venue: <span className="text-slate-200">{team.stadium}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between border-t border-[#1D2834] pt-3 text-xs">
                    <span className="font-mono tabular-nums text-amber-400 font-semibold">
                      {typeof team.leaguePosition === 'number'
                        ? `League Pos #${team.leaguePosition}`
                        : team.country}
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectTeam(team.id)}
                      className="font-semibold text-emerald-400 hover:text-emerald-300"
                    >
                      Open Club Profile →
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <p className="rounded-xl border border-[#24313F] bg-[#121A22] p-6 text-center text-sm text-slate-400">
            {query
              ? `No live club profiles match "${query}".`
              : 'No live club profiles available for this region right now.'}
          </p>
        )}
      </div>

      {/* Matching World Competitions */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Globe2 className="w-4 h-4 text-emerald-400" aria-hidden="true" />
          <h2 className="font-display text-lg font-bold text-white">
            World Competitions ({matchedLeagues.length})
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {matchedLeagues.map((league) => (
            <button
              key={league.id}
              type="button"
              onClick={() => onOpenLeagueTable(league.id)}
              className="text-left rounded-xl border border-[#24313F] bg-[#121A22] p-4 hover:border-amber-400/50 transition-colors flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <div className="font-semibold text-sm text-white truncate">{league.name}</div>
                <div className="text-xs text-slate-400 truncate">
                  {league.country} · {league.region}
                </div>
              </div>
              <span className="text-xs font-semibold text-emerald-400 shrink-0">Table →</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
