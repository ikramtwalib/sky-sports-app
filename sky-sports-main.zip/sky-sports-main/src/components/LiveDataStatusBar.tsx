import React from 'react';
import { AlertTriangle, Loader2, Radio, RefreshCw } from 'lucide-react';
import { formatTanzaniaClock } from '../utils/footballUtils';

interface LiveDataStatusBarProps {
  loading: boolean;
  refreshing: boolean;
  error: string | null;
  lastUpdatedIso: string | null;
  autoRefreshEnabled: boolean;
  secondsToRefresh: number;
  liveCount?: number;
  refreshIntervalSec?: number;
  onToggleAutoRefresh: () => void;
  onManualRefresh: () => void;
}

export const LiveDataStatusBar: React.FC<LiveDataStatusBarProps> = ({
  loading,
  refreshing,
  error,
  lastUpdatedIso,
  autoRefreshEnabled,
  secondsToRefresh,
  liveCount = 0,
  refreshIntervalSec = 45,
  onToggleAutoRefresh,
  onManualRefresh,
}) => {
  const formattedTime = lastUpdatedIso ? formatTanzaniaClock(lastUpdatedIso) : null;

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] px-4 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Left: Live API Status & Tanzania Local Time */}
        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 font-semibold text-emerald-300">
            {loading || refreshing ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <Radio className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
            )}
            <span>LIVE API FEED</span>
          </span>

          {liveCount > 0 && (
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500/15 border border-rose-500/45 font-mono text-[11px] font-bold text-rose-300">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
              {liveCount} LIVE
            </span>
          )}

          <span className="text-slate-300">
            {loading && !lastUpdatedIso
              ? 'Retrieving authentic fixtures, scores, logos & standings...'
              : formattedTime
              ? `Synced ${formattedTime} · Tanzania Local Time (UTC+3)`
              : 'Connecting to secure football API backend (Africa/Dar_es_Salaam)'}
          </span>
        </div>

        {/* Right: Auto-Refresh & Manual Refresh Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onToggleAutoRefresh}
            aria-pressed={autoRefreshEnabled}
            className={`min-h-[36px] px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors whitespace-nowrap ${
              autoRefreshEnabled
                ? 'bg-[#0F1720] border-emerald-500/40 text-emerald-300 hover:border-emerald-400'
                : 'bg-[#0F1720] border-[#24313F] text-slate-400 hover:text-white'
            }`}
          >
            {autoRefreshEnabled ? (
              <span className="font-mono tabular-nums">
                {liveCount > 0 ? `Live ${refreshIntervalSec}s` : `Sync ${refreshIntervalSec}s`} · {secondsToRefresh}s
              </span>
            ) : (
              <span>Auto-Refresh Off</span>
            )}
          </button>

          <button
            type="button"
            onClick={onManualRefresh}
            disabled={loading || refreshing}
            className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-semibold text-slate-200 hover:border-emerald-500/60 hover:text-white disabled:opacity-60 transition-colors whitespace-nowrap"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${loading || refreshing ? 'animate-spin text-emerald-400' : ''}`}
              aria-hidden="true"
            />
            <span>{loading || refreshing ? 'Updating...' : 'Refresh Now'}</span>
          </button>
        </div>
      </div>

      {/* Explicit Error Alert Banner when Live API is Unavailable */}
      {error && (
        <div
          role="alert"
          className="rounded-xl border border-rose-500/50 bg-rose-950/35 px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        >
          <div className="flex items-start gap-2.5 text-xs text-rose-100">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <p className="font-semibold text-white">Live Football Data Temporarily Unavailable</p>
              <p className="mt-0.5 text-rose-200/90">{error}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onManualRefresh}
              className="min-h-[36px] px-3.5 py-1.5 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
            >
              Retry Live Feed
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
