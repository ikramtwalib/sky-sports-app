import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Award, Globe2, Loader2, RefreshCw, ShieldCheck, Trophy } from 'lucide-react';
import type { LeagueInfo, LeagueStatsApiResponse, StandingRow } from '../types/football';
import { fetchLeagueStandings, fetchLeagueStats } from '../services/footballApi';
import { formatTanzaniaClock } from '../utils/footballUtils';
import { PlayerAvatar } from './PlayerAvatar';
import { TeamCrest } from './TeamCrest';

interface LeagueTablesViewProps {
  leagues: LeagueInfo[];
  selectedLeagueId: string;
  autoRefreshEnabled?: boolean;
  standingsRefreshTrigger?: number;
  onSelectLeagueId: (leagueId: string) => void;
  onOpenTeamProfile: (teamId: string) => void;
}

const HEADLINE_LEAGUE_IDS = [
  'epl',
  'ucl',
  'laliga',
  'bundesliga',
  'serie-a',
  'roshn',
  'sa-psl',
  'kenya-fkf',
  'caf-cl',
  'tanzania-nbc',
];

export const LeagueTablesView: React.FC<LeagueTablesViewProps> = ({
  leagues,
  selectedLeagueId,
  autoRefreshEnabled = true,
  standingsRefreshTrigger = 0,
  onSelectLeagueId,
  onOpenTeamProfile,
}) => {
  const currentLeague = useMemo(
    () => leagues.find((l) => l.id === selectedLeagueId) || leagues[0],
    [leagues, selectedLeagueId]
  );

  const [standings, setStandings] = useState<StandingRow[]>([]);
  const [liveProvider, setLiveProvider] = useState<string>('');
  const [calculatedFromResults, setCalculatedFromResults] = useState<boolean>(false);
  const [lastSyncedIso, setLastSyncedIso] = useState<string | null>(null);
  const [liveLoading, setLiveLoading] = useState(false);
  const [liveRefreshing, setLiveRefreshing] = useState(false);
  const [liveError, setLiveError] = useState<string | null>(null);
  const [liveUnavailableReason, setLiveUnavailableReason] = useState<string | null>(null);

  const [leagueStats, setLeagueStats] = useState<LeagueStatsApiResponse | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [statsTab, setStatsTab] = useState<'scorers' | 'assists' | 'apps'>('scorers');

  const loadLiveStandings = useCallback(async (leagueId: string, isBackgroundOrManual = false) => {
    if (isBackgroundOrManual) {
      setLiveRefreshing(true);
    } else {
      setLiveLoading(true);
    }
    setLiveError(null);
    setLiveUnavailableReason(null);
    try {
      const res = await fetchLeagueStandings(leagueId, isBackgroundOrManual);
      setLiveProvider(res.provider);
      setCalculatedFromResults(Boolean(res.calculatedFromResults));
      setLastSyncedIso(res.fetchedAt);
      if (!res.available || res.standings.length === 0) {
        if (!isBackgroundOrManual || standings.length === 0) {
          setStandings([]);
          setLiveUnavailableReason(
            res.reason || 'Live standings are currently unavailable for this league.'
          );
        }
      } else {
        setStandings(res.standings);
      }
    } catch (err) {
      if (!isBackgroundOrManual || standings.length === 0) {
        setStandings([]);
        setLiveError(
          err instanceof Error ? err.message : 'Unable to fetch live league standings.'
        );
      }
    } finally {
      setLiveLoading(false);
      setLiveRefreshing(false);
    }
  }, [standings.length]);

  useEffect(() => {
    if (currentLeague) {
      loadLiveStandings(currentLeague.id, false);
    }
  }, [currentLeague?.id]);

  // Re-fetch immediately when a live match completes
  useEffect(() => {
    if (standingsRefreshTrigger > 0 && currentLeague) {
      loadLiveStandings(currentLeague.id, true);
    }
  }, [standingsRefreshTrigger, currentLeague, loadLiveStandings]);

  // Load league top scorers, assists, appearances
  useEffect(() => {
    if (!currentLeague) return;
    let cancelled = false;
    setStatsLoading(true);
    fetchLeagueStats(currentLeague.id)
      .then((res) => {
        if (!cancelled) setLeagueStats(res);
      })
      .catch(() => {
        if (!cancelled) setLeagueStats(null);
      })
      .finally(() => {
        if (!cancelled) setStatsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [currentLeague?.id]);

  // Automatic 45-second live table synchronization matching server standings TTL
  useEffect(() => {
    if (!autoRefreshEnabled || !currentLeague) return undefined;
    const timer = window.setInterval(() => {
      loadLiveStandings(currentLeague.id, true);
    }, 45_000);
    return () => window.clearInterval(timer);
  }, [autoRefreshEnabled, currentLeague, loadLiveStandings]);

  const teamPerformanceHighlights = useMemo(() => {
    if (standings.length === 0) return null;
    const topAttack = [...standings].sort((a, b) => b.gf - a.gf || b.pts - a.pts)[0]!;
    const bestDefense = [...standings].sort((a, b) => a.ga - b.ga || b.pts - a.pts)[0]!;
    const bestDiff = [...standings].sort((a, b) => b.gd - a.gd || b.pts - a.pts)[0]!;
    return { topAttack, bestDefense, bestDiff };
  }, [standings]);

  const headlineLeagues = useMemo(
    () =>
      HEADLINE_LEAGUE_IDS.map((id) => leagues.find((l) => l.id === id)).filter(
        (l): l is LeagueInfo => Boolean(l)
      ),
    [leagues]
  );

  const syncedClock = lastSyncedIso ? formatTanzaniaClock(lastSyncedIso) : null;

  return (
    <section aria-label="Football league tables" className="space-y-5">
      {/* Header & Global League Picker */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
              <Trophy className="w-4 h-4 text-emerald-400" aria-hidden="true" />
              <span className="text-emerald-400">
                2026/27 Live League Standings {liveProvider ? `· ${liveProvider}` : ''}
              </span>
              {calculatedFromResults && (
                <span className="px-2 py-0.5 rounded bg-amber-500/15 border border-amber-400/40 text-[11px] text-amber-300">
                  Calculated from Results
                </span>
              )}
              {syncedClock && (
                <span className="font-mono text-[11px] text-slate-400">
                  · Synced {syncedClock} {autoRefreshEnabled ? '· Auto-updates 45s' : ''}
                </span>
              )}
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-white tracking-tight">
              {currentLeague.name}
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              {currentLeague.country} · {currentLeague.region} · Defending Champion:{' '}
              <span className="text-amber-300 font-medium">{currentLeague.defendingChampion}</span>
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <label htmlFor="world-league-select" className="sr-only">
              Select any world football league
            </label>
            <div className="relative w-full md:w-80">
              <Globe2
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <select
                id="world-league-select"
                value={currentLeague.id}
                onChange={(e) => onSelectLeagueId(e.target.value)}
                className="w-full min-h-[44px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-9 pr-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500"
              >
                {leagues.map((league) => (
                  <option key={league.id} value={league.id}>
                    {league.name} ({league.country})
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => loadLiveStandings(currentLeague.id, true)}
              disabled={liveLoading || liveRefreshing}
              aria-label="Refresh standings"
              className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-lg border border-[#24313F] bg-[#18222C] text-slate-200 hover:border-emerald-500/60 hover:text-white disabled:opacity-50 transition-colors shrink-0"
            >
              <RefreshCw
                className={`w-4 h-4 ${liveLoading || liveRefreshing ? 'animate-spin text-emerald-400' : ''}`}
                aria-hidden="true"
              />
            </button>
          </div>
        </div>

        {/* Headline & African Competition Quick Tabs */}
        <div className="mt-4 flex items-center gap-2 overflow-x-auto md:flex-wrap pb-1">
          {headlineLeagues.map((league) => {
            const active = league.id === currentLeague.id;
            return (
              <button
                key={league.id}
                type="button"
                aria-pressed={active}
                onClick={() => onSelectLeagueId(league.id)}
                className={`min-h-[40px] px-3.5 py-2 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:border-slate-500 hover:text-white'
                }`}
              >
                {league.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Loading / Error / Unavailable / Table */}
      {liveLoading && standings.length === 0 ? (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3 text-center">
          <Loader2 className="w-7 h-7 animate-spin text-emerald-400" aria-hidden="true" />
          <p className="text-sm font-medium text-white">
            Retrieving live standings &amp; authentic club logos for {currentLeague.name}...
          </p>
        </div>
      ) : liveError || liveUnavailableReason || standings.length === 0 ? (
        <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-6 space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="space-y-1">
              <h2 className="font-display text-base font-bold text-white">
                {liveError ? 'Unable to Retrieve Live Standings' : 'Live Standings Unavailable'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300">
                {liveError ||
                  liveUnavailableReason ||
                  `Live standings are currently unavailable for ${currentLeague.name}.`}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => loadLiveStandings(currentLeague.id)}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Retry Live Table
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#24313F] bg-[#0F1720] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <th className="py-3 pl-4 pr-2 w-12">Pos</th>
                  <th className="py-3 px-2 min-w-[180px]">Club</th>
                  <th className="py-3 px-2 text-center font-mono">P</th>
                  <th className="py-3 px-2 text-center font-mono">W</th>
                  <th className="py-3 px-2 text-center font-mono">D</th>
                  <th className="py-3 px-2 text-center font-mono">L</th>
                  <th className="py-3 px-2 text-center font-mono hidden sm:table-cell">GF</th>
                  <th className="py-3 px-2 text-center font-mono hidden sm:table-cell">GA</th>
                  <th className="py-3 px-2 text-center font-mono">GD</th>
                  <th className="py-3 px-2 text-center font-mono text-white">Pts</th>
                  <th className="py-3 pl-2 pr-4 text-right hidden md:table-cell">Form</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D2834] text-xs sm:text-sm">
                {standings.map((row) => {
                  const zoneColor =
                    row.zone === 'champions'
                      ? 'bg-emerald-400'
                      : row.zone === 'continental'
                      ? 'bg-amber-400'
                      : row.zone === 'relegation'
                      ? 'bg-rose-400'
                      : 'bg-slate-600';

                  return (
                    <tr
                      key={row.teamId}
                      className="hover:bg-[#18222C]/70 transition-colors"
                    >
                      <td className="py-3 pl-4 pr-2">
                        <div className="flex items-center gap-2">
                          <span
                            aria-hidden="true"
                            className={`w-1.5 h-3.5 rounded-xs shrink-0 ${zoneColor}`}
                          />
                          <span className="font-mono tabular-nums font-semibold text-slate-200">
                            {row.pos}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-2">
                        <button
                          type="button"
                          onClick={() => onOpenTeamProfile(row.teamId)}
                          className="inline-flex items-center gap-2.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
                        >
                          <TeamCrest
                            teamId={row.teamId}
                            shortName={row.shortName}
                            color={row.color}
                            logoUrl={row.logoUrl}
                            size="sm"
                          />
                          <span className="font-semibold text-white group-hover:text-emerald-300 transition-colors">
                            {row.teamName}
                          </span>
                        </button>
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                        {row.played}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                        {row.won}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                        {row.drawn}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-300">
                        {row.lost}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-400 hidden sm:table-cell">
                        {row.gf}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums text-slate-400 hidden sm:table-cell">
                        {row.ga}
                      </td>
                      <td
                        className={`py-3 px-2 text-center font-mono tabular-nums font-medium ${
                          row.gd > 0
                            ? 'text-emerald-400'
                            : row.gd < 0
                            ? 'text-rose-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {row.gd > 0 ? `+${row.gd}` : row.gd}
                      </td>
                      <td className="py-3 px-2 text-center font-mono tabular-nums font-bold text-white">
                        {row.pts}
                      </td>
                      <td className="py-3 pl-2 pr-4 hidden md:table-cell">
                        {row.form.length > 0 ? (
                          <div className="flex items-center justify-end gap-1 font-mono text-[11px] font-bold">
                            {row.form.map((res, idx) => (
                              <span
                                key={`${row.teamId}-f-${idx}`}
                                className={`w-5 h-5 inline-flex items-center justify-center rounded ${
                                  res === 'W'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : res === 'D'
                                    ? 'bg-amber-500/20 text-amber-300'
                                    : 'bg-rose-500/20 text-rose-300'
                                }`}
                              >
                                {res}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <div className="text-right font-mono text-[11px] text-slate-500">
                            {row.won}-{row.drawn}-{row.lost}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Zone Legend */}
          <div className="flex flex-wrap items-center gap-5 border-t border-[#1D2834] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
            <span className="inline-flex items-center gap-2">
              <span aria-hidden="true" className="w-2 h-2.5 rounded-xs bg-emerald-400" />
              Champions Qualification
            </span>
            <span className="inline-flex items-center gap-2">
              <span aria-hidden="true" className="w-2 h-2.5 rounded-xs bg-amber-400" />
              Continental Qualification
            </span>
            <span className="inline-flex items-center gap-2">
              <span aria-hidden="true" className="w-2 h-2.5 rounded-xs bg-rose-400" />
              Relegation / Playoff Zone
            </span>
          </div>
        </div>
      )}

      {/* League Statistics: Top Scorers, Assists, Appearances & Team Attack/Defense */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
              <Award className="w-4 h-4" aria-hidden="true" />
              <span>League Statistics &amp; Leaders</span>
            </div>
            <h2 className="mt-1 font-display text-xl font-bold text-white">
              {currentLeague.name} Statistical Leaders
            </h2>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {(
              [
                { id: 'scorers', label: 'Top Scorers' },
                { id: 'assists', label: 'Top Assists' },
                { id: 'apps', label: 'Most Appearances' },
              ] as const
            ).map((tab) => {
              const active = statsTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setStatsTab(tab.id)}
                  className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Team Attack & Defense Summary Derived From Live Standings */}
        {teamPerformanceHighlights && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => onOpenTeamProfile(teamPerformanceHighlights.topAttack.teamId)}
              className="text-left rounded-lg border border-[#1D2834] bg-[#0F1720] p-3.5 hover:border-emerald-500/40 transition-colors"
            >
              <div className="text-[11px] uppercase tracking-wider text-slate-400">
                Most Goals Scored
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="font-semibold text-sm text-white truncate">
                  {teamPerformanceHighlights.topAttack.teamName}
                </span>
                <span className="font-mono font-bold text-emerald-400 shrink-0">
                  {teamPerformanceHighlights.topAttack.gf} GF
                </span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onOpenTeamProfile(teamPerformanceHighlights.bestDefense.teamId)}
              className="text-left rounded-lg border border-[#1D2834] bg-[#0F1720] p-3.5 hover:border-emerald-500/40 transition-colors"
            >
              <div className="text-[11px] uppercase tracking-wider text-slate-400">
                Fewest Goals Conceded
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="font-semibold text-sm text-white truncate">
                  {teamPerformanceHighlights.bestDefense.teamName}
                </span>
                <span className="font-mono font-bold text-amber-400 shrink-0">
                  {teamPerformanceHighlights.bestDefense.ga} GA
                </span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onOpenTeamProfile(teamPerformanceHighlights.bestDiff.teamId)}
              className="text-left rounded-lg border border-[#1D2834] bg-[#0F1720] p-3.5 hover:border-emerald-500/40 transition-colors"
            >
              <div className="text-[11px] uppercase tracking-wider text-slate-400">
                Best Goal Difference
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="font-semibold text-sm text-white truncate">
                  {teamPerformanceHighlights.bestDiff.teamName}
                </span>
                <span className="font-mono font-bold text-sky-300 shrink-0">
                  {teamPerformanceHighlights.bestDiff.gd > 0
                    ? `+${teamPerformanceHighlights.bestDiff.gd}`
                    : teamPerformanceHighlights.bestDiff.gd} GD
                </span>
              </div>
            </button>
          </div>
        )}

        {/* Player Leaders Leaderboard */}
        {statsLoading ? (
          <div className="flex items-center gap-2 py-6 text-xs text-slate-400">
            <Loader2 className="w-4 h-4 animate-spin text-emerald-400" aria-hidden="true" />
            <span>Retrieving {currentLeague.name} top scorers and assist leaders...</span>
          </div>
        ) : leagueStats && leagueStats.available ? (
          (() => {
            const list =
              statsTab === 'scorers'
                ? leagueStats.topScorers
                : statsTab === 'assists'
                ? leagueStats.topAssists
                : leagueStats.mostAppearances;

            if (list.length === 0) {
              return (
                <p className="rounded-lg border border-[#1D2834] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
                  No player records are currently available for this category in {currentLeague.name}.
                </p>
              );
            }

            return (
              <div className="divide-y divide-[#1D2834] rounded-xl border border-[#1D2834] bg-[#0F1720]">
                {list.slice(0, 10).map((player, idx) => (
                  <div
                    key={player.id}
                    className="flex items-center justify-between gap-3 px-4 py-3 text-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="font-mono tabular-nums font-bold text-slate-400 w-5 shrink-0">
                        {idx + 1}
                      </span>
                      <PlayerAvatar
                        name={player.name}
                        src={player.headshotUrl}
                        accentColor={player.teamColor}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <div className="font-semibold text-white text-sm truncate">
                          {player.name}
                        </div>
                        <button
                          type="button"
                          onClick={() => onOpenTeamProfile(player.teamId)}
                          className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 hover:text-emerald-300 truncate"
                        >
                          <TeamCrest
                            teamId={player.teamId}
                            shortName={player.teamShort}
                            color={player.teamColor}
                            logoUrl={player.clubLogoUrl}
                            size="sm"
                          />
                          <span>{player.teamName}</span>
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 font-mono tabular-nums shrink-0">
                      <div className="text-right">
                        <div className="text-slate-400 text-[10px]">Apps</div>
                        <div className="text-slate-200 font-semibold">{player.appearances}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-slate-400 text-[10px]">Goals</div>
                        <div className="text-emerald-400 font-bold">{player.goals}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-slate-400 text-[10px]">Assists</div>
                        <div className="text-amber-300 font-bold">{player.assists}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()
        ) : (
          <p className="rounded-lg border border-[#1D2834] bg-[#0F1720] px-4 py-3 text-xs text-slate-400">
            {leagueStats?.reason ||
              `Player scoring and assist leaderboards are currently unavailable for ${currentLeague.name}.`}
          </p>
        )}

        <div className="flex items-start gap-2 rounded-lg border border-[#1D2834] bg-[#0B1117] px-3.5 py-2.5 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" aria-hidden="true" />
          <span>
            Note: League clean-sheet goalkeeper leaderboards and player market valuations are unavailable from the connected free live football data API and are intentionally omitted rather than estimated.
          </span>
        </div>
      </div>
    </section>
  );
};
