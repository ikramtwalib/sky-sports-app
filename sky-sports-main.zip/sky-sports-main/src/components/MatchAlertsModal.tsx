import React from 'react';
import { Bell, BellRing, Send, Trash2, X } from 'lucide-react';
import type { FootballMatch, MatchAlertItem } from '../types/football';
import { TeamCrest } from './TeamCrest';

interface MatchAlertsModalProps {
  isOpen: boolean;
  alerts: MatchAlertItem[];
  matches: FootballMatch[];
  browserNotifStatus?: 'unsupported' | 'default' | 'granted' | 'denied';
  browserNotifEnabled?: boolean;
  onToggleBrowserNotif?: () => void;
  onClose: () => void;
  onUpdateAlert: (
    matchId: string,
    patch: Partial<Pick<MatchAlertItem, 'notifyKickoff' | 'notifyGoals' | 'notifyFullTime'>>
  ) => void;
  onRemoveAlert: (matchId: string) => void;
  onPreviewAlert: (match: FootballMatch) => void;
  onOpenMatchDetail: (match: FootballMatch) => void;
}

export const MatchAlertsModal: React.FC<MatchAlertsModalProps> = ({
  isOpen,
  alerts,
  matches,
  browserNotifStatus = 'default',
  browserNotifEnabled = false,
  onToggleBrowserNotif,
  onClose,
  onUpdateAlert,
  onRemoveAlert,
  onPreviewAlert,
  onOpenMatchDetail,
}) => {
  if (!isOpen) return null;

  const alertRows = alerts
    .map((alert) => ({
      alert,
      match: matches.find((m) => m.id === alert.matchId),
    }))
    .filter((item): item is { alert: MatchAlertItem; match: FootballMatch } => Boolean(item.match));

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Match Alerts Manager"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-5 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-[#24313F] bg-[#121A22] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-[#24313F] bg-[#0F1720]/95 backdrop-blur-sm px-5 py-4">
          <div className="flex items-center gap-2.5">
            <BellRing className="w-5 h-5 text-amber-400" aria-hidden="true" />
            <div>
              <h2 className="font-display text-lg font-bold text-white">
                Match Alerts ({alertRows.length})
              </h2>
              <p className="text-xs text-slate-400">
                Matchday alerts with authentic club crests · Kickoff, goals &amp; full-time updates
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Match Alerts"
            className="min-h-[40px] min-w-[40px] inline-flex items-center justify-center rounded-lg border border-[#24313F] bg-[#18222C] text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {onToggleBrowserNotif && (
            <div className="rounded-xl border border-[#24313F] bg-[#0F1720] px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs">
                <div className="font-semibold text-white">
                  Automatic Browser Push Notifications
                </div>
                <div className="text-slate-400 mt-0.5">
                  {browserNotifStatus === 'unsupported'
                    ? 'In-app toast alerts active during 30s live updates.'
                    : browserNotifStatus === 'denied'
                    ? 'Browser notifications blocked in site settings — in-app toast alerts stay active.'
                    : browserNotifEnabled && browserNotifStatus === 'granted'
                    ? 'Desktop & Android browser alerts enabled for kickoffs, goals & full-time scores.'
                    : 'Enable device alerts when goals or kickoffs occur during 30s auto-sync.'}
                </div>
              </div>
              {browserNotifStatus !== 'unsupported' && browserNotifStatus !== 'denied' && (
                <button
                  type="button"
                  onClick={onToggleBrowserNotif}
                  aria-pressed={browserNotifEnabled}
                  className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                    browserNotifEnabled && browserNotifStatus === 'granted'
                      ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300 hover:bg-emerald-600/30'
                      : 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-500'
                  }`}
                >
                  {browserNotifEnabled && browserNotifStatus === 'granted'
                    ? 'Browser Alerts On'
                    : 'Enable Browser Alerts'}
                </button>
              )}
            </div>
          )}

          {alertRows.length > 0 ? (
            alertRows.map(({ alert, match }) => (
              <article
                key={match.id}
                className="rounded-xl border border-[#24313F] bg-[#0F1720] p-4 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMatchDetail(match);
                    }}
                    className="flex items-center gap-3 text-left group min-w-0"
                  >
                    <div className="flex items-center -space-x-2 shrink-0">
                      <TeamCrest
                        teamId={match.homeTeamId}
                        shortName={match.homeShort}
                        color={match.homeColor}
                        logoUrl={match.homeLogo}
                        size="md"
                      />
                      <TeamCrest
                        teamId={match.awayTeamId}
                        shortName={match.awayShort}
                        color={match.awayColor}
                        logoUrl={match.awayLogo}
                        size="md"
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="font-display text-sm sm:text-base font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                        {match.homeTeam} vs {match.awayTeam}
                      </div>
                      <div className="text-xs text-slate-400 truncate">
                        {match.league} ·{' '}
                        <span className="font-mono tabular-nums text-amber-400">
                          {match.timeLabel}
                        </span>
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onPreviewAlert(match)}
                      className="inline-flex items-center gap-1.5 min-h-[36px] px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-600/15 text-xs font-semibold text-emerald-300 hover:bg-emerald-600/25 transition-colors whitespace-nowrap"
                    >
                      <Send className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Preview Alert</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveAlert(match.id)}
                      aria-label={`Remove alert for ${match.homeTeam} vs ${match.awayTeam}`}
                      className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg border border-[#24313F] bg-[#121A22] text-slate-400 hover:text-rose-400 hover:border-rose-400/50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 border-t border-[#1D2834] pt-3 text-xs text-slate-300">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={alert.notifyKickoff}
                      onChange={(e) =>
                        onUpdateAlert(match.id, { notifyKickoff: e.target.checked })
                      }
                      className="h-4 w-4 accent-emerald-500"
                    />
                    <span>Kickoff Reminder</span>
                  </label>
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={alert.notifyGoals}
                      onChange={(e) =>
                        onUpdateAlert(match.id, { notifyGoals: e.target.checked })
                      }
                      className="h-4 w-4 accent-emerald-500"
                    />
                    <span>Goals &amp; Red Cards</span>
                  </label>
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={alert.notifyFullTime}
                      onChange={(e) =>
                        onUpdateAlert(match.id, { notifyFullTime: e.target.checked })
                      }
                      className="h-4 w-4 accent-emerald-500"
                    />
                    <span>Full-Time Score</span>
                  </label>
                </div>
              </article>
            ))
          ) : (
            <div className="rounded-xl border border-[#24313F] bg-[#0F1720] p-8 text-center space-y-2">
              <Bell className="w-7 h-7 text-slate-500 mx-auto" aria-hidden="true" />
              <p className="text-sm font-medium text-slate-200">No match alerts set yet</p>
              <p className="text-xs text-slate-400">
                Tap the Alert bell icon on any live or upcoming match card to receive instant matchday notifications.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface MatchAlertToastProps {
  match: FootballMatch | null;
  headline: string;
  onDismiss: () => void;
  onOpenMatchDetail: (match: FootballMatch) => void;
}

export const MatchAlertToast: React.FC<MatchAlertToastProps> = ({
  match,
  headline,
  onDismiss,
  onOpenMatchDetail,
}) => {
  if (!match) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-16 right-4 left-4 sm:left-auto sm:w-[400px] md:bottom-5 z-40 rounded-xl border border-amber-400/60 bg-[#121A22] p-3.5 shadow-2xl"
    >
      <div className="flex items-start gap-3">
        <div className="flex items-center -space-x-2 shrink-0 pt-0.5">
          <TeamCrest
            teamId={match.homeTeamId}
            shortName={match.homeShort}
            color={match.homeColor}
            logoUrl={match.homeLogo}
            size="sm"
          />
          <TeamCrest
            teamId={match.awayTeamId}
            shortName={match.awayShort}
            color={match.awayColor}
            logoUrl={match.awayLogo}
            size="sm"
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wide">
            <BellRing className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>Sky Sports Match Alert</span>
          </div>
          <p className="mt-0.5 text-xs font-semibold text-white leading-snug">{headline}</p>
          <div className="mt-1.5 flex items-center gap-3">
            <button
              type="button"
              onClick={() => onOpenMatchDetail(match)}
              className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300"
            >
              Open Match Center →
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss match alert notification"
          className="p-1 rounded text-slate-400 hover:text-white shrink-0"
        >
          <X className="w-4 h-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
};
