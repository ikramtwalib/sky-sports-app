import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ExternalLink,
  Loader2,
  Newspaper,
  RefreshCw,
  Search,
  X,
} from 'lucide-react';
import type { NewsHeadline, RegionId, TransferDealClassification } from '../types/football';
import { formatTanzaniaClock } from '../utils/footballUtils';

interface TransfersViewProps {
  stories: NewsHeadline[];
  loading?: boolean;
  error?: string | null;
  lastUpdatedIso?: string | null;
  onRefresh?: () => void;
}

const REGION_OPTIONS: { id: RegionId; label: string }[] = [
  { id: 'all', label: 'All Regions' },
  { id: 'Europe', label: 'Europe' },
  { id: 'Africa', label: 'Africa' },
  { id: 'Asia & Middle East', label: 'Asia & ME' },
  { id: 'Americas', label: 'Americas' },
];

const DEAL_TYPE_OPTIONS: { id: 'all' | TransferDealClassification; label: string }[] = [
  { id: 'all', label: 'All Updates' },
  { id: 'Confirmed', label: 'Confirmed Signings' },
  { id: 'Loan', label: 'Loan Deals' },
  { id: 'Rumour', label: 'Transfer Rumours' },
];

function badgeStyle(status?: TransferDealClassification): string {
  switch (status) {
    case 'Confirmed':
      return 'bg-emerald-500/15 border-emerald-500/45 text-emerald-300';
    case 'Loan':
      return 'bg-sky-500/15 border-sky-500/45 text-sky-300';
    case 'Rumour':
      return 'bg-amber-500/15 border-amber-400/45 text-amber-300';
    default:
      return 'bg-[#18222C] border-[#24313F] text-slate-300';
  }
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  stories,
  loading = false,
  error = null,
  lastUpdatedIso = null,
  onRefresh,
}) => {
  const [region, setRegion] = useState<RegionId>('all');
  const [dealType, setDealType] = useState<'all' | TransferDealClassification>('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return stories.filter((story) => {
      if (region !== 'all' && story.region && story.region !== region) return false;
      if (region !== 'all' && !story.region) return false;
      if (dealType !== 'all' && (story.transferStatus || 'Report') !== dealType) return false;
      if (!q) return true;
      return `${story.title} ${story.summary} ${story.leagueName}`
        .toLowerCase()
        .includes(q);
    });
  }, [stories, region, dealType, query]);

  const syncedClock = lastUpdatedIso ? formatTanzaniaClock(lastUpdatedIso) : null;

  return (
    <section aria-label="Live football transfer wire" className="space-y-5">
      {/* Header & Live Sync Banner */}
      <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <RefreshCw
                className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`}
                aria-hidden="true"
              />
              <span>
                {syncedClock
                  ? `Live Transfer Wire · Synced ${syncedClock}`
                  : 'Live Transfer Wire · Africa/Dar_es_Salaam (EAT)'}
              </span>
            </div>
            <h1 className="mt-1 font-display text-2xl font-bold text-white tracking-tight">
              Football Transfers &amp; Market Wire
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              Official transfers, confirmed signings, loan deals, and transfer rumours from verified live football wires.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <div className="rounded-lg border border-[#1D2834] bg-[#0B1117] px-3.5 py-2 text-right">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Live Stories</div>
              <div className="font-mono tabular-nums text-lg font-bold text-emerald-400">
                {stories.length}
              </div>
            </div>
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={loading}
                className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-semibold text-slate-200 hover:border-emerald-500/60 hover:text-white disabled:opacity-60 transition-colors"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-emerald-400' : ''}`}
                  aria-hidden="true"
                />
                <span>Refresh Wire</span>
              </button>
            )}
          </div>
        </div>

        {/* Classification & Region Filter + Search */}
        <div className="space-y-3 pt-2 border-t border-[#1D2834]">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {DEAL_TYPE_OPTIONS.map((opt) => {
              const active = dealType === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setDealType(opt.id)}
                  className={`min-h-[34px] px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {REGION_OPTIONS.map((reg) => {
                const active = region === reg.id;
                return (
                  <button
                    key={reg.id}
                    type="button"
                    onClick={() => setRegion(reg.id)}
                    className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                      active
                        ? 'bg-emerald-600 border-emerald-500 text-white'
                        : 'bg-[#0F1720] border-[#24313F] text-slate-300 hover:text-white'
                    }`}
                  >
                    {reg.label}
                  </button>
                );
              })}
            </div>

            <div className="relative w-full sm:w-72">
              <Search
                className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search player, club, or league..."
                aria-label="Search live transfer wire"
                className="w-full min-h-[40px] rounded-lg border border-[#24313F] bg-[#0B1117] pl-8 pr-8 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Clear transfer search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Loading / Error / Stories Grid */}
      {loading && stories.length === 0 ? (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-10 flex flex-col items-center justify-center gap-3 text-center">
          <Loader2 className="w-7 h-7 animate-spin text-emerald-400" aria-hidden="true" />
          <p className="text-sm font-medium text-white">
            Retrieving live football transfer reports from news feeds...
          </p>
        </div>
      ) : error && stories.length === 0 ? (
        <div className="rounded-xl border border-amber-400/40 bg-[#121A22] p-6 space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Live Transfer Wire Unavailable
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-300">{error}</p>
            </div>
          </div>
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Retry Transfer Wire
            </button>
          )}
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((story) => (
            <article
              key={story.id}
              className="rounded-xl border border-[#24313F] bg-[#121A22] overflow-hidden flex flex-col justify-between hover:border-emerald-500/45 transition-colors"
            >
              <div>
                {story.imageUrl && (
                  <div className="h-40 w-full overflow-hidden bg-[#0B1117]">
                    <img
                      src={story.imageUrl}
                      alt={story.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-center"
                      onError={(e) => {
                        (e.currentTarget.parentElement as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                )}

                <div className="p-4 sm:p-5 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase tracking-wider shrink-0 ${badgeStyle(
                          story.transferStatus
                        )}`}
                      >
                        {story.transferStatus || 'Report'}
                      </span>
                      <span className="inline-flex items-center gap-1.5 font-semibold text-amber-400 truncate">
                        <Newspaper className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span className="truncate">{story.leagueName}</span>
                      </span>
                    </div>
                    <span className="font-mono tabular-nums text-[11px] text-slate-400 shrink-0">
                      {story.publishedEatLabel || story.timeAgo}
                    </span>
                  </div>

                  <h2 className="font-display text-base sm:text-lg font-bold text-white leading-snug">
                    {story.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {story.summary}
                  </p>
                </div>
              </div>

              <div className="px-4 sm:px-5 pb-4 flex items-center justify-between gap-3 border-t border-[#1D2834] pt-3 text-xs">
                <span className="text-slate-400">
                  {story.sourceName || 'ESPN Football Wire'} · {story.region || 'Global'}
                </span>
                {story.externalUrl && (
                  <a
                    href={story.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
                  >
                    <span>Read Full Report</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="rounded-xl border border-[#24313F] bg-[#121A22] p-8 text-center space-y-3">
          <p className="text-sm text-slate-300">
            {stories.length === 0
              ? 'No verified transfer stories are currently listed in the live feed.'
              : 'No transfer stories match your selected deal classification, region, or search filter.'}
          </p>
          {(region !== 'all' || dealType !== 'all' || query) && (
            <button
              type="button"
              onClick={() => {
                setRegion('all');
                setDealType('all');
                setQuery('');
              }}
              className="min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
            >
              Reset Wire Filters
            </button>
          )}
        </div>
      )}
    </section>
  );
};
