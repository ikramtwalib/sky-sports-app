import React, { useEffect, useState } from 'react';

interface PlayerAvatarProps {
  name: string;
  src?: string;
  accentColor?: string;
  size?: 'sm' | 'md' | 'lg';
}

function getInitials(name: string): string {
  const parts = name
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (parts.length === 0) return 'PL';
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return `${parts[0]![0] || ''}${parts[parts.length - 1]![0] || ''}`.toUpperCase();
}

export const PlayerAvatar: React.FC<PlayerAvatarProps> = ({
  name,
  src,
  accentColor = '#10B981',
  size = 'md',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [src]);

  const sizeClass =
    size === 'sm'
      ? 'w-9 h-9 text-[11px]'
      : size === 'lg'
      ? 'w-14 h-14 text-sm'
      : 'w-11 h-11 text-xs';

  if (src && !imgFailed) {
    return (
      <span
        className={`inline-flex items-center justify-center shrink-0 overflow-hidden rounded-full border border-[#24313F] bg-[#18222C] ${sizeClass}`}
      >
        <img
          src={src}
          alt={name}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover object-top"
        />
      </span>
    );
  }

  return (
    <span
      aria-hidden="true"
      style={{ borderColor: `${accentColor}66` }}
      className={`inline-flex items-center justify-center shrink-0 rounded-full border bg-[#18222C] font-mono font-bold text-slate-200 select-none ${sizeClass}`}
    >
      {getInitials(name)}
    </span>
  );
};
