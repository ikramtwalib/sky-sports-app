import React, { useEffect, useId, useState } from 'react';

interface TeamCrestProps {
  teamId?: string;
  shortName: string;
  color: string;
  secondaryColor?: string;
  logoUrl?: string;
  size?: 'sm' | 'md' | 'lg';
}

function hashId(value: string): number {
  let h = 0;
  for (let i = 0; i < value.length; i += 1) {
    h = (h * 31 + value.charCodeAt(i)) >>> 0;
  }
  return h;
}

export const TeamCrest: React.FC<TeamCrestProps> = ({
  teamId = '',
  shortName,
  color,
  secondaryColor = '#FFFFFF',
  logoUrl,
  size = 'md',
}) => {
  const uid = useId().replace(/:/g, '');
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [logoUrl]);

  const id = teamId.toLowerCase();
  const label = shortName.slice(0, 4).toUpperCase();

  const dimensions =
    size === 'sm'
      ? 'w-8 h-8'
      : size === 'lg'
      ? 'w-14 h-14'
      : 'w-10 h-10';

  const clipShieldId = `shield-${uid}`;
  const clipCircleId = `circle-${uid}`;
  const clipOvalId = `oval-${uid}`;
  const maskCrescentId = `crescent-${uid}`;

  const renderSpecificCrest = () => {
    switch (id) {
      case 'arsenal':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M6 5 H34 V21 C34 30 20 36 20 36 C20 36 6 30 6 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="6" y="5" width="28" height="31" fill="#EF0107" />
              <rect x="6" y="5" width="5" height="31" fill="#063672" />
              <rect x="29" y="5" width="5" height="31" fill="#063672" />
              <rect x="12" y="21.5" width="15" height="3.2" rx="1.2" fill="#9C824A" />
              <circle cx="22.5" cy="24.8" r="3" fill="#FFFFFF" stroke="#9C824A" strokeWidth="1.2" />
              <path d="M12 20.5 L9 22 L12 24 Z" fill="#9C824A" />
              <text x="20" y="15" textAnchor="middle" fill="#FFFFFF" fontSize="6" fontWeight="800" fontFamily="sans-serif">
                ARS
              </text>
            </g>
            <path d="M6 5 H34 V21 C34 30 20 36 20 36 C20 36 6 30 6 21 Z" fill="none" stroke="#9C824A" strokeWidth="2" />
          </g>
        );

      case 'chelsea':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#034694" stroke="#DBA111" strokeWidth="2" />
            <circle cx="20" cy="20" r="11.5" fill="none" stroke="#FFFFFF" strokeWidth="1" opacity="0.88" />
            <path d="M14.5 26.5 L16 17 L19.5 13.5 L23.5 15 L25 19 L22 26.5 Z" fill="#FFFFFF" opacity="0.94" />
            <path d="M23.5 11.5 L24.5 26.5" stroke="#DBA111" strokeWidth="1.4" strokeLinecap="round" />
            <circle cx="20.5" cy="12.5" r="2" fill="#DBA111" />
            <text x="20" y="34" textAnchor="middle" fill="#FFFFFF" fontSize="4.6" fontWeight="800" fontFamily="monospace">
              CFC
            </text>
          </g>
        );

      case 'liverpool':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#C8102E" />
              <rect x="7" y="6" width="26" height="6" fill="#00B2A9" />
              <path d="M20 13.5 C23.5 16 24.5 20.5 22 26.5 L20 30 L18 26.5 C15.5 20.5 16.5 16 20 13.5 Z" fill="#F6EB61" />
              <text x="20" y="10.8" textAnchor="middle" fill="#FFFFFF" fontSize="4.8" fontWeight="800" fontFamily="monospace">
                LFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F6EB61" strokeWidth="1.8" />
          </g>
        );

      case 'man-city':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#6CABDD" stroke="#FFFFFF" strokeWidth="2" />
            <circle cx="20" cy="20" r="11.5" fill="#1C2C5B" stroke="#D4AF37" strokeWidth="1.3" />
            <path d="M15 17.5 L20 12 L25 17.5 Z" fill="#D4AF37" />
            <circle cx="20" cy="21" r="2.1" fill="#E11D48" />
            <path d="M14 24.5 L18 28 M18.5 24 L22 27.5 M22.5 23.5 L26 27" stroke="#6CABDD" strokeWidth="1.5" />
          </g>
        );

      case 'man-utd':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#DA291C" />
              <rect x="7" y="6" width="26" height="6" fill="#111827" />
              <path d="M20 14 V28 M15 17 L20 14 L25 17" stroke="#FBE122" strokeWidth="2.2" fill="none" />
              <text x="20" y="10.8" textAnchor="middle" fill="#FBE122" fontSize="4.6" fontWeight="800" fontFamily="monospace">
                MUFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FBE122" strokeWidth="1.8" />
          </g>
        );

      case 'real-madrid':
        return (
          <g>
            <path d="M14 8 L16 3.5 L20 6.5 L24 3.5 L26 8 Z" fill="#FEBE10" />
            <circle cx="20" cy="22.5" r="13.5" fill="#FFFFFF" stroke="#FEBE10" strokeWidth="2.2" />
            <circle cx="20" cy="22.5" r="10.2" fill="none" stroke="#00529F" strokeWidth="1.2" />
            <path d="M11 29.5 L29 15.5" stroke="#00529F" strokeWidth="3.2" opacity="0.9" />
            <text x="20" y="25" textAnchor="middle" fill="#00529F" fontSize="7.2" fontWeight="900" fontFamily="sans-serif">
              MCF
            </text>
          </g>
        );

      case 'barcelona':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M6 6 H34 V21 C34 29 20 36 20 36 C20 36 6 29 6 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="6" y="6" width="14" height="12" fill="#FFFFFF" />
              <rect x="12" y="6" width="2.5" height="12" fill="#DB0030" />
              <rect x="6" y="10.8" width="14" height="2.5" fill="#DB0030" />
              <rect x="20" y="6" width="14" height="12" fill="#FFED02" />
              <rect x="22" y="6" width="2.5" height="12" fill="#DB0030" />
              <rect x="27" y="6" width="2.5" height="12" fill="#DB0030" />
              <rect x="32" y="6" width="2.5" height="12" fill="#DB0030" />
              <rect x="6" y="17.5" width="28" height="6" fill="#EDBB00" />
              <text x="20" y="22.2" textAnchor="middle" fill="#111827" fontSize="5" fontWeight="900" fontFamily="monospace">
                FCB
              </text>
              <rect x="6" y="23.5" width="28" height="13" fill="#004D98" />
              <rect x="11" y="23.5" width="4" height="13" fill="#A50044" />
              <rect x="18" y="23.5" width="4" height="13" fill="#A50044" />
              <rect x="25" y="23.5" width="4" height="13" fill="#A50044" />
            </g>
            <path d="M6 6 H34 V21 C34 29 20 36 20 36 C20 36 6 29 6 21 Z" fill="none" stroke="#EDBB00" strokeWidth="1.8" />
          </g>
        );

      case 'atletico':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#FFFFFF" />
              <rect x="9" y="6" width="4.5" height="30" fill="#CB3524" />
              <rect x="17.5" y="6" width="4.5" height="30" fill="#CB3524" />
              <rect x="26" y="6" width="4.5" height="30" fill="#CB3524" />
              <polygon points="7,6 24,6 7,22" fill="#1B2A6B" />
              <circle cx="11.5" cy="11" r="1.1" fill="#FFFFFF" />
              <circle cx="15.5" cy="9" r="1.1" fill="#FFFFFF" />
              <circle cx="11.5" cy="15" r="1.1" fill="#FFFFFF" />
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#D4AF37" strokeWidth="1.8" />
          </g>
        );

      case 'bayern':
        return (
          <g>
            <defs>
              <clipPath id={clipCircleId}>
                <circle cx="20" cy="21" r="10" />
              </clipPath>
            </defs>
            {/* 5 Championship Stars */}
            <circle cx="11" cy="5.5" r="1.1" fill="#FACC15" />
            <circle cx="15.5" cy="4.2" r="1.1" fill="#FACC15" />
            <circle cx="20" cy="3.8" r="1.2" fill="#FACC15" />
            <circle cx="24.5" cy="4.2" r="1.1" fill="#FACC15" />
            <circle cx="29" cy="5.5" r="1.1" fill="#FACC15" />
            <circle cx="20" cy="21" r="15" fill="#DC052D" stroke="#FFFFFF" strokeWidth="1.8" />
            <g clipPath={`url(#${clipCircleId})`}>
              <rect x="10" y="11" width="20" height="20" fill="#FFFFFF" />
              <polygon points="15,10 20,15 15,20 10,15" fill="#0066B2" />
              <polygon points="24,10 29,15 24,20 19,15" fill="#0066B2" />
              <polygon points="15,20 20,25 15,30 10,25" fill="#0066B2" />
              <polygon points="24,20 29,25 24,30 19,25" fill="#0066B2" />
            </g>
            <circle cx="20" cy="21" r="10" fill="none" stroke="#FFFFFF" strokeWidth="1.3" />
          </g>
        );

      case 'dortmund':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#FDE100" stroke="#111827" strokeWidth="2.4" />
            <circle cx="20" cy="20" r="12.5" fill="none" stroke="#111827" strokeWidth="1.2" />
            <text x="20" y="23" textAnchor="middle" fill="#111827" fontSize="9.5" fontWeight="900" fontFamily="sans-serif">
              BVB
            </text>
          </g>
        );

      case 'leverkusen':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#111827" stroke="#E32221" strokeWidth="2.4" />
            <rect x="10" y="17" width="20" height="6" fill="#E32221" />
            <text x="20" y="22" textAnchor="middle" fill="#FFFFFF" fontSize="6" fontWeight="900" fontFamily="monospace">
              B04
            </text>
          </g>
        );

      case 'inter':
        return (
          <g>
            {/* Latest 2-Star Crest */}
            <circle cx="16.5" cy="4.2" r="1.4" fill="#FACC15" />
            <circle cx="23.5" cy="4.2" r="1.4" fill="#FACC15" />
            <circle cx="20" cy="21.5" r="14.8" fill="#010E80" stroke="#D4AF37" strokeWidth="1.8" />
            <circle cx="20" cy="21.5" r="11" fill="#0B1117" stroke="#FFFFFF" strokeWidth="1.1" />
            <circle cx="20" cy="21.5" r="7.8" fill="#010E80" stroke="#D4AF37" strokeWidth="1" />
            <text x="20" y="24.2" textAnchor="middle" fill="#FFFFFF" fontSize="7.2" fontWeight="900" fontFamily="sans-serif">
              IM
            </text>
          </g>
        );

      case 'ac-milan':
        return (
          <g>
            <defs>
              <clipPath id={clipOvalId}>
                <ellipse cx="20" cy="21" rx="11.8" ry="15" />
              </clipPath>
            </defs>
            <circle cx="20" cy="3.8" r="1.3" fill="#FACC15" />
            <g clipPath={`url(#${clipOvalId})`}>
              <rect x="8" y="6" width="12" height="30" fill="#111827" />
              <rect x="11" y="6" width="3" height="30" fill="#FB090B" />
              <rect x="16.5" y="6" width="3" height="30" fill="#FB090B" />
              <rect x="20" y="6" width="12" height="30" fill="#FFFFFF" />
              <rect x="24.5" y="6" width="3" height="30" fill="#FB090B" />
              <rect x="20" y="19.5" width="12" height="3.2" fill="#FB090B" />
            </g>
            <ellipse cx="20" cy="21" rx="11.8" ry="15" fill="none" stroke="#E5E7EB" strokeWidth="1.8" />
          </g>
        );

      case 'napoli':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#003C82" stroke="#FFFFFF" strokeWidth="1.8" />
            <circle cx="20" cy="20" r="12.5" fill="#12A0D7" stroke="#FFFFFF" strokeWidth="1.2" />
            <text x="20" y="25" textAnchor="middle" fill="#FFFFFF" fontSize="14" fontWeight="900" fontFamily="sans-serif">
              N
            </text>
          </g>
        );

      case 'juventus':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#111827" stroke="#FFFFFF" strokeWidth="1.8" />
            {/* Latest Double-J Monogram */}
            <path d="M13 11 H18 V24 C18 28 14 29 12 28" fill="none" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
            <path d="M21 11 H26 V24 C26 28 22 29 20 28" fill="none" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
          </g>
        );

      case 'al-hilal':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
              <mask id={maskCrescentId}>
                <rect x="7" y="6" width="26" height="30" fill="#000000" />
                <circle cx="19" cy="20" r="8.2" fill="#FFFFFF" />
                <circle cx="22.8" cy="20" r="6.8" fill="#000000" />
              </mask>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#0055B8" />
              <rect x="7" y="6" width="26" height="30" fill="#FFFFFF" mask={`url(#${maskCrescentId})`} />
              <circle cx="24.5" cy="20" r="2.1" fill="#F5C400" />
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#93C5FD" strokeWidth="1.8" />
          </g>
        );

      case 'al-nassr':
        return (
          <g>
            <path d="M14 7 L17 4 L20 6.5 L23 4 L26 7 Z" fill="#FCD116" />
            <circle cx="20" cy="21.5" r="14" fill="#FCD116" stroke="#0038A8" strokeWidth="2.2" />
            <circle cx="20" cy="21.5" r="9.5" fill="#0038A8" />
            <text x="20" y="24" textAnchor="middle" fill="#FCD116" fontSize="6.8" fontWeight="900" fontFamily="monospace">
              NAS
            </text>
          </g>
        );

      case 'al-ittihad':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#111827" />
              <rect x="11" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="18" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="25" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="7" y="6" width="26" height="7" fill="#111827" />
              <text x="20" y="11.5" textAnchor="middle" fill="#F5C400" fontSize="4.6" fontWeight="900" fontFamily="monospace">
                ITT
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'al-ahli-ksa':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#008751" />
              <path d="M20 11 L20 27 M15 16 Q20 12 25 16 M14 20 Q20 16 26 20" stroke="#FFFFFF" strokeWidth="2" fill="none" />
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'psg':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#004170" stroke="#FFFFFF" strokeWidth="2" />
            <path d="M16 29 L19.2 12 H20.8 L24 29 H21.5 L20 22 L18.5 29 Z" fill="#DA291C" />
            <circle cx="20" cy="25" r="2.2" fill="#FFFFFF" />
          </g>
        );

      case 'flamengo':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#111827" />
              <rect x="7" y="10" width="26" height="5" fill="#C52613" />
              <rect x="7" y="20" width="26" height="5" fill="#C52613" />
              <rect x="7" y="30" width="26" height="5" fill="#C52613" />
              <rect x="7" y="6" width="12" height="12" fill="#C52613" />
              <text x="13" y="14" textAnchor="middle" fill="#FFFFFF" fontSize="5.5" fontWeight="900" fontFamily="monospace">
                FLA
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#E5E7EB" strokeWidth="1.6" />
          </g>
        );

      case 'inter-miami':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#F7B5CD" stroke="#111827" strokeWidth="2.2" />
            <circle cx="20" cy="20" r="11.5" fill="#111827" />
            <path d="M16 26 V16 L13 13 M24 26 V16 L27 13" stroke="#F7B5CD" strokeWidth="2.2" strokeLinecap="round" fill="none" />
          </g>
        );

      // AFRICAN CLUBS CURRENT LOGOS
      case 'sundowns':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#F5C400" />
              <rect x="7" y="21" width="26" height="15" fill="#008751" />
              <path d="M10 21 L20 11 L30 21 Z" fill="#008751" />
              <circle cx="20" cy="18" r="2.5" fill="#F5C400" />
              <text x="20" y="29" textAnchor="middle" fill="#FFFFFF" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                MSFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#008751" strokeWidth="2" />
          </g>
        );

      case 'orlando-pirates':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#111827" stroke="#FFFFFF" strokeWidth="2" />
            <circle cx="20" cy="20" r="12" fill="none" stroke="#DC2626" strokeWidth="1.2" />
            {/* Crossed Bones + Skull Crest */}
            <path d="M13 26 L27 14 M13 14 L27 26" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
            <circle cx="20" cy="18.5" r="4.5" fill="#FFFFFF" />
            <circle cx="18.4" cy="18.2" r="1" fill="#111827" />
            <circle cx="21.6" cy="18.2" r="1" fill="#111827" />
          </g>
        );

      case 'kaizer-chiefs':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#F59E0B" />
              <circle cx="20" cy="18" r="7" fill="#111827" />
              <path d="M14 14 L20 9 L26 14" stroke="#FFFFFF" strokeWidth="2" fill="none" />
              <text x="20" y="20.5" textAnchor="middle" fill="#F59E0B" fontSize="6" fontWeight="900" fontFamily="monospace">
                KC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#111827" strokeWidth="2" />
          </g>
        );

      case 'stellenbosch':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#581C3A" />
              <circle cx="20" cy="19" r="6" fill="#D4AF37" />
              <text x="20" y="21.5" textAnchor="middle" fill="#581C3A" fontSize="5.8" fontWeight="900" fontFamily="monospace">
                SFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#D4AF37" strokeWidth="1.8" />
          </g>
        );

      case 'yanga':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#008751" />
              <rect x="7" y="6" width="26" height="8" fill="#F5C400" />
              {/* Stylized Africa Emblem */}
              <path d="M16 16 H24 L25 22 L20 29 L18 23 L15 20 Z" fill="#F5C400" />
              <text x="20" y="12" textAnchor="middle" fill="#008751" fontSize="4.6" fontWeight="900" fontFamily="monospace">
                YANGA
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'simba':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#DC2626" />
              <circle cx="20" cy="20" r="7.5" fill="#FFFFFF" />
              <circle cx="20" cy="20" r="4.8" fill="#F59E0B" />
              <text x="20" y="11" textAnchor="middle" fill="#FFFFFF" fontSize="4.6" fontWeight="900" fontFamily="monospace">
                SIMBA
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'azam':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#0055A5" />
              <rect x="7" y="16" width="26" height="8" fill="#FFFFFF" />
              <text x="20" y="22" textAnchor="middle" fill="#0055A5" fontSize="6" fontWeight="900" fontFamily="monospace">
                AZAM
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'gor-mahia':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#008751" />
              <rect x="17.5" y="6" width="5" height="30" fill="#FFFFFF" />
              <circle cx="20" cy="20" r="6.5" fill="#111827" stroke="#FACC15" strokeWidth="1.4" />
              <text x="20" y="22.3" textAnchor="middle" fill="#FFFFFF" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                GOR
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'afc-leopards':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#FFFFFF" />
              <rect x="9" y="6" width="5" height="30" fill="#0055B8" />
              <rect x="17.5" y="6" width="5" height="30" fill="#0055B8" />
              <rect x="26" y="6" width="5" height="30" fill="#0055B8" />
              <circle cx="20" cy="20" r="6.5" fill="#111827" stroke="#FACC15" strokeWidth="1.2" />
              <text x="20" y="22.2" textAnchor="middle" fill="#FFFFFF" fontSize="5.2" fontWeight="900" fontFamily="monospace">
                AFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#0055B8" strokeWidth="1.8" />
          </g>
        );

      case 'tusker':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#EAB308" />
              <rect x="7" y="6" width="26" height="8" fill="#111827" />
              {/* Twin Tusks */}
              <path d="M13 24 Q14 16 18 15" stroke="#FFFFFF" strokeWidth="2.4" strokeLinecap="round" fill="none" />
              <path d="M27 24 Q26 16 22 15" stroke="#FFFFFF" strokeWidth="2.4" strokeLinecap="round" fill="none" />
              <text x="20" y="12" textAnchor="middle" fill="#EAB308" fontSize="4.6" fontWeight="900" fontFamily="monospace">
                TUSKER
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#111827" strokeWidth="1.8" />
          </g>
        );

      case 'kenya-police':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#1E3A8A" />
              <circle cx="20" cy="19" r="6.5" fill="#F5C400" />
              <text x="20" y="21.5" textAnchor="middle" fill="#1E3A8A" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                KPF
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'al-ahly-egy':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#D6001C" />
              <path d="M11 16 L20 22 L29 16 L24 26 L16 26 Z" fill="#111827" />
              <circle cx="20" cy="11.5" r="2" fill="#F5C400" />
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'zamalek':
        return (
          <g>
            <circle cx="20" cy="20" r="16" fill="#FFFFFF" stroke="#DC2626" strokeWidth="2.2" />
            <rect x="6" y="16" width="28" height="3" fill="#DC2626" />
            <rect x="6" y="21" width="28" height="3" fill="#DC2626" />
            <circle cx="20" cy="19.5" r="4.5" fill="#111827" />
          </g>
        );

      case 'raja-ca':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#007A3D" />
              <path d="M12 18 L20 14 L28 18 L22 25 L18 25 Z" fill="#FFFFFF" />
              <circle cx="15" cy="10.5" r="1.2" fill="#FACC15" />
              <circle cx="20" cy="10" r="1.2" fill="#FACC15" />
              <circle cx="25" cy="10.5" r="1.2" fill="#FACC15" />
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FACC15" strokeWidth="1.8" />
          </g>
        );

      case 'wydad-ac':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#C8102E" />
              <text x="20" y="23" textAnchor="middle" fill="#FFFFFF" fontSize="6.8" fontWeight="900" fontFamily="monospace">
                WAC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'esperance':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#C8102E" />
              <rect x="11" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="18" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="25" y="6" width="4" height="30" fill="#F5C400" />
              <rect x="7" y="15" width="26" height="8" fill="#111827" />
              <text x="20" y="21" textAnchor="middle" fill="#F5C400" fontSize="5.8" fontWeight="900" fontFamily="monospace">
                EST
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'enyimba':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#0055A5" />
              <circle cx="20" cy="19" r="7" fill="#FFFFFF" />
              <text x="20" y="21.5" textAnchor="middle" fill="#0055A5" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                ENY
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'lazio':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#87D8F7" />
              <rect x="7" y="18" width="26" height="18" fill="#FFFFFF" />
              <path d="M11 14 L20 11 L29 14 L23 19 L17 19 Z" fill="#F5C400" />
              <text x="20" y="29" textAnchor="middle" fill="#0F172A" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                LAZIO
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'roma':
      case 'as-roma':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="14" fill="#F5C400" />
              <rect x="7" y="20" width="26" height="16" fill="#8E1F2F" />
              <circle cx="20" cy="14" r="4.5" fill="#111827" />
              <text x="20" y="29" textAnchor="middle" fill="#F5C400" fontSize="5.5" fontWeight="900" fontFamily="monospace">
                ASR
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      case 'como':
        return (
          <g>
            <circle cx="20" cy="20" r="15.5" fill="#0055B8" stroke="#FFFFFF" strokeWidth="2" />
            <path d="M8 23 Q14 19 20 23 Q26 27 32 23" stroke="#FFFFFF" strokeWidth="2" fill="none" />
            <text x="20" y="17.5" textAnchor="middle" fill="#FFFFFF" fontSize="6.4" fontWeight="900" fontFamily="monospace">
              COMO
            </text>
          </g>
        );

      case 'brighton':
        return (
          <g>
            <circle cx="20" cy="20" r="15.5" fill="#0057B8" stroke="#FFFFFF" strokeWidth="2" />
            <circle cx="20" cy="20" r="11" fill="#FFFFFF" />
            <path d="M12 20 Q16 15 20 19 Q24 15 28 20" stroke="#0057B8" strokeWidth="2.4" fill="none" strokeLinecap="round" />
            <text x="20" y="28" textAnchor="middle" fill="#0057B8" fontSize="5" fontWeight="900" fontFamily="monospace">
              BHA
            </text>
          </g>
        );

      case 'everton':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#003399" />
              <rect x="17" y="13" width="6" height="14" fill="#FFFFFF" />
              <polygon points="15,13 20,8 25,13" fill="#FFFFFF" />
              <text x="20" y="32" textAnchor="middle" fill="#FFFFFF" fontSize="4.8" fontWeight="900" fontFamily="monospace">
                EFC
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );

      case 'freiburg':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="13" height="30" fill="#DC052D" />
              <rect x="20" y="6" width="13" height="30" fill="#111827" />
              <circle cx="20" cy="20" r="6.8" fill="#FFFFFF" />
              <text x="20" y="22.5" textAnchor="middle" fill="#111827" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                SCF
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeWidth="1.6" />
          </g>
        );

      case 'real-betis':
        return (
          <g>
            <polygon points="20,6 33,28 7,28" fill="#00954C" stroke="#FFFFFF" strokeWidth="1.8" />
            <circle cx="20" cy="20" r="6" fill="#FFFFFF" />
            <text x="20" y="22.3" textAnchor="middle" fill="#00954C" fontSize="5.4" fontWeight="900" fontFamily="monospace">
              RBB
            </text>
          </g>
        );

      case 'al-qadsiah':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#F5C400" />
              <rect x="7" y="16" width="26" height="9" fill="#DA291C" />
              <text x="20" y="22.5" textAnchor="middle" fill="#FFFFFF" fontSize="5.6" fontWeight="900" fontFamily="monospace">
                QAD
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#DA291C" strokeWidth="1.8" />
          </g>
        );

      case 'neom-sc':
        return (
          <g>
            <circle cx="20" cy="20" r="15.5" fill="#0B1117" stroke="#0D9488" strokeWidth="2.2" />
            <polygon points="20,8 29,20 20,32 11,20" fill="none" stroke="#2DD4BF" strokeWidth="1.6" />
            <text x="20" y="22.2" textAnchor="middle" fill="#FFFFFF" fontSize="5.4" fontWeight="900" fontFamily="monospace">
              NEOM
            </text>
          </g>
        );

      case 'wiliete':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#EA580C" />
              <rect x="7" y="16" width="26" height="8" fill="#111827" />
              <text x="20" y="22" textAnchor="middle" fill="#FACC15" fontSize="5.6" fontWeight="900" fontFamily="monospace">
                WIL
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FACC15" strokeWidth="1.8" />
          </g>
        );

      case 'jkt-tanzania':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#15803D" />
              <circle cx="20" cy="19" r="6.8" fill="#FACC15" />
              <text x="20" y="21.4" textAnchor="middle" fill="#111827" fontSize="5.4" fontWeight="900" fontFamily="monospace">
                JKT
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FACC15" strokeWidth="1.8" />
          </g>
        );

      case 'pyramids':
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill="#1D4ED8" />
              <polygon points="10,27 20,11 30,27" fill="#F5C400" />
              <text x="20" y="25" textAnchor="middle" fill="#111827" fontSize="5.2" fontWeight="900" fontFamily="monospace">
                PYR
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#F5C400" strokeWidth="1.8" />
          </g>
        );

      default: {
        const variant = hashId(id || label) % 4;
        if (variant === 0) {
          return (
            <g>
              <circle cx="20" cy="20" r="15.5" fill={color} stroke={secondaryColor} strokeWidth="1.8" />
              <circle cx="20" cy="20" r="11.5" fill="#0B1117" opacity="0.72" />
              <text x="20" y="22.8" textAnchor="middle" fill="#FFFFFF" fontSize="8" fontWeight="800" fontFamily="monospace">
                {label.slice(0, 3)}
              </text>
            </g>
          );
        }
        if (variant === 1) {
          return (
            <g>
              <defs>
                <clipPath id={clipShieldId}>
                  <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
                </clipPath>
              </defs>
              <g clipPath={`url(#${clipShieldId})`}>
                <rect x="7" y="6" width="26" height="30" fill="#0E151C" />
                <path d="M5 30 L35 10" stroke={color} strokeWidth="9" />
                <rect x="7" y="15" width="26" height="10" fill="#0B1117" opacity="0.78" />
                <text x="20" y="22.5" textAnchor="middle" fill="#FFFFFF" fontSize="7.5" fontWeight="800" fontFamily="monospace">
                  {label.slice(0, 3)}
                </text>
              </g>
              <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke={color} strokeWidth="2" />
            </g>
          );
        }
        if (variant === 2) {
          return (
            <g>
              <defs>
                <clipPath id={clipShieldId}>
                  <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
                </clipPath>
              </defs>
              <g clipPath={`url(#${clipShieldId})`}>
                <rect x="7" y="6" width="13" height="30" fill={color} />
                <rect x="20" y="6" width="13" height="30" fill="#121A22" />
                <circle cx="20" cy="20" r="8" fill="#0B1117" stroke={secondaryColor} strokeWidth="1.2" />
                <text x="20" y="22.8" textAnchor="middle" fill="#FFFFFF" fontSize="7" fontWeight="800" fontFamily="monospace">
                  {label.slice(0, 3)}
                </text>
              </g>
              <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#E2E8F0" strokeWidth="1.6" />
            </g>
          );
        }
        return (
          <g>
            <defs>
              <clipPath id={clipShieldId}>
                <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" />
              </clipPath>
            </defs>
            <g clipPath={`url(#${clipShieldId})`}>
              <rect x="7" y="6" width="26" height="30" fill={color} />
              <rect x="7" y="6" width="26" height="9" fill="#0B1117" opacity="0.7" />
              <text x="20" y="25" textAnchor="middle" fill="#FFFFFF" fontSize="8" fontWeight="800" fontFamily="monospace">
                {label.slice(0, 3)}
              </text>
            </g>
            <path d="M7 6 H33 V21 C33 30 20 36 20 36 C20 36 7 30 7 21 Z" fill="none" stroke="#FFFFFF" strokeOpacity="0.5" strokeWidth="1.6" />
          </g>
        );
      }
    }
  };

  if (logoUrl && !imgFailed) {
    return (
      <span
        aria-hidden="true"
        className={`inline-flex items-center justify-center shrink-0 select-none rounded-md bg-white/[0.04] p-0.5 ${dimensions}`}
      >
        <img
          src={logoUrl}
          alt=""
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-contain drop-shadow-sm"
        />
      </span>
    );
  }

  return (
    <span
      aria-hidden="true"
      className={`inline-flex items-center justify-center shrink-0 select-none ${dimensions}`}
    >
      <svg viewBox="0 0 40 40" className="w-full h-full drop-shadow-sm">
        {renderSpecificCrest()}
      </svg>
    </span>
  );
};
