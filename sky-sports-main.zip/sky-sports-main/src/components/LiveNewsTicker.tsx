import React, { useState } from 'react';
import { ChevronRight, ExternalLink, Pause, Play, X } from 'lucide-react';
import type { NewsHeadline } from '../types/football';

interface LiveNewsTickerProps {
  headlines: NewsHeadline[];
  onOpenMatch?: (matchId: string) => void;
  onOpenTeam?: (teamId: string) => void;
}

export const LiveNewsTicker: React.FC<LiveNewsTickerProps> = ({
  headlines,
  onOpenMatch,
  onOpenTeam,
}) => {
  const [paused, setPaused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [selectedStory, setSelectedStory] = useState<NewsHeadline | null>(null);

  const isPaused = paused || hovered || selectedStory !== null;

  const getCategoryColor = (category: NewsHeadline['category']) => {
    switch (category) {
      case 'Breaking':
      case 'Match Update':
      case 'Tanzania':
      case 'Africa':
        return 'text-emerald-400';
      case 'Transfer':
      case 'Roshn':
      case 'Injury':
        return 'text-amber-400';
      case 'UCL':
      case 'Serie A':
      case 'International':
      case 'Manager':
        return 'text-sky-300';
      default:
        return 'text-slate-300';
    }
  };

  return (
    <>
      <section
        aria-label="Live football news ticker"
        className="border-b border-[#1D2834] bg-[#0F1720]"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        <div className="mx-auto flex max-w-[1440px] items-center gap-3 px-4 py-2 sm:px-6">
          {/* Left Ticker Label */}
          <div className="flex items-center gap-2 shrink-0 pr-2 border-r border-[#24313F]">
            <span className="text-xs font-bold tracking-wide text-amber-400 whitespace-nowrap">
              SKY SPORTS WIRE
            </span>
          </div>

          {/* Scrolling Marquee Viewport */}
          <div className="relative flex-1 overflow-hidden">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-y-0 left-0 z-10 w-5 bg-gradient-to-r from-[#0F1720] to-transparent"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-y-0 right-0 z-10 w-6 bg-gradient-to-l from-[#0F1720] to-transparent"
            />
            <div
              className={`flex w-max items-center gap-8 pl-3 animate-ticker ${
                isPaused ? 'animate-ticker-paused' : ''
              }`}
            >
              {[...headlines, ...headlines].map((item, idx) => (
                <button
                  key={`${item.id}-${idx}`}
                  type="button"
                  onClick={() => setSelectedStory(item)}
                  className="inline-flex items-center gap-2 text-xs text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-emerald-500 rounded px-1 py-0.5"
                >
                  <span className={`font-semibold ${getCategoryColor(item.category)}`}>
                    {item.category}
                  </span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="font-medium text-slate-100">{item.title}</span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="font-mono tabular-nums text-[11px] text-slate-400">
                    {item.timeAgo}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Pause / Resume Control */}
          <button
            type="button"
            onClick={() => setPaused((prev) => !prev)}
            aria-label={paused ? 'Resume live news ticker' : 'Pause live news ticker'}
            aria-pressed={paused}
            className="inline-flex items-center justify-center min-h-[32px] min-w-[32px] rounded-md border border-[#24313F] bg-[#121A22] text-slate-300 hover:text-white hover:border-emerald-500/60 transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
          >
            {paused ? (
              <Play className="w-3.5 h-3.5" aria-hidden="true" />
            ) : (
              <Pause className="w-3.5 h-3.5" aria-hidden="true" />
            )}
          </button>
        </div>
      </section>

      {/* Story Detail Modal */}
      {selectedStory && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="News headline details"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          onClick={() => setSelectedStory(null)}
        >
          <div
            className="w-full max-w-lg rounded-xl border border-[#24313F] bg-[#121A22] p-5 sm:p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-2 text-xs">
                <span className={`font-semibold ${getCategoryColor(selectedStory.category)}`}>
                  {selectedStory.category}
                </span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-slate-400">{selectedStory.leagueName}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="font-mono tabular-nums text-slate-400">{selectedStory.timeAgo}</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedStory(null)}
                aria-label="Close news brief"
                className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-[#18222C]"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            <h3 className="mt-3 font-display text-lg font-bold text-white leading-snug">
              {selectedStory.title}
            </h3>
            <p className="mt-2.5 text-sm text-slate-300 leading-relaxed">
              {selectedStory.summary}
            </p>

            <div className="mt-5 flex flex-wrap items-center justify-end gap-2 border-t border-[#1D2834] pt-4">
              {selectedStory.externalUrl && (
                <a
                  href={selectedStory.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg border border-amber-400/50 bg-amber-500/10 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors"
                >
                  <span>Full Story</span>
                  <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                </a>
              )}
              {selectedStory.relatedTeamId && onOpenTeam && (
                <button
                  type="button"
                  onClick={() => {
                    const teamId = selectedStory.relatedTeamId!;
                    setSelectedStory(null);
                    onOpenTeam(teamId);
                  }}
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg border border-[#24313F] bg-[#18222C] text-xs font-medium text-slate-200 hover:border-amber-400/60 hover:text-white transition-colors"
                >
                  <span>Club Profile</span>
                  <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              )}
              {selectedStory.relatedMatchId && onOpenMatch && (
                <button
                  type="button"
                  onClick={() => {
                    const matchId = selectedStory.relatedMatchId!;
                    setSelectedStory(null);
                    onOpenMatch(matchId);
                  }}
                  className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors"
                >
                  <span>Open Match Center</span>
                  <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
