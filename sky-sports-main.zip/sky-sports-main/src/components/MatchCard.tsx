import React from 'react';
import { Bell, BellRing, ChevronRight, MapPin } from 'lucide-react';
import type { FootballMatch } from '../types/football';
import { TeamCrest } from './TeamCrest';

interface MatchCardProps {
  match: FootballMatch;
  isAlertSet?: boolean;
  onToggleAlert?: (match: FootballMatch) => void;
  onOpenMatchDetail: (match: FootballMatch) => void;
  onOpenTeamProfile: (teamId: string) => void;
}

export const MatchCard: React.FC<MatchCardProps> = ({
  match,
  isAlertSet = false,
  onToggleAlert,
  onOpenMatchDetail,
  onOpenTeamProfile,
}) => {
  const isLive = match.status === 'live';
  const isResult = match.status === 'result';

  const statusColor = isLive
    ? 'text-emerald-400'
    : isResult
    ? 'text-amber-400'
    : 'text-slate-400';

  const goalEvents = match.events.filter((e) => e.type === 'goal');

  return (
    <article className="rounded-xl border border-[#24313F] bg-[#121A22] p-4 hover:border-emerald-500/45 transition-colors flex flex-col justify-between gap-3">
      {/* Header Metadata Line */}
      <div className="flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="font-medium text-slate-200 truncate">{match.league}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-400 truncate">{match.country}</span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {isLive && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-500/15 border border-rose-500/50 text-[10px] font-bold tracking-wider text-rose-400">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
              LIVE
            </span>
          )}
          <span className={`font-mono tabular-nums font-semibold shrink-0 ${statusColor}`}>
            {match.timeLabel}
          </span>
        </div>
      </div>

      {/* Match Teams & Score Grid */}
      <div className="flex flex-col gap-2.5 py-1">
        {/* Home Team */}
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => onOpenTeamProfile(match.homeTeamId)}
            className="flex items-center gap-2.5 min-w-0 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
          >
            <TeamCrest
              teamId={match.homeTeamId}
              shortName={match.homeShort}
              color={match.homeColor}
              logoUrl={match.homeLogo}
              size="sm"
            />
            <span className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors truncate">
              {match.homeTeam}
            </span>
          </button>
          <span className="font-mono tabular-nums text-base font-bold text-white shrink-0">
            {typeof match.homeScore === 'number' ? match.homeScore : '—'}
          </span>
        </div>

        {/* Away Team */}
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => onOpenTeamProfile(match.awayTeamId)}
            className="flex items-center gap-2.5 min-w-0 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
          >
            <TeamCrest
              teamId={match.awayTeamId}
              shortName={match.awayShort}
              color={match.awayColor}
              logoUrl={match.awayLogo}
              size="sm"
            />
            <span className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors truncate">
              {match.awayTeam}
            </span>
          </button>
          <span className="font-mono tabular-nums text-base font-bold text-white shrink-0">
            {typeof match.awayScore === 'number' ? match.awayScore : '—'}
          </span>
        </div>
      </div>

      {/* Goal Scorers & Minutes if Available */}
      {goalEvents.length > 0 && (
        <div className="border-t border-[#1D2834] pt-2 space-y-1 text-[11px] text-slate-300">
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            {goalEvents.slice(0, 4).map((e, idx) => (
              <span
                key={`${e.minute}-${e.player}-${idx}`}
                className="inline-flex items-center gap-1 truncate max-w-full"
              >
                <span className="font-mono tabular-nums font-semibold text-emerald-400">
                  {e.minute}
                </span>
                <span className="truncate">{e.player}</span>
                <span className="font-mono text-[10px] text-slate-500">
                  ({e.team === 'home' ? match.homeShort : match.awayShort})
                </span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Footer Actions */}
      <div className="flex items-center justify-between gap-2 border-t border-[#1D2834] pt-2.5 text-xs">
        <span className="inline-flex items-center gap-1 text-slate-500 truncate">
          <MapPin className="w-3 h-3 shrink-0" aria-hidden="true" />
          <span className="truncate">{match.venue}</span>
        </span>
        <div className="flex items-center gap-1.5 shrink-0">
          {onToggleAlert && (
            <button
              type="button"
              onClick={() => onToggleAlert(match)}
              aria-pressed={isAlertSet}
              aria-label={
                isAlertSet
                  ? `Disable match alert for ${match.homeTeam} vs ${match.awayTeam}`
                  : `Set match alert for ${match.homeTeam} vs ${match.awayTeam}`
              }
              title={isAlertSet ? 'Match alert active' : 'Set match alert'}
              className={`inline-flex items-center justify-center min-h-[36px] min-w-[36px] px-2 rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                isAlertSet
                  ? 'bg-amber-500/15 border-amber-400/60 text-amber-300 hover:bg-amber-500/25'
                  : 'bg-[#18222C] border-[#24313F] text-slate-400 hover:text-amber-300 hover:border-amber-400/50'
              }`}
            >
              {isAlertSet ? (
                <BellRing className="w-3.5 h-3.5" aria-hidden="true" />
              ) : (
                <Bell className="w-3.5 h-3.5" aria-hidden="true" />
              )}
            </button>
          )}
          <button
            type="button"
            onClick={() => onOpenMatchDetail(match)}
            className="inline-flex items-center gap-1 min-h-[36px] px-2.5 py-1 rounded-lg bg-[#18222C] border border-[#24313F] text-emerald-300 font-medium hover:border-emerald-500/60 hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            <span>Match Center</span>
            <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </article>
  );
};
