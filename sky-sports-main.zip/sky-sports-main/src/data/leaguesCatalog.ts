import type { LeagueInfo, RegionId } from '../types/football';

export const REGIONS_META: { id: RegionId; label: string }[] = [
  { id: 'all', label: 'All Regions' },
  { id: 'Europe', label: 'Europe' },
  { id: 'Africa', label: 'Africa' },
  { id: 'Asia & Middle East', label: 'Asia & ME' },
  { id: 'Americas', label: 'Americas' },
  { id: 'International', label: 'International' },
];

export const LEAGUES_CATALOG: LeagueInfo[] = [
  // Featured Headline Competitions (2026/27 Continuation)
  { id: 'epl', name: 'English Premier League', shortName: 'EPL', country: 'England', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Liverpool', featuredPriority: 1, liveSupported: true },
  { id: 'ucl', name: 'UEFA Champions League', shortName: 'UCL', country: 'Europe', region: 'Europe', tier: 'Continental · 2026/27', defendingChampion: 'Paris Saint-Germain', featuredPriority: 2, liveSupported: true },
  { id: 'laliga', name: 'La Liga', shortName: 'LAL', country: 'Spain', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'FC Barcelona', featuredPriority: 3, liveSupported: true },
  { id: 'bundesliga', name: 'Bundesliga', shortName: 'BUN', country: 'Germany', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Bayern Munich', featuredPriority: 4, liveSupported: true },
  { id: 'serie-a', name: 'Serie A', shortName: 'SER', country: 'Italy', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Napoli', featuredPriority: 5, liveSupported: true },
  { id: 'roshn', name: 'Roshn Saudi League', shortName: 'RSL', country: 'Saudi Arabia', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Al-Ittihad', featuredPriority: 6, liveSupported: true },

  // African Leagues & CAF Continental (2026/27 Continuation)
  { id: 'sa-psl', name: 'Betway Premiership (PSL)', shortName: 'PSL', country: 'South Africa', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Mamelodi Sundowns', featuredPriority: 7, liveSupported: true },
  { id: 'tanzania-nbc', name: 'NBC Premier League', shortName: 'NBC', country: 'Tanzania', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Young Africans', featuredPriority: 8, liveSupported: false },
  { id: 'kenya-fkf', name: 'FKF Premier League', shortName: 'FKF', country: 'Kenya', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Kenya Police FC', featuredPriority: 9, liveSupported: true },
  { id: 'uganda-upl', name: 'Uganda Premier League', shortName: 'UPL', country: 'Uganda', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Vipers SC', featuredPriority: 10, liveSupported: true },
  { id: 'caf-cl', name: 'CAF Champions League', shortName: 'CAF', country: 'Africa', region: 'Africa', tier: 'Continental · 2026/27', defendingChampion: 'Pyramids FC', featuredPriority: 11, liveSupported: true },
  { id: 'caf-confed', name: 'CAF Confederation Cup', shortName: 'CCC', country: 'Africa', region: 'Africa', tier: 'Continental · 2026/27', defendingChampion: 'RS Berkane', featuredPriority: 12, liveSupported: true },
  { id: 'zambia-super', name: 'Zambia Super League', shortName: 'ZSL', country: 'Zambia', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Power Dynamos', featuredPriority: 13, liveSupported: true },
  { id: 'zim-psl', name: 'Zimbabwe PSL', shortName: 'ZIM', country: 'Zimbabwe', region: 'Africa', tier: '1st Tier · 2026', defendingChampion: 'Simba Bhora', featuredPriority: 14, liveSupported: true },
  { id: 'egypt-pl', name: 'Egyptian Premier League', shortName: 'EGP', country: 'Egypt', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Al Ahly', featuredPriority: 15, liveSupported: false },
  { id: 'botola-pro', name: 'Botola Pro', shortName: 'BOT', country: 'Morocco', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'RS Berkane', featuredPriority: 16, liveSupported: false },
  { id: 'algeria-l1', name: 'Algerian Ligue 1', shortName: 'ALG', country: 'Algeria', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'MC Alger', featuredPriority: 17, liveSupported: false },
  { id: 'nigeria-npfl', name: 'Nigeria NPFL', shortName: 'NPFL', country: 'Nigeria', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Remo Stars', featuredPriority: 18, liveSupported: true },
  { id: 'tunisia-l1', name: 'Tunisian Ligue 1', shortName: 'TL1', country: 'Tunisia', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Espérance Tunis', featuredPriority: 19, liveSupported: false },
  { id: 'ghana-pl', name: 'Ghana Premier League', shortName: 'GPL', country: 'Ghana', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Asante Kotoko', featuredPriority: 20, liveSupported: true },
  { id: 'rwanda-pl', name: 'Rwanda Premier League', shortName: 'RPL', country: 'Rwanda', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'APR FC', featuredPriority: 21, liveSupported: false },
  { id: 'burundi-pl', name: 'Burundi Primus League', shortName: 'BPL', country: 'Burundi', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Aigle Noir', featuredPriority: 22, liveSupported: false },
  { id: 'drc-linafoot', name: 'DR Congo Linafoot', shortName: 'DRC', country: 'DR Congo', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'TP Mazembe', featuredPriority: 23, liveSupported: false },
  { id: 'senegal-l1', name: 'Senegal Ligue 1', shortName: 'SEN', country: 'Senegal', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Teungueth FC', featuredPriority: 24, liveSupported: false },
  { id: 'cameroon-e1', name: 'Cameroon Elite One', shortName: 'CMR', country: 'Cameroon', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'Victoria United', featuredPriority: 25, liveSupported: false },
  { id: 'civ-l1', name: 'Ivory Coast Ligue 1', shortName: 'CIV', country: 'Ivory Coast', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'ASEC Mimosas', featuredPriority: 26, liveSupported: false },
  { id: 'ethiopia-pl', name: 'Ethiopian Premier League', shortName: 'ETH', country: 'Ethiopia', region: 'Africa', tier: '1st Tier · 2026/27', defendingChampion: 'CBE SA', featuredPriority: 27, liveSupported: false },

  // Rest of Europe (2026/27 Continuation)
  { id: 'ligue-1', name: 'Ligue 1', shortName: 'L1', country: 'France', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Paris Saint-Germain', featuredPriority: 28, liveSupported: true },
  { id: 'uel', name: 'UEFA Europa League', shortName: 'UEL', country: 'Europe', region: 'Europe', tier: 'Continental · 2026/27', defendingChampion: 'Tottenham', featuredPriority: 29, liveSupported: true },
  { id: 'uecl', name: 'UEFA Conference League', shortName: 'UECL', country: 'Europe', region: 'Europe', tier: 'Continental · 2026/27', defendingChampion: 'Chelsea', featuredPriority: 30, liveSupported: true },
  { id: 'championship', name: 'EFL Championship', shortName: 'EFL', country: 'England', region: 'Europe', tier: '2nd Tier · 2026/27', defendingChampion: 'Leeds United', featuredPriority: 31, liveSupported: true },
  { id: 'eredivisie', name: 'Eredivisie', shortName: 'ERE', country: 'Netherlands', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'PSV Eindhoven', featuredPriority: 32, liveSupported: true },
  { id: 'liga-portugal', name: 'Liga Portugal', shortName: 'LPT', country: 'Portugal', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Sporting CP', featuredPriority: 33, liveSupported: true },
  { id: 'scottish-prem', name: 'Scottish Premiership', shortName: 'SPL', country: 'Scotland', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Celtic', featuredPriority: 34, liveSupported: true },
  { id: 'super-lig', name: 'Süper Lig', shortName: 'SL', country: 'Turkey', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Galatasaray', featuredPriority: 35, liveSupported: true },
  { id: 'belgian-pro', name: 'Belgian Pro League', shortName: 'BPL', country: 'Belgium', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'Union SG', featuredPriority: 36, liveSupported: true },
  { id: 'swiss-super', name: 'Swiss Super League', shortName: 'SSL', country: 'Switzerland', region: 'Europe', tier: '1st Tier · 2026/27', defendingChampion: 'FC Basel', featuredPriority: 37, liveSupported: true },

  // Americas (2026 / 2026/27 Continuation)
  { id: 'mls', name: 'MLS', shortName: 'MLS', country: 'USA / Canada', region: 'Americas', tier: 'Playoffs · 2026', defendingChampion: 'LA Galaxy', featuredPriority: 38, liveSupported: true },
  { id: 'liga-mx', name: 'Liga MX', shortName: 'LMX', country: 'Mexico', region: 'Americas', tier: 'Apertura · 2026/27', defendingChampion: 'Club América', featuredPriority: 39, liveSupported: true },
  { id: 'brasileirao', name: 'Brasileirão Série A', shortName: 'BRA', country: 'Brazil', region: 'Americas', tier: '1st Tier · 2026', defendingChampion: 'Botafogo', featuredPriority: 40, liveSupported: true },
  { id: 'liga-arg', name: 'Liga Profesional', shortName: 'ARG', country: 'Argentina', region: 'Americas', tier: '1st Tier · 2026', defendingChampion: 'Vélez Sarsfield', featuredPriority: 41, liveSupported: true },
  { id: 'libertadores', name: 'Copa Libertadores', shortName: 'LIB', country: 'South America', region: 'Americas', tier: 'Finals · 2026', defendingChampion: 'Botafogo', featuredPriority: 42, liveSupported: true },
  { id: 'colombia-a', name: 'Categoría Primera A', shortName: 'COL', country: 'Colombia', region: 'Americas', tier: 'Clausura · 2026', defendingChampion: 'Atlético Nacional', featuredPriority: 43, liveSupported: true },

  // Asia & Middle East (2026/27 Continuation)
  { id: 'afc-cl', name: 'AFC Champions League Elite', shortName: 'ACLE', country: 'Asia', region: 'Asia & Middle East', tier: 'League Stage · 2026/27', defendingChampion: 'Al-Ahli', featuredPriority: 44, liveSupported: true },
  { id: 'j1-league', name: 'J1 League', shortName: 'J1', country: 'Japan', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Vissel Kobe', featuredPriority: 45, liveSupported: true },
  { id: 'k-league-1', name: 'K League 1', shortName: 'K1', country: 'South Korea', region: 'Asia & Middle East', tier: 'Final Round · 2026', defendingChampion: 'Ulsan HD', featuredPriority: 46, liveSupported: false },
  { id: 'a-league', name: 'A-League Men', shortName: 'ALM', country: 'Australia', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Melbourne City', featuredPriority: 47, liveSupported: true },
  { id: 'csl', name: 'Chinese Super League', shortName: 'CSL', country: 'China', region: 'Asia & Middle East', tier: '1st Tier · 2026', defendingChampion: 'Shanghai Port', featuredPriority: 48, liveSupported: true },
  { id: 'isl', name: 'Indian Super League', shortName: 'ISL', country: 'India', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Mohun Bagan SG', featuredPriority: 49, liveSupported: true },
  { id: 'qatar-stars', name: 'Qatar Stars League', shortName: 'QSL', country: 'Qatar', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Al-Sadd', featuredPriority: 50, liveSupported: false },
  { id: 'uae-pro', name: 'UAE Pro League', shortName: 'UAE', country: 'United Arab Emirates', region: 'Asia & Middle East', tier: '1st Tier · 2026/27', defendingChampion: 'Shabab Al Ahli', featuredPriority: 51, liveSupported: false },

  // International
  { id: 'wcq', name: 'FIFA World Cup African Qualifiers', shortName: 'WCQ', country: 'Africa / International', region: 'International', tier: '2026/27 Window', defendingChampion: 'Morocco', featuredPriority: 52, liveSupported: true },
  { id: 'nations-league', name: 'UEFA Nations League', shortName: 'UNL', country: 'International', region: 'International', tier: '2026/27', defendingChampion: 'Portugal', featuredPriority: 53, liveSupported: true },
  { id: 'afcon-q', name: 'AFCON 2027 Qualifiers & Finals', shortName: 'AFCON', country: 'Africa', region: 'International', tier: '2026/27 Window', defendingChampion: 'Ivory Coast', featuredPriority: 54, liveSupported: true },
];
