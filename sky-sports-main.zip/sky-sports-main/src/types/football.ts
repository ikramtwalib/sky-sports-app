export type AppView =
  | 'home'
  | 'matches'
  | 'tables'
  | 'africa'
  | 'teams'
  | 'players'
  | 'transfers'
  | 'news'
  | 'profile';

export type SportCategoryId =
  | 'football'
  | 'basketball'
  | 'tennis'
  | 'cricket'
  | 'volleyball'
  | 'rugby'
  | 'baseball'
  | 'hockey';

export type RegionId =
  | 'all'
  | 'Europe'
  | 'Americas'
  | 'Asia & Middle East'
  | 'Africa'
  | 'International';

export type DataSourceMode = 'live';

export type MatchStatus = 'live' | 'upcoming' | 'result';

export type MatchEventType = 'goal' | 'assist' | 'yellow' | 'red' | 'sub';

export interface MatchEvent {
  minute: string;
  team: 'home' | 'away';
  type: MatchEventType;
  player: string;
  detail?: string;
}

export interface MatchStats {
  statsAvailable?: boolean;
  possessionHome: number | null;
  possessionAway: number | null;
  shotsHome: number | null;
  shotsAway: number | null;
  shotsOnTargetHome: number | null;
  shotsOnTargetAway: number | null;
  cornersHome: number | null;
  cornersAway: number | null;
  xgHome: number | null;
  xgAway: number | null;
}

export interface HeadToHeadMatch {
  id: string;
  dateLabel: string;
  competition: string;
  homeTeam: string;
  awayTeam: string;
  homeShort: string;
  awayShort: string;
  homeLogo?: string;
  awayLogo?: string;
  homeScore: number | null;
  awayScore: number | null;
  winnerSide?: 'home' | 'away' | 'draw';
}

export interface HeadToHeadSummary {
  title: string;
  summaryText: string;
  matches: HeadToHeadMatch[];
}

export interface FootballMatch {
  id: string;
  leagueId: string;
  league: string;
  country: string;
  region: Exclude<RegionId, 'all'>;
  round: string;
  status: MatchStatus;
  timeLabel: string; // e.g. "Live · 64'", "Sat · 20:30 EAT", "FT · Nov 16"
  venue: string;
  homeTeamId: string;
  awayTeamId: string;
  homeExternalTeamId?: string;
  awayExternalTeamId?: string;
  homeTeam: string;
  awayTeam: string;
  homeShort: string;
  awayShort: string;
  homeColor: string;
  awayColor: string;
  homeLogo?: string;
  awayLogo?: string;
  homeScore?: number;
  awayScore?: number;
  kickoffIso?: string;
  source?: DataSourceMode;
  externalEventId?: string;
  featured?: boolean;
  heroImage?: string;
  events: MatchEvent[];
  stats: MatchStats;
  homeLineup: string[];
  awayLineup: string[];
  headToHead?: HeadToHeadSummary;
}

export interface MultiSportEvent {
  id: string;
  sport: SportCategoryId;
  league: string;
  status: MatchStatus;
  timeLabel: string;
  kickoffIso?: string;
  venue: string;
  homeTeam: string;
  awayTeam: string;
  homeShort: string;
  awayShort: string;
  homeLogo?: string;
  awayLogo?: string;
  homeScore?: string;
  awayScore?: string;
  detailNote?: string;
}

export interface MultiSportApiResponse {
  ok: boolean;
  sport: SportCategoryId;
  available: boolean;
  provider: string;
  timezone: string;
  fetchedAt: string;
  events: MultiSportEvent[];
  reason?: string;
}

export interface LeagueInfo {
  id: string;
  name: string;
  shortName: string;
  country: string;
  region: Exclude<RegionId, 'all'>;
  tier: string;
  defendingChampion: string;
  featuredPriority: number;
  logoUrl?: string;
  liveSupported?: boolean;
}

export interface StandingRow {
  pos: number;
  teamId: string;
  externalTeamId?: string;
  teamName: string;
  shortName: string;
  color: string;
  logoUrl?: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  gd: number;
  pts: number;
  form: ('W' | 'D' | 'L')[];
  zone?: 'champions' | 'continental' | 'relegation';
  source?: DataSourceMode;
}

export interface TeamProfile {
  id: string;
  externalTeamId?: string;
  name: string;
  shortName: string;
  country: string;
  leagueId: string;
  leagueName: string;
  region: Exclude<RegionId, 'all'>;
  stadium: string;
  capacity: string;
  manager: string;
  founded: number | null;
  primaryColor: string;
  secondaryColor: string;
  logoUrl?: string;
  standingSummary?: string;
  recordSummary?: string;
  leaguePosition: number | null;
  form: ('W' | 'D' | 'L')[];
  summary: string;
  source?: DataSourceMode;
}

export type PlayerPosition = 'FW' | 'MF' | 'DF' | 'GK';

export interface PlayerStat {
  id: string;
  externalPlayerId?: string;
  name: string;
  teamId: string;
  externalTeamId?: string;
  teamName: string;
  teamShort: string;
  teamColor: string;
  clubLogoUrl?: string;
  headshotUrl?: string;
  jersey?: string;
  leagueId: string;
  leagueName: string;
  nationality: string;
  position: PlayerPosition | 'N/A';
  age: number | null;
  appearances: number;
  minutes: number | null;
  goals: number;
  assists: number;
  shotsOnTarget: number;
  totalShots?: number;
  passAccuracy: number | null;
  cleanSheets: number | null;
  saves?: number | null;
  yellowCards: number;
  redCards?: number;
  rating: number | null;
  marketValue?: string | null;
  previousClubs?: string[];
  externalUrl?: string;
}

export type NewsCategory =
  | 'Breaking'
  | 'Transfer'
  | 'Match Update'
  | 'UCL'
  | 'Roshn'
  | 'Serie A'
  | 'International'
  | 'Africa'
  | 'Tanzania'
  | 'Injury'
  | 'Manager';

export type TransferDealClassification = 'Confirmed' | 'Loan' | 'Rumour' | 'Report';

export interface NewsHeadline {
  id: string;
  category: NewsCategory;
  timeAgo: string;
  publishedIso?: string;
  publishedEatLabel?: string;
  title: string;
  summary: string;
  leagueName: string;
  region?: Exclude<RegionId, 'all'>;
  imageUrl?: string;
  sourceName?: string;
  transferStatus?: TransferDealClassification;
  relatedMatchId?: string;
  relatedTeamId?: string;
  externalUrl?: string;
  source?: DataSourceMode;
}

export interface UserProfileData {
  uid: string;
  displayName: string;
  username: string;
  email: string;
  favoriteLeague: string;
  favoriteTeam: string;
  bio: string;
  followedTeams: string[];
  alertsEnabled: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface MatchAlertItem {
  matchId: string;
  notifyKickoff: boolean;
  notifyGoals: boolean;
  notifyFullTime: boolean;
  createdAt: string;
}

export type TransferStatus = 'Confirmed' | 'Agreed' | 'Loan' | 'Rumour';

export interface TransferItem {
  id: string;
  playerName: string;
  position: PlayerPosition;
  age: number;
  nationality: string;
  fromTeamId: string;
  fromTeamName: string;
  fromShort: string;
  fromColor: string;
  toTeamId: string;
  toTeamName: string;
  toShort: string;
  toColor: string;
  region: Exclude<RegionId, 'all'>;
  leagueName: string;
  fee: string;
  contractTerm: string;
  status: TransferStatus;
  dayGroup: 'Today · Nov 17' | 'Today · Nov 16' | 'Yesterday · Nov 16' | 'Yesterday · Nov 15' | 'Nov 15' | 'Nov 14' | 'Nov 13';
  updatedAtLabel: string;
  summary: string;
}

export interface PlayerComparisonMetric {
  label: string;
  key: string;
  valueA: number | null;
  valueB: number | null;
  displayA: string;
  displayB: string;
  winner: 'A' | 'B' | 'tie' | 'unavailable';
}

export interface LeagueLeaderItem {
  leagueId: string;
  leagueLabel: string;
  roundLabel: string;
  resumeDateLabel: string;
  leaderId: string;
  leaderExternalTeamId?: string;
  leaderName: string;
  leaderShort: string;
  leaderColor: string;
  leaderLogo?: string;
  ptsLabel: string;
  source: DataSourceMode;
}

export interface OverviewApiResponse {
  ok: boolean;
  provider: string;
  timezone: string;
  fetchedAt: string;
  matches: FootballMatch[];
  headlines: NewsHeadline[];
  leaders: LeagueLeaderItem[];
  teams: TeamProfile[];
  completedLeagues?: string[];
  warnings?: string[];
}

export interface StandingsApiResponse {
  ok: boolean;
  available: boolean;
  leagueId: string;
  provider: string;
  fetchedAt: string;
  standings: StandingRow[];
  calculatedFromResults?: boolean;
  reason?: string;
}

export interface LeagueStatsApiResponse {
  ok: boolean;
  available: boolean;
  leagueId: string;
  provider: string;
  fetchedAt: string;
  topScorers: PlayerStat[];
  topAssists: PlayerStat[];
  mostAppearances: PlayerStat[];
  cleanSheetsAvailable: boolean;
  marketValuesAvailable: boolean;
  reason?: string;
}

export interface PlayersApiResponse {
  ok: boolean;
  available: boolean;
  provider: string;
  fetchedAt: string;
  players: PlayerStat[];
  reason?: string;
}

export interface TeamDetailApiResponse {
  ok: boolean;
  available: boolean;
  provider: string;
  fetchedAt: string;
  team: TeamProfile | null;
  squad: PlayerStat[];
  matches: FootballMatch[];
  reason?: string;
}

export interface TransfersApiResponse {
  ok: boolean;
  available: boolean;
  provider: string;
  timezone: string;
  fetchedAt: string;
  stories: NewsHeadline[];
  reason?: string;
}

export interface NewsApiResponse {
  ok: boolean;
  available: boolean;
  provider: string;
  timezone: string;
  fetchedAt: string;
  articles: NewsHeadline[];
  reason?: string;
}
