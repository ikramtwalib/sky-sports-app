import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildComparisonRadarData,
  buildPlayerComparison,
  detectMatchAlertNotifications,
  filterAndSortPlayers,
  filterMatches,
  filterTransfers,
  formatMatchAlertMessage,
  formatTanzaniaClock,
  getTransferSummary,
  sanitizeProfilePayload,
  searchTeamsAndCompetitions,
  sortStandings,
  toggleMatchAlert,
  updateMatchAlertPreferences,
  validateUserProfileInput,
} from './footballUtils';
import type {
  FootballMatch,
  LeagueInfo,
  PlayerStat,
  StandingRow,
  TeamProfile,
  TransferItem,
} from '../types/football';

const SAMPLE_MATCHES: FootballMatch[] = [
  {
    id: 'm1',
    leagueId: 'epl',
    league: 'English Premier League',
    country: 'England',
    region: 'Europe',
    round: 'Matchweek 12',
    status: 'live',
    timeLabel: "Live · 64'",
    venue: 'Emirates Stadium',
    homeTeamId: 'arsenal',
    awayTeamId: 'chelsea',
    homeTeam: 'Arsenal',
    awayTeam: 'Chelsea',
    homeShort: 'ARS',
    awayShort: 'CHE',
    homeColor: '#EF0107',
    awayColor: '#034694',
    homeScore: 2,
    awayScore: 1,
    events: [
      { minute: "18'", team: 'home', type: 'goal', player: 'Bukayo Saka', detail: 'Goal' },
    ],
    stats: {
      statsAvailable: true,
      possessionHome: 57,
      possessionAway: 43,
      shotsHome: 14,
      shotsAway: 9,
      shotsOnTargetHome: 6,
      shotsOnTargetAway: 3,
      cornersHome: 7,
      cornersAway: 4,
      xgHome: 2.1,
      xgAway: 1.0,
    },
    homeLineup: [],
    awayLineup: [],
  },
  {
    id: 'm2',
    leagueId: 'roshn',
    league: 'Roshn Saudi League',
    country: 'Saudi Arabia',
    region: 'Asia & Middle East',
    round: 'Matchweek 11',
    status: 'upcoming',
    timeLabel: 'Fri · 18:00',
    venue: 'Kingdom Arena',
    homeTeamId: 'al-hilal',
    awayTeamId: 'al-nassr',
    homeTeam: 'Al-Hilal',
    awayTeam: 'Al-Nassr',
    homeShort: 'HIL',
    awayShort: 'NAS',
    homeColor: '#0055B8',
    awayColor: '#F5C400',
    events: [],
    stats: {
      statsAvailable: false,
      possessionHome: null,
      possessionAway: null,
      shotsHome: null,
      shotsAway: null,
      shotsOnTargetHome: null,
      shotsOnTargetAway: null,
      cornersHome: null,
      cornersAway: null,
      xgHome: null,
      xgAway: null,
    },
    homeLineup: [],
    awayLineup: [],
  },
  {
    id: 'm3',
    leagueId: 'laliga',
    league: 'La Liga',
    country: 'Spain',
    region: 'Europe',
    round: 'Matchday 13',
    status: 'result',
    timeLabel: 'FT',
    venue: 'Santiago Bernabéu',
    homeTeamId: 'real-madrid',
    awayTeamId: 'barcelona',
    homeTeam: 'Real Madrid',
    awayTeam: 'FC Barcelona',
    homeShort: 'RMA',
    awayShort: 'BAR',
    homeColor: '#FEBE10',
    awayColor: '#A50044',
    homeScore: 2,
    awayScore: 3,
    events: [],
    stats: {
      statsAvailable: true,
      possessionHome: 46,
      possessionAway: 54,
      shotsHome: 12,
      shotsAway: 15,
      shotsOnTargetHome: 5,
      shotsOnTargetAway: 7,
      cornersHome: 5,
      cornersAway: 6,
      xgHome: 1.8,
      xgAway: 2.4,
    },
    homeLineup: [],
    awayLineup: [],
  },
];

test('filterMatches filters by status, region, leagueId, and query', () => {
  assert.equal(
    filterMatches(SAMPLE_MATCHES, { status: 'live', region: 'all', leagueId: null, query: '' }).length,
    1
  );
  assert.equal(
    filterMatches(SAMPLE_MATCHES, { status: 'result', region: 'all', leagueId: null, query: '' })[0]?.id,
    'm3'
  );
  assert.equal(
    filterMatches(SAMPLE_MATCHES, { status: 'all', region: 'Asia & Middle East', leagueId: null, query: '' })[0]?.leagueId,
    'roshn'
  );
  assert.equal(
    filterMatches(SAMPLE_MATCHES, { status: 'all', region: 'all', leagueId: 'laliga', query: 'bernabeu' }).length,
    1
  );
});

test('sortStandings orders by points, goal difference, goals for, and updates pos', () => {
  const rows: StandingRow[] = [
    { pos: 0, teamId: 'a', teamName: 'Alpha FC', shortName: 'ALP', color: '#111', played: 10, won: 6, drawn: 2, lost: 2, gf: 18, ga: 10, gd: 8, pts: 20, form: ['W'] },
    { pos: 0, teamId: 'b', teamName: 'Beta United', shortName: 'BET', color: '#222', played: 10, won: 6, drawn: 2, lost: 2, gf: 22, ga: 10, gd: 12, pts: 20, form: ['W'] },
    { pos: 0, teamId: 'c', teamName: 'Gamma City', shortName: 'GAM', color: '#333', played: 10, won: 7, drawn: 2, lost: 1, gf: 24, ga: 8, gd: 16, pts: 23, form: ['W'] },
  ];
  const sorted = sortStandings(rows);
  assert.deepEqual(
    sorted.map((r) => [r.pos, r.teamId]),
    [
      [1, 'c'],
      [2, 'b'],
      [3, 'a'],
    ]
  );
});

test('filterAndSortPlayers sorts by chosen metric and filters by position/league', () => {
  const players: PlayerStat[] = [
    { id: 'p1', name: 'Player One', teamId: 't1', teamName: 'Arsenal', teamShort: 'ARS', teamColor: '#EF0107', leagueId: 'epl', leagueName: 'Premier League', nationality: 'England', position: 'FW', age: 23, appearances: 11, minutes: 940, goals: 6, assists: 8, shotsOnTarget: 18, passAccuracy: 85, cleanSheets: 0, yellowCards: 2, rating: 7.9 },
    { id: 'p2', name: 'Player Two', teamId: 't2', teamName: 'Liverpool', teamShort: 'LIV', teamColor: '#C8102E', leagueId: 'epl', leagueName: 'Premier League', nationality: 'Egypt', position: 'FW', age: 32, appearances: 11, minutes: 970, goals: 10, assists: 6, shotsOnTarget: 23, passAccuracy: 82, cleanSheets: 0, yellowCards: 1, rating: 8.3 },
    { id: 'p3', name: 'Player Three', teamId: 't3', teamName: 'Al-Hilal', teamShort: 'HIL', teamColor: '#0055B8', leagueId: 'roshn', leagueName: 'Roshn Saudi League', nationality: 'Serbia', position: 'FW', age: 30, appearances: 10, minutes: 890, goals: 11, assists: 2, shotsOnTarget: 20, passAccuracy: 77, cleanSheets: 0, yellowCards: 2, rating: 8.1 },
  ];

  const byAssists = filterAndSortPlayers(players, { leagueId: 'epl', position: 'FW', query: '', sortBy: 'assists' });
  assert.equal(byAssists[0]?.id, 'p1');

  const byGoals = filterAndSortPlayers(players, { leagueId: 'all', position: 'all', query: 'al-hilal', sortBy: 'goals' });
  assert.equal(byGoals.length, 1);
  assert.equal(byGoals[0]?.id, 'p3');
});

test('searchTeamsAndCompetitions matches teams and leagues cleanly', () => {
  const teams: TeamProfile[] = [
    { id: 'al-hilal', name: 'Al-Hilal', shortName: 'HIL', country: 'Saudi Arabia', leagueId: 'roshn', leagueName: 'Roshn Saudi League', region: 'Asia & Middle East', stadium: 'Kingdom Arena', capacity: '30,000', manager: 'Jorge Jesus', founded: 1957, primaryColor: '#0055B8', secondaryColor: '#FFFFFF', leaguePosition: 1, form: ['W'], summary: '' },
  ];
  const leagues: LeagueInfo[] = [
    { id: 'roshn', name: 'Roshn Saudi League', shortName: 'RSL', country: 'Saudi Arabia', region: 'Asia & Middle East', tier: '1st Tier', defendingChampion: 'Al-Hilal', featuredPriority: 5 },
  ];
  const res = searchTeamsAndCompetitions({ teams, leagues, query: 'roshn' });
  assert.equal(res.teams.length, 1);
  assert.equal(res.leagues.length, 1);
});

test('validateUserProfileInput and sanitizeProfilePayload enforce blueprint rules', () => {
  const invalid = validateUserProfileInput({
    displayName: 'A',
    username: 'Bad Handle!',
    favoriteLeague: '',
    favoriteTeam: 'Arsenal',
    bio: 'x'.repeat(245),
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.displayName);
  assert.ok(invalid.errors.username);
  assert.ok(invalid.errors.favoriteLeague);
  assert.ok(invalid.errors.bio);

  const valid = validateUserProfileInput({
    displayName: 'Ikram Twalib',
    username: 'ikram_fc24',
    favoriteLeague: 'English Premier League',
    favoriteTeam: 'Arsenal',
    bio: 'Following Premier League, UCL & Roshn Saudi League.',
  });
  assert.equal(valid.valid, true);

  const sanitized = sanitizeProfilePayload({
    email: ' fan@example.com ',
    displayName: ' Ikram ',
    username: 'Ikram_FC!!',
    favoriteLeague: 'Premier League',
    favoriteTeam: 'Arsenal',
    bio: ' Supporter ',
    followedTeams: new Array(15).fill('arsenal'),
    alertsEnabled: true,
  });
  assert.equal(sanitized.username, 'ikram_fc');
  assert.equal(sanitized.followedTeams.length, 12);
});

test('match alert helpers toggle, update preferences, and format alert headlines', () => {
  const first = toggleMatchAlert([], 'm1');
  assert.equal(first.added, true);
  assert.equal(first.nextAlerts.length, 1);
  assert.equal(first.nextAlerts[0]?.notifyGoals, true);

  const updated = updateMatchAlertPreferences(first.nextAlerts, 'm1', { notifyKickoff: false });
  assert.equal(updated[0]?.notifyKickoff, false);
  assert.equal(updated[0]?.notifyGoals, true);

  const removed = toggleMatchAlert(updated, 'm1');
  assert.equal(removed.added, false);
  assert.equal(removed.nextAlerts.length, 0);

  const liveMsg = formatMatchAlertMessage(SAMPLE_MATCHES[0]);
  assert.ok(liveMsg.includes('Arsenal 2–1 Chelsea'));

  const upcomingMsg = formatMatchAlertMessage(SAMPLE_MATCHES[1]);
  assert.ok(upcomingMsg.includes('Al-Hilal vs Al-Nassr'));
});

test('buildPlayerComparison and buildComparisonRadarData compute accurate head-to-head metrics', () => {
  const playerA: PlayerStat = {
    id: 'p1',
    name: 'Mohamed Salah',
    teamId: 'liverpool',
    teamName: 'Liverpool',
    teamShort: 'LIV',
    teamColor: '#C8102E',
    leagueId: 'epl',
    leagueName: 'English Premier League',
    nationality: 'Egypt',
    position: 'FW',
    age: 34,
    appearances: 12,
    minutes: 1080,
    goals: 11,
    assists: 7,
    shotsOnTarget: 25,
    passAccuracy: 81,
    cleanSheets: 0,
    yellowCards: 1,
    rating: 8.32,
  };
  const playerB: PlayerStat = {
    id: 'p2',
    name: 'Kylian Mbappé',
    teamId: 'real-madrid',
    teamName: 'Real Madrid',
    teamShort: 'RMA',
    teamColor: '#FEBE10',
    leagueId: 'laliga',
    leagueName: 'La Liga',
    nationality: 'France',
    position: 'FW',
    age: 27,
    appearances: 12,
    minutes: 900,
    goals: 9,
    assists: 3,
    shotsOnTarget: 27,
    passAccuracy: 84,
    cleanSheets: 0,
    yellowCards: 2,
    rating: 8.05,
  };

  const metrics = buildPlayerComparison(playerA, playerB);
  const goalsRow = metrics.find((m) => m.key === 'goals');
  const gaRow = metrics.find((m) => m.key === 'ga');
  const cardsRow = metrics.find((m) => m.key === 'yellowCards');
  const shotsRow = metrics.find((m) => m.key === 'shotsOnTarget');

  assert.equal(goalsRow?.winner, 'A');
  assert.equal(gaRow?.displayA, '18');
  assert.equal(gaRow?.displayB, '12');
  assert.equal(shotsRow?.winner, 'B');
  assert.equal(cardsRow?.winner, 'A');

  const radar = buildComparisonRadarData(playerA, playerB);
  assert.equal(radar.length, 6);
  assert.ok(radar.every((r) => r.A >= 0 && r.A <= 100 && r.B >= 0 && r.B <= 100));
});

test('filterTransfers and getTransferSummary filter daily updates cleanly', () => {
  const sampleTransfers: TransferItem[] = [
    {
      id: 'tr-1',
      playerName: 'Feisal Salum',
      position: 'MF',
      age: 28,
      nationality: 'Tanzania',
      fromTeamId: 'azam',
      fromTeamName: 'Azam FC',
      fromShort: 'AZA',
      fromColor: '#0055A5',
      toTeamId: 'sundowns',
      toTeamName: 'Mamelodi Sundowns',
      toShort: 'SUN',
      toColor: '#F5C400',
      region: 'Africa',
      leagueName: 'Betway Premiership',
      fee: '$1.4M',
      contractTerm: '3-Year Deal',
      status: 'Agreed',
      dayGroup: 'Today · Nov 17',
      updatedAtLabel: 'Today · 09:40',
      summary: 'Midfield agreement ahead of January window.',
    },
    {
      id: 'tr-2',
      playerName: 'Viktor Gyökeres',
      position: 'FW',
      age: 28,
      nationality: 'Sweden',
      fromTeamId: 'sporting-cp',
      fromTeamName: 'Sporting CP',
      fromShort: 'SCP',
      fromColor: '#008057',
      toTeamId: 'arsenal',
      toTeamName: 'Arsenal',
      toShort: 'ARS',
      toColor: '#EF0107',
      region: 'Europe',
      leagueName: 'English Premier League',
      fee: '€85M',
      contractTerm: 'Pre-Contract Talks',
      status: 'Rumour',
      dayGroup: 'Yesterday · Nov 16',
      updatedAtLabel: 'Yesterday · 18:10',
      summary: 'Premier League scouts tracking progress.',
    },
  ];

  const todayAfrica = filterTransfers(sampleTransfers, {
    dayGroup: 'Today · Nov 17',
    status: 'all',
    region: 'Africa',
    query: 'azam',
  });
  assert.equal(todayAfrica.length, 1);
  assert.equal(todayAfrica[0]?.id, 'tr-1');

  const summary = getTransferSummary(sampleTransfers);
  assert.equal(summary.totalCount, 2);
  assert.equal(summary.todayCount, 1);
  assert.equal(summary.africaCount, 1);
  assert.equal(summary.confirmedCount, 0);
});

test('formatTanzaniaClock converts ISO timestamps to EAT (UTC+3)', () => {
  assert.equal(formatTanzaniaClock('2026-11-17T15:05:09Z'), '18:05:09 EAT');
  assert.equal(formatTanzaniaClock('not-a-date'), null);
});

test('buildPlayerComparison handles nullable API fields as unavailable instead of fake numbers', () => {
  const apiPlayerA: PlayerStat = {
    id: 'epl-1',
    name: 'Bukayo Saka',
    teamId: 'epl-359',
    teamName: 'Arsenal',
    teamShort: 'ARS',
    teamColor: '#EF0107',
    leagueId: 'epl',
    leagueName: 'English Premier League',
    nationality: 'England',
    position: 'N/A',
    age: null,
    appearances: 11,
    minutes: null,
    goals: 7,
    assists: 8,
    shotsOnTarget: 0,
    passAccuracy: null,
    cleanSheets: null,
    yellowCards: 0,
    rating: null,
  };
  const apiPlayerB: PlayerStat = {
    ...apiPlayerA,
    id: 'epl-2',
    name: 'Cole Palmer',
    goals: 9,
    assists: 5,
  };

  const metrics = buildPlayerComparison(apiPlayerA, apiPlayerB);
  const ratingRow = metrics.find((m) => m.key === 'rating');
  const g90Row = metrics.find((m) => m.key === 'g90');
  const goalsRow = metrics.find((m) => m.key === 'goals');

  assert.equal(ratingRow?.winner, 'unavailable');
  assert.equal(ratingRow?.displayA, 'N/A');
  assert.equal(g90Row?.winner, 'unavailable');
  assert.equal(goalsRow?.winner, 'B');
});

test('detectMatchAlertNotifications fires on kickoff, goal+scorer, and full-time transitions', () => {
  const alerts = [
    { matchId: 'm1', notifyKickoff: true, notifyGoals: true, notifyFullTime: true, createdAt: '2026-11-17T00:00:00Z' },
    { matchId: 'm2', notifyKickoff: true, notifyGoals: true, notifyFullTime: true, createdAt: '2026-11-17T00:00:00Z' },
  ];

  // Goal scored in m1 + Kickoff started in m2
  const nextMatches: FootballMatch[] = [
    {
      ...SAMPLE_MATCHES[0]!,
      homeScore: 3,
      timeLabel: "Live · 74'",
      events: [
        ...SAMPLE_MATCHES[0]!.events,
        { minute: "74'", team: 'home', type: 'goal', player: 'Viktor Gyökeres', detail: 'Goal' },
      ],
    },
    {
      ...SAMPLE_MATCHES[1]!,
      status: 'live',
      timeLabel: "Live · 1'",
      homeScore: 0,
      awayScore: 0,
    },
  ];

  const triggered = detectMatchAlertNotifications(SAMPLE_MATCHES, nextMatches, alerts);
  assert.equal(triggered.length, 2);
  assert.equal(triggered[0]?.eventKind, 'goal');
  assert.ok(triggered[0]?.headline.includes('Viktor Gyökeres'));
  assert.equal(triggered[1]?.eventKind, 'kickoff');

  // Full-time transition in m1
  const fullTimeMatches: FootballMatch[] = [
    {
      ...nextMatches[0]!,
      status: 'result',
      timeLabel: 'FT · Nov 17',
    },
    nextMatches[1]!,
  ];
  const ftTriggered = detectMatchAlertNotifications(nextMatches, fullTimeMatches, alerts);
  assert.equal(ftTriggered.length, 1);
  assert.equal(ftTriggered[0]?.eventKind, 'fulltime');
  assert.ok(ftTriggered[0]?.headline.includes('FULL-TIME'));
});

test('EAT date helpers classify Today, Tomorrow, and Yesterday correctly in Africa/Dar_es_Salaam', async () => {
  const { classifyMatchTimeBucket, formatEatDateHeading, getEatDateKey } = await import('./footballUtils');
  // 2026-11-18T10:00:00Z = 13:00 EAT on Nov 18
  const refMs = Date.parse('2026-11-18T10:00:00Z');
  assert.equal(getEatDateKey(refMs), '2026-11-18');
  // 2026-11-17T22:30:00Z = 01:30 EAT on Nov 18 (Today in Tanzania!)
  assert.equal(getEatDateKey('2026-11-17T22:30:00Z'), '2026-11-18');

  const todayUpcoming: FootballMatch = {
    ...SAMPLE_MATCHES[1]!,
    kickoffIso: '2026-11-18T17:00:00Z',
  };
  const tomorrowUpcoming: FootballMatch = {
    ...SAMPLE_MATCHES[1]!,
    kickoffIso: '2026-11-19T14:00:00Z',
  };
  const yesterdayResult: FootballMatch = {
    ...SAMPLE_MATCHES[2]!,
    kickoffIso: '2026-11-17T18:00:00Z',
  };

  assert.equal(classifyMatchTimeBucket(SAMPLE_MATCHES[0]!, refMs), 'live');
  assert.equal(classifyMatchTimeBucket(todayUpcoming, refMs), 'today');
  assert.equal(classifyMatchTimeBucket(tomorrowUpcoming, refMs), 'tomorrow');
  assert.equal(classifyMatchTimeBucket(yesterdayResult, refMs), 'yesterday');
  assert.ok(formatEatDateHeading('2026-11-17T18:00:00Z', refMs).startsWith('Yesterday · '));
  assert.ok(formatEatDateHeading('2026-11-19T14:00:00Z', refMs).startsWith('Tomorrow · '));
});

