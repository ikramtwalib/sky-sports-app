import type {
  FootballMatch,
  LeagueInfo,
  MatchAlertItem,
  MatchStatus,
  PlayerComparisonMetric,
  PlayerPosition,
  PlayerStat,
  RegionId,
  StandingRow,
  TeamProfile,
  TransferItem,
  TransferStatus,
} from '../types/football';

function normalizeText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

export interface MatchFilterOptions {
  status: 'all' | MatchStatus;
  region: RegionId;
  leagueId: string | null;
  query: string;
}

export function filterMatches(
  matches: FootballMatch[],
  options: MatchFilterOptions
): FootballMatch[] {
  const q = normalizeText(options.query.trim());
  return matches.filter((match) => {
    if (options.status !== 'all' && match.status !== options.status) return false;
    if (options.region !== 'all' && match.region !== options.region) return false;
    if (options.leagueId && match.leagueId !== options.leagueId) return false;
    if (q) {
      const haystack = normalizeText(
        `${match.homeTeam} ${match.awayTeam} ${match.homeShort} ${match.awayShort} ${match.league} ${match.country} ${match.region} ${match.venue}`
      );
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
}

export const TANZANIA_TIMEZONE = 'Africa/Dar_es_Salaam';

export function formatTanzaniaClock(isoDate: string): string | null {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return null;
  const formatted = parsed.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: TANZANIA_TIMEZONE,
  });
  return `${formatted} EAT`;
}

export function getEatDateKey(isoOrMs: string | number): string | null {
  const parsed = new Date(isoOrMs);
  if (Number.isNaN(parsed.getTime())) return null;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: TANZANIA_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(parsed);
  const year = parts.find((p) => p.type === 'year')?.value;
  const month = parts.find((p) => p.type === 'month')?.value;
  const day = parts.find((p) => p.type === 'day')?.value;
  return year && month && day ? `${year}-${month}-${day}` : null;
}

export type MatchTimeBucket = 'live' | 'today' | 'tomorrow' | 'upcoming' | 'yesterday' | 'past';

export function classifyMatchTimeBucket(
  match: FootballMatch,
  referenceNowMs = Date.now()
): MatchTimeBucket {
  if (match.status === 'live') return 'live';

  const todayKey = getEatDateKey(referenceNowMs);
  const tomorrowKey = getEatDateKey(referenceNowMs + 24 * 60 * 60 * 1000);
  const yesterdayKey = getEatDateKey(referenceNowMs - 24 * 60 * 60 * 1000);
  const matchKey = match.kickoffIso ? getEatDateKey(match.kickoffIso) : null;

  if (match.status === 'result') {
    if (matchKey && yesterdayKey && matchKey === yesterdayKey) return 'yesterday';
    if (matchKey && todayKey && matchKey === todayKey) return 'today';
    return 'past';
  }

  // upcoming
  if (matchKey && todayKey && matchKey === todayKey) return 'today';
  if (matchKey && tomorrowKey && matchKey === tomorrowKey) return 'tomorrow';
  return 'upcoming';
}

export function formatEatDateHeading(isoDate?: string, referenceNowMs = Date.now()): string {
  if (!isoDate) return 'Scheduled (EAT)';
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return 'Scheduled (EAT)';

  const matchKey = getEatDateKey(isoDate);
  const todayKey = getEatDateKey(referenceNowMs);
  const tomorrowKey = getEatDateKey(referenceNowMs + 24 * 60 * 60 * 1000);
  const yesterdayKey = getEatDateKey(referenceNowMs - 24 * 60 * 60 * 1000);

  const formattedDate = parsed.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: TANZANIA_TIMEZONE,
  });

  if (matchKey && todayKey && matchKey === todayKey) return `Today · ${formattedDate}`;
  if (matchKey && tomorrowKey && matchKey === tomorrowKey) return `Tomorrow · ${formattedDate}`;
  if (matchKey && yesterdayKey && matchKey === yesterdayKey) return `Yesterday · ${formattedDate}`;
  return formattedDate;
}

export function sortStandings(rows: StandingRow[]): StandingRow[] {
  return [...rows]
    .sort((a, b) => {
      if (b.pts !== a.pts) return b.pts - a.pts;
      if (b.gd !== a.gd) return b.gd - a.gd;
      if (b.gf !== a.gf) return b.gf - a.gf;
      return a.teamName.localeCompare(b.teamName);
    })
    .map((row, idx) => ({ ...row, pos: idx + 1 }));
}

export type PlayerSortKey = 'goals' | 'assists' | 'rating' | 'appearances' | 'minutes';

export function filterAndSortPlayers(
  players: PlayerStat[],
  options: {
    leagueId: string;
    position: 'all' | PlayerPosition;
    query: string;
    sortBy: PlayerSortKey;
  }
): PlayerStat[] {
  const q = normalizeText(options.query.trim());
  const num = (val: number | null | undefined) => (typeof val === 'number' ? val : -1);

  return players
    .filter((player) => {
      if (options.leagueId !== 'all' && player.leagueId !== options.leagueId) return false;
      if (options.position !== 'all' && player.position !== options.position) return false;
      if (q) {
        const hay = normalizeText(
          `${player.name} ${player.teamName} ${player.leagueName} ${player.nationality}`
        );
        if (!hay.includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      const diff = num(b[options.sortBy]) - num(a[options.sortBy]);
      if (diff !== 0) return diff;
      if (b.goals !== a.goals) return b.goals - a.goals;
      if (b.assists !== a.assists) return b.assists - a.assists;
      return num(b.rating) - num(a.rating);
    });
}

export function searchTeamsAndCompetitions(params: {
  teams: TeamProfile[];
  leagues: LeagueInfo[];
  query: string;
}): { teams: TeamProfile[]; leagues: LeagueInfo[] } {
  const q = normalizeText(params.query.trim());
  if (!q) {
    return {
      teams: params.teams,
      leagues: params.leagues,
    };
  }
  return {
    teams: params.teams.filter((t) =>
      normalizeText(
        `${t.name} ${t.shortName} ${t.leagueName} ${t.country} ${t.manager} ${t.stadium}`
      ).includes(q)
    ),
    leagues: params.leagues.filter((l) =>
      normalizeText(`${l.name} ${l.shortName} ${l.country} ${l.region}`).includes(q)
    ),
  };
}

export interface ProfileValidationResult {
  valid: boolean;
  errors: Partial<Record<'displayName' | 'username' | 'favoriteLeague' | 'favoriteTeam' | 'bio', string>>;
}

const USERNAME_PATTERN = /^[a-z0-9_]+$/;

export function validateUserProfileInput(input: {
  displayName: string;
  username: string;
  favoriteLeague: string;
  favoriteTeam: string;
  bio: string;
}): ProfileValidationResult {
  const errors: ProfileValidationResult['errors'] = {};
  const displayName = input.displayName.trim();
  const username = input.username.trim().toLowerCase();
  const favoriteLeague = input.favoriteLeague.trim();
  const favoriteTeam = input.favoriteTeam.trim();
  const bio = input.bio.trim();

  if (displayName.length < 2 || displayName.length > 60) {
    errors.displayName = 'Display name must be between 2 and 60 characters.';
  }
  if (username.length < 3 || username.length > 24 || !USERNAME_PATTERN.test(username)) {
    errors.username = 'Username must be 3–24 characters using lowercase letters, numbers, or underscores.';
  }
  if (favoriteLeague.length < 2 || favoriteLeague.length > 80) {
    errors.favoriteLeague = 'Please select a favorite competition.';
  }
  if (favoriteTeam.length < 2 || favoriteTeam.length > 80) {
    errors.favoriteTeam = 'Please select a favorite football club.';
  }
  if (bio.length > 240) {
    errors.bio = 'Supporter bio must be 240 characters or fewer.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function sanitizeProfilePayload(input: {
  email: string;
  displayName: string;
  username: string;
  favoriteLeague: string;
  favoriteTeam: string;
  bio: string;
  followedTeams: string[];
  alertsEnabled: boolean;
}) {
  return {
    email: input.email.trim().slice(0, 160),
    displayName: input.displayName.trim().slice(0, 60),
    username: input.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 24),
    favoriteLeague: input.favoriteLeague.trim().slice(0, 80),
    favoriteTeam: input.favoriteTeam.trim().slice(0, 80),
    bio: input.bio.trim().slice(0, 240),
    followedTeams: input.followedTeams
      .map((t) => t.trim().slice(0, 40))
      .filter((t) => t.length > 0)
      .slice(0, 12),
    alertsEnabled: Boolean(input.alertsEnabled),
  };
}

export function createDefaultMatchAlert(matchId: string): MatchAlertItem {
  return {
    matchId,
    notifyKickoff: true,
    notifyGoals: true,
    notifyFullTime: true,
    createdAt: new Date().toISOString(),
  };
}

export function toggleMatchAlert(
  alerts: MatchAlertItem[],
  matchId: string
): { nextAlerts: MatchAlertItem[]; added: boolean } {
  const exists = alerts.some((a) => a.matchId === matchId);
  if (exists) {
    return {
      nextAlerts: alerts.filter((a) => a.matchId !== matchId),
      added: false,
    };
  }
  return {
    nextAlerts: [createDefaultMatchAlert(matchId), ...alerts],
    added: true,
  };
}

export function updateMatchAlertPreferences(
  alerts: MatchAlertItem[],
  matchId: string,
  patch: Partial<Pick<MatchAlertItem, 'notifyKickoff' | 'notifyGoals' | 'notifyFullTime'>>
): MatchAlertItem[] {
  return alerts.map((a) => (a.matchId === matchId ? { ...a, ...patch } : a));
}

export function formatMatchAlertMessage(match: FootballMatch): string {
  if (match.status === 'live') {
    const score =
      typeof match.homeScore === 'number' && typeof match.awayScore === 'number'
        ? `${match.homeScore}–${match.awayScore}`
        : 'Live';
    const goals = match.events.filter((e) => e.type === 'goal');
    const latestGoal = goals[goals.length - 1];
    const scorerSuffix = latestGoal ? ` · Goal: ${latestGoal.player} (${latestGoal.minute})` : '';
    return `LIVE ALERT (${match.timeLabel}): ${match.homeTeam} ${score} ${match.awayTeam}${scorerSuffix} · ${match.league}`;
  }
  if (match.status === 'result') {
    return `FULL-TIME ALERT: ${match.homeTeam} ${match.homeScore ?? 0}–${match.awayScore ?? 0} ${match.awayTeam} · ${match.league}`;
  }
  return `KICKOFF ALERT SET: ${match.homeTeam} vs ${match.awayTeam} (${match.timeLabel}) · ${match.league}`;
}

export interface LiveAlertNotification {
  match: FootballMatch;
  headline: string;
  eventKind: 'kickoff' | 'goal' | 'fulltime';
}

export function detectMatchAlertNotifications(
  prevMatches: FootballMatch[],
  nextMatches: FootballMatch[],
  alerts: MatchAlertItem[]
): LiveAlertNotification[] {
  if (prevMatches.length === 0 || alerts.length === 0) return [];
  const prevMap = new Map(prevMatches.map((m) => [m.id, m]));
  const nextMap = new Map(nextMatches.map((m) => [m.id, m]));
  const notifications: LiveAlertNotification[] = [];

  for (const alert of alerts) {
    const prev = prevMap.get(alert.matchId);
    const next = nextMap.get(alert.matchId);
    if (!prev || !next) continue;

    // 1. Kickoff transition
    if (alert.notifyKickoff && prev.status === 'upcoming' && next.status === 'live') {
      notifications.push({
        match: next,
        eventKind: 'kickoff',
        headline: `KICKOFF: ${next.homeTeam} vs ${next.awayTeam} is now underway (${next.timeLabel}) · ${next.league}`,
      });
      continue;
    }

    // 2. Goal scored (score increase or new goal event during live play)
    const prevHome = prev.homeScore ?? 0;
    const prevAway = prev.awayScore ?? 0;
    const nextHome = next.homeScore ?? 0;
    const nextAway = next.awayScore ?? 0;
    const scoreChanged =
      typeof next.homeScore === 'number' &&
      typeof next.awayScore === 'number' &&
      (nextHome > prevHome || nextAway > prevAway);

    const prevGoals = prev.events.filter((e) => e.type === 'goal');
    const nextGoals = next.events.filter((e) => e.type === 'goal');
    const newGoalDetected = scoreChanged || nextGoals.length > prevGoals.length;

    if (alert.notifyGoals && next.status !== 'upcoming' && newGoalDetected) {
      const latestGoal = nextGoals[nextGoals.length - 1];
      const scorerText = latestGoal ? ` · ${latestGoal.player} (${latestGoal.minute})` : '';
      notifications.push({
        match: next,
        eventKind: 'goal',
        headline: `GOAL! ${next.homeTeam} ${nextHome}–${nextAway} ${next.awayTeam}${scorerText} · ${next.timeLabel}`,
      });
      continue;
    }

    // 3. Full-time transition
    if (alert.notifyFullTime && prev.status !== 'result' && next.status === 'result') {
      notifications.push({
        match: next,
        eventKind: 'fulltime',
        headline: `FULL-TIME: ${next.homeTeam} ${next.homeScore ?? 0}–${next.awayScore ?? 0} ${next.awayTeam} · ${next.league}`,
      });
    }
  }

  return notifications;
}

export function buildPlayerComparison(
  playerA: PlayerStat,
  playerB: PlayerStat
): PlayerComparisonMetric[] {
  const gaA = playerA.goals + playerA.assists;
  const gaB = playerB.goals + playerB.assists;
  const gAppA = playerA.appearances > 0 ? playerA.goals / playerA.appearances : 0;
  const gAppB = playerB.appearances > 0 ? playerB.goals / playerB.appearances : 0;
  const g90A =
    typeof playerA.minutes === 'number' && playerA.minutes > 0
      ? (playerA.goals * 90) / playerA.minutes
      : null;
  const g90B =
    typeof playerB.minutes === 'number' && playerB.minutes > 0
      ? (playerB.goals * 90) / playerB.minutes
      : null;

  const makeMetric = (
    key: string,
    label: string,
    valueA: number | null,
    valueB: number | null,
    formatVal: (v: number) => string,
    lowerIsBetter = false
  ): PlayerComparisonMetric => {
    const displayA = valueA === null ? 'N/A' : formatVal(valueA);
    const displayB = valueB === null ? 'N/A' : formatVal(valueB);

    if (valueA === null || valueB === null) {
      return { key, label, valueA, valueB, displayA, displayB, winner: 'unavailable' };
    }

    let winner: PlayerComparisonMetric['winner'] = 'tie';
    if (valueA !== valueB) {
      if (lowerIsBetter) {
        winner = valueA < valueB ? 'A' : 'B';
      } else {
        winner = valueA > valueB ? 'A' : 'B';
      }
    }
    return { key, label, valueA, valueB, displayA, displayB, winner };
  };

  return [
    makeMetric('goals', 'Goals Scored', playerA.goals, playerB.goals, (v) => String(v)),
    makeMetric('assists', 'Assists', playerA.assists, playerB.assists, (v) => String(v)),
    makeMetric('ga', 'Goal Contributions (G+A)', gaA, gaB, (v) => String(v)),
    makeMetric('appearances', 'Appearances', playerA.appearances, playerB.appearances, (v) => String(v)),
    makeMetric('gPerApp', 'Goals per Match', Number(gAppA.toFixed(2)), Number(gAppB.toFixed(2)), (v) => v.toFixed(2)),
    makeMetric('g90', 'Goals per 90 mins', g90A !== null ? Number(g90A.toFixed(2)) : null, g90B !== null ? Number(g90B.toFixed(2)) : null, (v) => v.toFixed(2)),
    makeMetric('shotsOnTarget', 'Shots on Target', playerA.shotsOnTarget, playerB.shotsOnTarget, (v) => String(v)),
    makeMetric('passAccuracy', 'Pass Accuracy', playerA.passAccuracy, playerB.passAccuracy, (v) => `${v}%`),
    makeMetric('rating', 'Match Rating', playerA.rating, playerB.rating, (v) => v.toFixed(2)),
    makeMetric('cleanSheets', 'Clean Sheets', playerA.cleanSheets, playerB.cleanSheets, (v) => String(v)),
    makeMetric('yellowCards', 'Yellow Cards (fewer better)', playerA.yellowCards, playerB.yellowCards, (v) => String(v), true),
  ];
}

export function buildComparisonRadarData(playerA: PlayerStat, playerB: PlayerStat) {
  const clamp = (val: number | null, max: number) =>
    typeof val === 'number' && max > 0 ? Math.min(100, Math.round((val / max) * 100)) : 0;
  const gAppA = playerA.appearances > 0 ? playerA.goals / playerA.appearances : 0;
  const gAppB = playerB.appearances > 0 ? playerB.goals / playerB.appearances : 0;

  return [
    {
      metric: 'Goals',
      A: clamp(playerA.goals, 16),
      B: clamp(playerB.goals, 16),
    },
    {
      metric: 'Assists',
      A: clamp(playerA.assists, 12),
      B: clamp(playerB.assists, 12),
    },
    {
      metric: 'G + A',
      A: clamp(playerA.goals + playerA.assists, 22),
      B: clamp(playerB.goals + playerB.assists, 22),
    },
    {
      metric: 'G / Match',
      A: clamp(gAppA, 1.2),
      B: clamp(gAppB, 1.2),
    },
    {
      metric: 'Apps',
      A: clamp(playerA.appearances, 20),
      B: clamp(playerB.appearances, 20),
    },
    {
      metric: 'Shots OT',
      A: clamp(playerA.shotsOnTarget, 32),
      B: clamp(playerB.shotsOnTarget, 32),
    },
  ];
}

export function filterTransfers(
  transfers: TransferItem[],
  options: {
    dayGroup: 'all' | TransferItem['dayGroup'];
    status: 'all' | TransferStatus;
    region: RegionId;
    query: string;
  }
): TransferItem[] {
  const q = normalizeText(options.query.trim());
  return transfers.filter((item) => {
    if (options.dayGroup !== 'all' && item.dayGroup !== options.dayGroup) return false;
    if (options.status !== 'all' && item.status !== options.status) return false;
    if (options.region !== 'all' && item.region !== options.region) return false;
    if (q) {
      const hay = normalizeText(
        `${item.playerName} ${item.fromTeamName} ${item.toTeamName} ${item.leagueName} ${item.nationality} ${item.status} ${item.fee}`
      );
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

export function getTransferSummary(transfers: TransferItem[]) {
  return {
    totalCount: transfers.length,
    todayCount: transfers.filter((t) => t.dayGroup.startsWith('Today')).length,
    confirmedCount: transfers.filter((t) => t.status === 'Confirmed').length,
    africaCount: transfers.filter((t) => t.region === 'Africa').length,
  };
}

