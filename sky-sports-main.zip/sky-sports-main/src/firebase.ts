import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import {
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import type { UserProfileData } from './types/football';
import { sanitizeProfilePayload } from './utils/footballUtils';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();

export async function fetchUserProfile(uid: string): Promise<UserProfileData | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    return snap.data() as UserProfileData;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveUserProfile(params: {
  uid: string;
  email: string;
  displayName: string;
  username: string;
  favoriteLeague: string;
  favoriteTeam: string;
  bio: string;
  followedTeams: string[];
  alertsEnabled: boolean;
  isNew: boolean;
}): Promise<void> {
  const clean = sanitizeProfilePayload(params);
  const userRef = doc(db, 'users', params.uid);
  const publicRef = doc(db, 'publicProfiles', params.uid);
  const path = `users/${params.uid}`;

  try {
    const batch = writeBatch(db);
    if (params.isNew) {
      batch.set(userRef, {
        uid: params.uid,
        email: clean.email,
        displayName: clean.displayName,
        username: clean.username,
        favoriteLeague: clean.favoriteLeague,
        favoriteTeam: clean.favoriteTeam,
        bio: clean.bio,
        followedTeams: clean.followedTeams,
        alertsEnabled: clean.alertsEnabled,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(publicRef, {
        uid: params.uid,
        displayName: clean.displayName,
        username: clean.username,
        favoriteLeague: clean.favoriteLeague,
        favoriteTeam: clean.favoriteTeam,
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.update(userRef, {
        displayName: clean.displayName,
        username: clean.username,
        favoriteLeague: clean.favoriteLeague,
        favoriteTeam: clean.favoriteTeam,
        bio: clean.bio,
        alertsEnabled: clean.alertsEnabled,
        updatedAt: serverTimestamp(),
      });
      batch.set(
        publicRef,
        {
          uid: params.uid,
          displayName: clean.displayName,
          username: clean.username,
          favoriteLeague: clean.favoriteLeague,
          favoriteTeam: clean.favoriteTeam,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, params.isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

export async function updateFollowedTeams(uid: string, followedTeams: string[]): Promise<void> {
  const path = `users/${uid}`;
  const trimmedTeams = followedTeams
    .map((id) => id.trim().slice(0, 40))
    .filter((id) => id.length > 0)
    .slice(0, 12);

  try {
    await updateDoc(doc(db, 'users', uid), {
      followedTeams: trimmedTeams,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
