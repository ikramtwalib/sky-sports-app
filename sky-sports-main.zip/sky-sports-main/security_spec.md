# Security Specification: Sky Sports User Profiles

## 1. Data Invariants
1. **Identity Integrity**: A `/users/{userId}` or `/publicProfiles/{userId}` document may only be created or updated when `request.auth.uid == userId`, `request.auth.token.email_verified == true`, and `incoming().uid == request.auth.uid`.
2. **PII Isolation**: `/users/{userId}` stores `email` and personal preferences; `get` is strictly restricted to the document owner (`request.auth.uid == userId`), and `list` is explicitly denied (`false`) to prevent user enumeration or email scraping.
3. **Public Non-PII Split**: `/publicProfiles/{userId}` stores only non-PII fan display data (`uid`, `displayName`, `username`, `favoriteLeague`, `favoriteTeam`, `updatedAt`) and never accepts `email` or extra shadow keys.
4. **Immutable Ownership & Timestamps**: `uid` and `createdAt` cannot be modified after creation (`incoming().uid == existing().uid && incoming().createdAt == existing().createdAt`). `createdAt` on create and `updatedAt` on create/update must equal `request.time`.
5. **Bounded Arrays & Strings**: `followedTeams` is capped at `<= 12` entries, and when non-empty, `followedTeams[0]` must be a string (`<= 40` chars). Every string enforces explicit `.size()` bounds and regex checks where specified (`username` matches `^[a-z0-9_]+$`).

## 2. Dirty Dozen Attack Payloads (All Must Yield PERMISSION_DENIED)
1. **Unauthenticated Read**: `GET /users/user123` with `auth = null`.
2. **Cross-User PII Read**: `GET /users/victimUid` as `auth = { uid: 'attackerUid', email_verified: true }`.
3. **Collection Enumeration**: `LIST /users` as any authenticated user.
4. **Unverified Email Registration**: `CREATE /users/user123` with `email_verified: false`.
5. **Identity Spoofing on Create**: `CREATE /users/victimUid` as `attackerUid` (or `uid: 'victimUid'` inside body).
6. **Privilege / Shadow Field Injection**: `CREATE /users/user123` adding `{ isAdmin: true, role: 'admin' }`.
7. **Client-Forged Timestamp**: `CREATE /users/user123` setting `createdAt` to a client `Date` instead of `request.time`.
8. **Immutable Field Mutation**: `UPDATE /users/user123` changing `uid` or `createdAt`.
9. **Oversized String DoS**: `UPDATE /users/user123` setting `bio` to 500 characters (`> 240`).
10. **Invalid Username Pattern**: `CREATE /users/user123` with `username: "Bad Name!"`.
11. **Unbounded Array Injection**: `UPDATE /users/user123` with `followedTeams` containing 20 items (`> 12`) or numeric first element `[123]`.
12. **PII Leak into Public Profile**: `CREATE /publicProfiles/user123` including `email: "a@b.com"` or invalid path ID (`id` > 128 chars).
